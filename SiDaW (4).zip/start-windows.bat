@echo off
cd /d "%~dp0"
title SiDaW Launcher
echo ==========================================
echo   SiDaW - Personal Hub (PC + Smartphone)
echo ==========================================

where node >nul 2>nul
if errorlevel 1 (
  if exist "%ProgramFiles%\nodejs\node.exe" set "PATH=%ProgramFiles%\nodejs;%PATH%"
)
where node >nul 2>nul
if errorlevel 1 (
  echo [ERROR] Node.js not found! Install Node.js 20 LTS from https://nodejs.org/
  pause
  exit /b 1
)

if not exist "node_modules" (
  echo First launch: installing dependencies (about 15-20 seconds)...
  call npm install
  if errorlevel 1 (
    echo [ERROR] npm install failed.
    pause
    exit /b 1
  )
)

echo Starting SiDaW on http://localhost:5173 ...
start "" "http://localhost:5173"
call npm run dev
pause
