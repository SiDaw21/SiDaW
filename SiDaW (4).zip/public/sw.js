/**
 * Service Worker приложения SiDaW.
 * Отвечает за установку приложения на рабочий стол ПК / экран телефона (PWA)
 * и кэширование оболочки интерфейса для быстрого запуска без сети.
 */
const CACHE_NAME = 'sidaw-shell-v6';
const CORE_ASSETS = [
  '/',
  '/index.html',
  '/manifest.webmanifest',
  '/icon-192.png',
  '/icon-512.png',
  '/apple-touch-icon.png',
];

self.addEventListener('install', (event) => {
  event.waitUntil(
    caches
      .open(CACHE_NAME)
      .then((cache) => cache.addAll(CORE_ASSETS))
      .then(() => self.skipWaiting())
  );
});

self.addEventListener('activate', (event) => {
  event.waitUntil(
    caches
      .keys()
      .then((keys) =>
        Promise.all(
          keys.filter((key) => key !== CACHE_NAME).map((key) => caches.delete(key))
        )
      )
      .then(() => self.clients.claim())
  );
});

self.addEventListener('fetch', (event) => {
  const { request } = event;
  if (request.method !== 'GET') return;

  const url = new URL(request.url);
  if (url.origin !== self.location.origin) return;

  // Запросы к API и служебным модулям Vite в режиме разработки не перехватываем кэшем SW
  if (
    url.pathname.startsWith('/api/') ||
    url.pathname.startsWith('/@') ||
    url.pathname.startsWith('/client/') ||
    url.pathname.startsWith('/node_modules/')
  ) {
    return;
  }

  // Для скомпилированных статических файлов (/assets/*, иконки) — сначала кэш, при промахе сеть
  if (url.pathname.startsWith('/assets/') || url.pathname.endsWith('.png')) {
    event.respondWith(
      caches.match(request).then((cached) => {
        if (cached) return cached;
        return fetch(request).then((response) => {
          if (response.ok) {
            const clone = response.clone();
            caches.open(CACHE_NAME).then((cache) => cache.put(request, clone));
          }
          return response;
        });
      })
    );
    return;
  }

  // Для навигации по приложению — сначала сеть, при офлайне отдаём кэшированный index.html
  if (request.mode === 'navigate') {
    event.respondWith(
      fetch(request)
        .then((response) => {
          const clone = response.clone();
          caches.open(CACHE_NAME).then((cache) => cache.put('/', clone));
          return response;
        })
        .catch(() => caches.match('/') || caches.match('/index.html'))
    );
  }
});
