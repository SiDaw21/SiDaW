#!/usr/bin/env bash
set -e
echo "=========================================="
echo "  Запуск SiDaW (Сервер + Веб-интерфейс)"
echo "=========================================="
if [ ! -d "node_modules" ]; then
  echo "Первый запуск: устанавливаем зависимости..."
  npm install
fi
echo "Откройте в браузере: http://localhost:5173"
npm run dev
