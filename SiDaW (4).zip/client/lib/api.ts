import { APP_CONFIG } from '@shared/constants';
import type {
  AccountCreateInput,
  AccountDTO,
  AccountUpdateInput,
  AuthResponseDTO,
  ChangePasswordInput,
  DashboardSummaryDTO,
  HabitCreateInput,
  HabitDTO,
  HabitUpdateInput,
  LoginInput,
  NoteCreateInput,
  NoteDTO,
  NoteUpdateInput,
  RegisterInput,
  SessionDTO,
  TaskCreateInput,
  TaskDTO,
  TaskUpdateInput,
  TransactionCreateInput,
  TransactionDTO,
  UserDTO,
  UserSettings,
  UserSettingsPatch,
} from '@shared/schemas';
import { generateUuid } from '@shared/uuid';
import {
  applyOptimisticOfflineUpdate,
  clearUserLocalCache,
  enqueueOfflineMutation,
  flushOfflineOutbox,
  readCachedResponse,
  writeCachedResponse,
} from './offlineSync';

const TOKEN_STORAGE_KEY = 'sidaw_auth_token';

// Храним токен и в оперативной памяти (чтобы авторизация стабильно работала даже в iframe/инкогнито),
// и в localStorage для сохранения входа между перезагрузками.
let memoryToken: string | null = null;
const fastMemoryGetCache = new Map<string, unknown>();

export function getStoredToken(): string | null {
  if (memoryToken) return memoryToken;
  try {
    const saved = localStorage.getItem(TOKEN_STORAGE_KEY);
    if (saved) {
      memoryToken = saved;
    }
    return saved;
  } catch {
    return memoryToken;
  }
}

export function setStoredToken(token: string | null): void {
  const prev = memoryToken || getStoredToken();
  memoryToken = token;
  fastMemoryGetCache.clear();
  if (!token && prev) {
    clearUserLocalCache(prev);
  }
  try {
    if (token) {
      localStorage.setItem(TOKEN_STORAGE_KEY, token);
    } else {
      localStorage.removeItem(TOKEN_STORAGE_KEY);
    }
  } catch {
    // В iframe/приватном режиме используем memoryToken
  }
}

export function peekCachedGet<T>(endpoint: string): T | null {
  const token = getStoredToken();
  if (!token) return null;
  const key = `${token}::${endpoint}`;
  if (fastMemoryGetCache.has(key)) {
    return fastMemoryGetCache.get(key) as T;
  }
  return readCachedResponse<T>(token, endpoint);
}

export class ApiError extends Error {
  status: number;

  constructor(message: string, status: number) {
    super(message);
    this.name = 'ApiError';
    this.status = status;
  }
}

function isOfflineQueueableMutation(endpoint: string, method: string): boolean {
  if (method === 'GET') return false;
  if (endpoint.startsWith('/api/auth/')) return false;
  return (
    endpoint.startsWith('/api/tasks') ||
    endpoint.startsWith('/api/habits') ||
    endpoint.startsWith('/api/notes') ||
    endpoint.startsWith('/api/finance/')
  );
}

/**
 * Универсальный клиент запросов к серверу SiDaW с передачей токена через X-SiDaW-Token
 * (защита от перезаписи Authorization внешними прокси) и поддержкой офлайн-синхронизации.
 */
export async function apiRequest<T>(
  endpoint: string,
  options: RequestInit = {}
): Promise<T> {
  const token = getStoredToken();
  const method = (options.method || 'GET').toUpperCase();
  const headers = new Headers(options.headers || {});

  if (options.body && !headers.has('Content-Type')) {
    headers.set('Content-Type', 'application/json');
  }
  if (token) {
    headers.set(APP_CONFIG.tokenHeaderName, token);
    if (!headers.has('Authorization')) {
      headers.set('Authorization', `Bearer ${token}`);
    }
  }

  // Если есть отложенные в офлайне изменения и сеть доступна — сначала синхронизируем их
  if (token && typeof navigator !== 'undefined' && navigator.onLine) {
    await flushOfflineOutbox(token);
  }

  try {
    const response = await fetch(endpoint, {
      ...options,
      method,
      headers,
      credentials: 'include',
    });

    const data = await response.json().catch(() => ({}));

    if (!response.ok) {
      if (
        response.status === 401 &&
        endpoint !== '/api/auth/login' &&
        endpoint !== '/api/auth/register' &&
        endpoint !== '/api/auth/me'
      ) {
        if (typeof window !== 'undefined') {
          window.dispatchEvent(new CustomEvent('sidaw:unauthorized'));
        }
      }
      throw new ApiError(
        data?.error || `Ошибка запроса (${response.status})`,
        response.status
      );
    }

    if (method === 'GET' && token) {
      fastMemoryGetCache.set(`${token}::${endpoint}`, data);
      writeCachedResponse(token, endpoint, data);
    } else if (method !== 'GET') {
      fastMemoryGetCache.clear();
    }

    return data as T;
  } catch (err) {
    if (err instanceof ApiError) {
      throw err;
    }

    // Сетевой обрыв / офлайн-режим:
    if (method === 'GET' && token) {
      const cached = readCachedResponse<T>(token, endpoint);
      if (cached !== null) {
        return cached;
      }
    }

    if (token && isOfflineQueueableMutation(endpoint, method)) {
      let bodyStr = typeof options.body === 'string' ? options.body : undefined;

      if (method === 'POST' && bodyStr) {
        try {
          const parsed = JSON.parse(bodyStr);
          if (!parsed.id) {
            parsed.id = generateUuid();
            bodyStr = JSON.stringify(parsed);
          }
        } catch {
          // ignore
        }
      }

      enqueueOfflineMutation(token, {
        endpoint,
        method,
        body: bodyStr,
      });

      return applyOptimisticOfflineUpdate(token, endpoint, method, bodyStr) as T;
    }

    throw new ApiError('Нет соединения с сервером SiDaW', 0);
  }
}

export const authApi = {
  register(input: RegisterInput) {
    return apiRequest<AuthResponseDTO>('/api/auth/register', {
      method: 'POST',
      body: JSON.stringify(input),
    });
  },

  login(input: LoginInput) {
    return apiRequest<AuthResponseDTO>('/api/auth/login', {
      method: 'POST',
      body: JSON.stringify(input),
    });
  },

  me() {
    return apiRequest<{ user: UserDTO; session: SessionDTO }>('/api/auth/me');
  },

  logout() {
    return apiRequest<{ ok: boolean }>('/api/auth/logout', {
      method: 'POST',
    });
  },

  listSessions() {
    return apiRequest<{ sessions: SessionDTO[] }>('/api/auth/sessions');
  },

  revokeSession(sessionId: string) {
    return apiRequest<{ ok: boolean }>(`/api/auth/sessions/${sessionId}`, {
      method: 'DELETE',
    });
  },

  logoutOthers() {
    return apiRequest<{ ok: boolean; revokedCount: number }>(
      '/api/auth/logout-others',
      { method: 'POST' }
    );
  },

  changePassword(input: ChangePasswordInput) {
    return apiRequest<{ ok: boolean }>('/api/auth/change-password', {
      method: 'POST',
      body: JSON.stringify(input),
    });
  },

  updateSettings(patch: UserSettingsPatch) {
    return apiRequest<{ settings: UserSettings }>('/api/auth/settings', {
      method: 'PATCH',
      body: JSON.stringify(patch),
    });
  },
};

export const dashboardApi = {
  getSummary() {
    return apiRequest<DashboardSummaryDTO>('/api/dashboard');
  },
};

export const tasksApi = {
  list() {
    return apiRequest<{ tasks: TaskDTO[] }>('/api/tasks');
  },
  create(input: TaskCreateInput) {
    return apiRequest<{ task: TaskDTO }>('/api/tasks', {
      method: 'POST',
      body: JSON.stringify(input),
    });
  },
  update(id: string, patch: TaskUpdateInput) {
    return apiRequest<{ task: TaskDTO }>(`/api/tasks/${id}`, {
      method: 'PATCH',
      body: JSON.stringify(patch),
    });
  },
  remove(id: string) {
    return apiRequest<{ ok: boolean }>(`/api/tasks/${id}`, {
      method: 'DELETE',
    });
  },
};

export const habitsApi = {
  list() {
    return apiRequest<{ habits: HabitDTO[] }>('/api/habits');
  },
  create(input: HabitCreateInput) {
    return apiRequest<{ habit: HabitDTO }>('/api/habits', {
      method: 'POST',
      body: JSON.stringify(input),
    });
  },
  update(id: string, patch: HabitUpdateInput) {
    return apiRequest<{ habit: HabitDTO }>(`/api/habits/${id}`, {
      method: 'PATCH',
      body: JSON.stringify(patch),
    });
  },
  toggleDate(id: string, date?: string) {
    return apiRequest<{ completed: boolean; date: string; habit: HabitDTO }>(
      `/api/habits/${id}/toggle`,
      {
        method: 'POST',
        body: JSON.stringify(date ? { date } : {}),
      }
    );
  },
  remove(id: string) {
    return apiRequest<{ ok: boolean }>(`/api/habits/${id}`, {
      method: 'DELETE',
    });
  },
};

export const notesApi = {
  list() {
    return apiRequest<{ notes: NoteDTO[] }>('/api/notes');
  },
  create(input: NoteCreateInput) {
    return apiRequest<{ note: NoteDTO }>('/api/notes', {
      method: 'POST',
      body: JSON.stringify(input),
    });
  },
  update(id: string, patch: NoteUpdateInput) {
    return apiRequest<{ note: NoteDTO }>(`/api/notes/${id}`, {
      method: 'PATCH',
      body: JSON.stringify(patch),
    });
  },
  remove(id: string) {
    return apiRequest<{ ok: boolean }>(`/api/notes/${id}`, {
      method: 'DELETE',
    });
  },
};

export const financeApi = {
  listAccounts() {
    return apiRequest<{ accounts: AccountDTO[] }>('/api/finance/accounts');
  },
  createAccount(input: AccountCreateInput) {
    return apiRequest<{ account: AccountDTO }>('/api/finance/accounts', {
      method: 'POST',
      body: JSON.stringify(input),
    });
  },
  updateAccount(id: string, patch: AccountUpdateInput) {
    return apiRequest<{ account: AccountDTO }>(`/api/finance/accounts/${id}`, {
      method: 'PATCH',
      body: JSON.stringify(patch),
    });
  },
  removeAccount(id: string) {
    return apiRequest<{ ok: boolean }>(`/api/finance/accounts/${id}`, {
      method: 'DELETE',
    });
  },
  listTransactions() {
    return apiRequest<{ transactions: TransactionDTO[] }>('/api/finance/transactions');
  },
  createTransaction(input: TransactionCreateInput) {
    return apiRequest<{ transaction: TransactionDTO; accountBalance: number }>(
      '/api/finance/transactions',
      {
        method: 'POST',
        body: JSON.stringify(input),
      }
    );
  },
  removeTransaction(id: string) {
    return apiRequest<{ ok: boolean }>(`/api/finance/transactions/${id}`, {
      method: 'DELETE',
    });
  },
};

export const backupApi = {
  exportJson() {
    return apiRequest<Record<string, unknown>>('/api/backup/export');
  },
  importJson(backupContent: Record<string, unknown>) {
    return apiRequest<{ ok: boolean; importedCount: number }>('/api/backup/import', {
      method: 'POST',
      body: JSON.stringify(backupContent),
    });
  },
  clearOfflineCache() {
    clearUserLocalCache(getStoredToken());
  },
};
