import { useCallback, useEffect, useState } from 'react';
import { getStoredToken } from './api';
import {
  flushOfflineOutbox,
  getSyncStateSnapshot,
  subscribeSyncState,
  type SyncStateSnapshot,
} from './offlineSync';

interface BeforeInstallPromptEvent extends Event {
  prompt: () => Promise<void>;
  userChoice: Promise<{ outcome: 'accepted' | 'dismissed' }>;
}

let deferredInstallEvent: BeforeInstallPromptEvent | null = null;
const pwaListeners = new Set<() => void>();

if (typeof window !== 'undefined') {
  window.addEventListener('beforeinstallprompt', (e) => {
    e.preventDefault();
    deferredInstallEvent = e as BeforeInstallPromptEvent;
    for (const fn of pwaListeners) fn();
  });

  window.addEventListener('appinstalled', () => {
    deferredInstallEvent = null;
    for (const fn of pwaListeners) fn();
  });
}

export function useSyncAndPwa() {
  const [syncState, setSyncState] = useState<SyncStateSnapshot>(() =>
    getSyncStateSnapshot(getStoredToken())
  );
  const [canInstallPwa, setCanInstallPwa] = useState<boolean>(
    Boolean(deferredInstallEvent)
  );
  const [isStandalone, setIsStandalone] = useState<boolean>(() => {
    if (typeof window === 'undefined') return false;
    return (
      window.matchMedia('(display-mode: standalone)').matches ||
      Boolean((window.navigator as any).standalone)
    );
  });

  useEffect(() => {
    const updateSync = () => setSyncState(getSyncStateSnapshot(getStoredToken()));
    const unsubSync = subscribeSyncState(updateSync);

    const handleOnline = () => {
      updateSync();
      flushOfflineOutbox(getStoredToken());
    };
    window.addEventListener('online', handleOnline);

    return () => {
      unsubSync();
      window.removeEventListener('online', handleOnline);
    };
  }, []);

  useEffect(() => {
    const updatePwa = () => {
      setCanInstallPwa(Boolean(deferredInstallEvent));
      setIsStandalone(
        window.matchMedia('(display-mode: standalone)').matches ||
          Boolean((window.navigator as any).standalone)
      );
    };
    pwaListeners.add(updatePwa);
    return () => {
      pwaListeners.delete(updatePwa);
    };
  }, []);

  const promptInstall = useCallback(async () => {
    if (!deferredInstallEvent) return false;
    await deferredInstallEvent.prompt();
    const choice = await deferredInstallEvent.userChoice;
    if (choice.outcome === 'accepted') {
      deferredInstallEvent = null;
      setCanInstallPwa(false);
      return true;
    }
    return false;
  }, []);

  const manualSync = useCallback(async () => {
    return flushOfflineOutbox(getStoredToken());
  }, []);

  return {
    ...syncState,
    canInstallPwa,
    isStandalone,
    promptInstall,
    manualSync,
  };
}
