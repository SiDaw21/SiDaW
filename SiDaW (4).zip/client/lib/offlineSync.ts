/**
 * Менеджер офлайн-кэша и очереди синхронизации SiDaW (для ПК и смартфона).
 *
 * Как работает:
 * 1. Каждый успешный GET-запрос кэшируется локально с привязкой к текущему токену сессии.
 * 2. Если пропал интернет, приложение мгновенно отдаёт сохранённые данные из кэша.
 * 3. Если в офлайне создать/изменить задачу, заметку или операцию — действие попадает в очередь
 *    и автоматически отправляется на сервер, как только связь восстановится.
 */

import { APP_CONFIG } from '@shared/constants';
import { generateUuid } from '@shared/uuid';

export interface QueuedMutation {
  id: string;
  endpoint: string;
  method: string;
  body?: string;
  createdAt: string;
}

export interface SyncStateSnapshot {
  isOnline: boolean;
  isSyncing: boolean;
  pendingCount: number;
  lastSyncedAt: string | null;
}

const CACHE_PREFIX = 'sidaw_cache_v1';
const OUTBOX_PREFIX = 'sidaw_outbox_v1';

type Listener = () => void;
const listeners = new Set<Listener>();

let isSyncingFlag = false;
let lastSyncedAtIso: string | null = null;

function notify() {
  for (const fn of listeners) fn();
}

export function subscribeSyncState(listener: Listener): () => void {
  listeners.add(listener);
  return () => listeners.delete(listener);
}

function getScopeKey(token: string | null): string {
  return token ? token.slice(0, 14) : 'guest';
}

export function readCachedResponse<T>(token: string | null, endpoint: string): T | null {
  try {
    const raw = localStorage.getItem(`${CACHE_PREFIX}:${getScopeKey(token)}:${endpoint}`);
    if (!raw) return null;
    return JSON.parse(raw) as T;
  } catch {
    return null;
  }
}

export function writeCachedResponse(
  token: string | null,
  endpoint: string,
  data: unknown
): void {
  if (!token) return;
  try {
    localStorage.setItem(
      `${CACHE_PREFIX}:${getScopeKey(token)}:${endpoint}`,
      JSON.stringify(data)
    );
    lastSyncedAtIso = new Date().toISOString();
    notify();
  } catch {
    // ignore storage quota errors
  }
}

export function clearUserLocalCache(token: string | null): void {
  try {
    const scope = getScopeKey(token);
    const toRemove: string[] = [];
    for (let i = 0; i < localStorage.length; i++) {
      const key = localStorage.key(i);
      if (
        key &&
        (key.startsWith(`${CACHE_PREFIX}:${scope}:`) ||
          key.startsWith(`${OUTBOX_PREFIX}:${scope}`))
      ) {
        toRemove.push(key);
      }
    }
    for (const k of toRemove) localStorage.removeItem(k);
    notify();
  } catch {
    // ignore
  }
}

export function getOutboxQueue(token: string | null): QueuedMutation[] {
  if (!token) return [];
  try {
    const raw = localStorage.getItem(`${OUTBOX_PREFIX}:${getScopeKey(token)}`);
    if (!raw) return [];
    const parsed = JSON.parse(raw);
    return Array.isArray(parsed) ? parsed : [];
  } catch {
    return [];
  }
}

function saveOutboxQueue(token: string | null, items: QueuedMutation[]): void {
  if (!token) return;
  try {
    localStorage.setItem(`${OUTBOX_PREFIX}:${getScopeKey(token)}`, JSON.stringify(items));
    notify();
  } catch {
    // ignore
  }
}

export function enqueueOfflineMutation(
  token: string | null,
  mutation: Omit<QueuedMutation, 'id' | 'createdAt'>
): void {
  if (!token) return;
  const current = getOutboxQueue(token);
  current.push({
    ...mutation,
    id: generateUuid(),
    createdAt: new Date().toISOString(),
  });
  saveOutboxQueue(token, current);
}

/**
 * Применяет оптимистичное обновление к локальному кэшу задач/заметок,
 * чтобы созданная без интернета запись сразу отобразилась на экране.
 */
export function applyOptimisticOfflineUpdate(
  token: string | null,
  endpoint: string,
  method: string,
  rawBody: string | undefined
): unknown {
  const now = new Date().toISOString();
  const payload = rawBody ? JSON.parse(rawBody) : {};

  if (endpoint === '/api/tasks' && method === 'POST') {
    const item = {
      id: payload.id || generateUuid(),
      title: payload.title,
      description: payload.description || '',
      status: payload.status || 'todo',
      priority: payload.priority || 'medium',
      category: payload.category || 'Личное',
      dueDate: payload.dueDate || null,
      completedAt: payload.status === 'done' ? now : null,
      createdAt: now,
      updatedAt: now,
    };
    const cached = readCachedResponse<{ tasks: any[] }>(token, '/api/tasks') || { tasks: [] };
    writeCachedResponse(token, '/api/tasks', { tasks: [item, ...cached.tasks] });
    return { task: item, queuedOffline: true };
  }

  if (endpoint === '/api/notes' && method === 'POST') {
    const item = {
      id: payload.id || generateUuid(),
      title: payload.title,
      content: payload.content || '',
      tags: payload.tags || [],
      color: payload.color || 'default',
      isPinned: Boolean(payload.isPinned),
      createdAt: now,
      updatedAt: now,
    };
    const cached = readCachedResponse<{ notes: any[] }>(token, '/api/notes') || { notes: [] };
    writeCachedResponse(token, '/api/notes', { notes: [item, ...cached.notes] });
    return { note: item, queuedOffline: true };
  }

  if (endpoint === '/api/habits' && method === 'POST') {
    const item = {
      id: payload.id || generateUuid(),
      title: payload.title,
      description: payload.description || '',
      color: payload.color || 'cyan',
      targetDaysPerWeek: payload.targetDaysPerWeek || 7,
      completedDates: [],
      currentStreak: 0,
      bestStreak: 0,
      totalCompletions: 0,
      createdAt: now,
      updatedAt: now,
    };
    const cached = readCachedResponse<{ habits: any[] }>(token, '/api/habits') || {
      habits: [],
    };
    writeCachedResponse(token, '/api/habits', { habits: [...cached.habits, item] });
    return { habit: item, queuedOffline: true };
  }

  return { ok: true, queuedOffline: true };
}

export async function flushOfflineOutbox(token: string | null): Promise<number> {
  if (!token || isSyncingFlag || typeof navigator !== 'undefined' && !navigator.onLine) {
    return 0;
  }

  const queue = getOutboxQueue(token);
  if (queue.length === 0) return 0;

  isSyncingFlag = true;
  notify();

  let synced = 0;
  const remaining: QueuedMutation[] = [];

  try {
    for (let i = 0; i < queue.length; i++) {
      const item = queue[i];
      try {
        const res = await fetch(item.endpoint, {
          method: item.method,
          headers: {
            'Content-Type': 'application/json',
            [APP_CONFIG.tokenHeaderName]: token,
            Authorization: `Bearer ${token}`,
          },
          body: item.body,
          credentials: 'include',
        });

        // Если сервер ответил или запись некорректна (4xx, кроме 401) — убираем из очереди
        if (res.ok || (res.status >= 400 && res.status < 500 && res.status !== 401)) {
          synced++;
        } else {
          remaining.push(...queue.slice(i));
          break;
        }
      } catch {
        // Сеть снова пропала — сохраняем остаток очереди до следующего подключения
        remaining.push(...queue.slice(i));
        break;
      }
    }

    saveOutboxQueue(token, remaining);
    if (synced > 0) {
      lastSyncedAtIso = new Date().toISOString();
    }
  } finally {
    isSyncingFlag = false;
    notify();
  }

  return synced;
}

export function getSyncStateSnapshot(token: string | null): SyncStateSnapshot {
  return {
    isOnline: typeof navigator !== 'undefined' ? navigator.onLine : true,
    isSyncing: isSyncingFlag,
    pendingCount: getOutboxQueue(token).length,
    lastSyncedAt: lastSyncedAtIso,
  };
}

if (typeof window !== 'undefined') {
  window.addEventListener('online', () => notify());
  window.addEventListener('offline', () => notify());
}
