import React, { createContext, useCallback, useContext, useEffect, useState } from 'react';
import type { LoginInput, RegisterInput, SessionDTO, UserDTO } from '@shared/schemas';
import { authApi, getStoredToken, setStoredToken } from '../lib/api';

interface AuthContextValue {
  user: UserDTO | null;
  currentSession: SessionDTO | null;
  isLoading: boolean;
  login: (input: LoginInput) => Promise<void>;
  register: (input: RegisterInput) => Promise<void>;
  logout: () => Promise<void>;
  refreshProfile: () => Promise<void>;
}

const AuthContext = createContext<AuthContextValue | null>(null);

export function AuthProvider({ children }: { children: React.ReactNode }) {
  const [user, setUser] = useState<UserDTO | null>(null);
  const [currentSession, setCurrentSession] = useState<SessionDTO | null>(null);
  const [isLoading, setIsLoading] = useState(true);

  const refreshProfile = useCallback(async () => {
    try {
      const data = await authApi.me();
      setUser(data.user);
      setCurrentSession(data.session);
    } catch {
      setStoredToken(null);
      setUser(null);
      setCurrentSession(null);
    } finally {
      setIsLoading(false);
    }
  }, []);

  useEffect(() => {
    refreshProfile();

    const handleUnauthorized = () => {
      setStoredToken(null);
      setUser(null);
      setCurrentSession(null);
    };
    window.addEventListener('sidaw:unauthorized', handleUnauthorized);
    return () => window.removeEventListener('sidaw:unauthorized', handleUnauthorized);
  }, [refreshProfile]);

  const login = useCallback(async (input: LoginInput) => {
    const res = await authApi.login(input);
    setStoredToken(res.token);
    setUser(res.user);
    setCurrentSession(res.session);
  }, []);

  const register = useCallback(async (input: RegisterInput) => {
    const res = await authApi.register(input);
    setStoredToken(res.token);
    setUser(res.user);
    setCurrentSession(res.session);
  }, []);

  const logout = useCallback(async () => {
    try {
      await authApi.logout();
    } catch {
      // Даже если сеть недоступна — очищаем локальную сессию
    } finally {
      setStoredToken(null);
      setUser(null);
      setCurrentSession(null);
    }
  }, []);

  return (
    <AuthContext.Provider
      value={{
        user,
        currentSession,
        isLoading,
        login,
        register,
        logout,
        refreshProfile,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth(): AuthContextValue {
  const ctx = useContext(AuthContext);
  if (!ctx) {
    throw new Error('useAuth должен использоваться внутри AuthProvider');
  }
  return ctx;
}
