import React, { createContext, useCallback, useContext, useEffect, useMemo, useState } from 'react';
import { CURRENCY_SYMBOLS, type CurrencyCode } from '@shared/constants';
import {
  DEFAULT_USER_SETTINGS,
  userSettingsSchema,
  type UserSettings,
  type UserSettingsPatch,
} from '@shared/schemas';
import { useAuth } from './AuthContext';
import { authApi } from '../lib/api';

const LOCAL_SETTINGS_KEY = 'sidaw_ui_settings_v1';

function loadLocalSettings(): UserSettings {
  try {
    const raw = localStorage.getItem(LOCAL_SETTINGS_KEY);
    if (!raw) return { ...DEFAULT_USER_SETTINGS };
    const parsed = userSettingsSchema.safeParse(JSON.parse(raw));
    return parsed.success ? parsed.data : { ...DEFAULT_USER_SETTINGS };
  } catch {
    return { ...DEFAULT_USER_SETTINGS };
  }
}

function saveLocalSettings(settings: UserSettings): void {
  try {
    localStorage.setItem(LOCAL_SETTINGS_KEY, JSON.stringify(settings));
  } catch {
    // ignore
  }
}

interface SettingsContextValue {
  settings: UserSettings;
  resolvedTheme: 'dark' | 'light';
  balancesTemporarilyRevealed: boolean;
  toggleTemporaryReveal: () => void;
  updateSettings: (patch: UserSettingsPatch) => Promise<void>;
  resetSettings: () => Promise<void>;
  formatAmount: (amount: number, currency: string) => string;
  playGlassSound: () => void;
}

const SettingsContext = createContext<SettingsContextValue | null>(null);

export function SettingsProvider({ children }: { children: React.ReactNode }) {
  const { user } = useAuth();
  const [settings, setSettings] = useState<UserSettings>(() => loadLocalSettings());
  const [systemPrefersDark, setSystemPrefersDark] = useState<boolean>(() => {
    if (typeof window === 'undefined') return true;
    return window.matchMedia('(prefers-color-scheme: dark)').matches;
  });
  const [balancesTemporarilyRevealed, setBalancesTemporarilyRevealed] = useState(false);

  // Подхватываем настройки аккаунта при входе
  useEffect(() => {
    if (user?.settings) {
      setSettings(user.settings);
      saveLocalSettings(user.settings);
    }
  }, [user?.id]);

  // Следим за системной темой ОС (для режима themeMode === 'system')
  useEffect(() => {
    if (typeof window === 'undefined') return;
    const mq = window.matchMedia('(prefers-color-scheme: dark)');
    const handler = (e: MediaQueryListEvent) => setSystemPrefersDark(e.matches);
    if (mq.addEventListener) {
      mq.addEventListener('change', handler);
      return () => mq.removeEventListener('change', handler);
    }
  }, []);

  const resolvedTheme: 'dark' | 'light' = useMemo(() => {
    if (settings.themeMode === 'system') {
      return systemPrefersDark ? 'dark' : 'light';
    }
    return settings.themeMode;
  }, [settings.themeMode, systemPrefersDark]);

  // Применяем глобальные CSS-классы на <html>
  useEffect(() => {
    const root = document.documentElement;
    root.classList.remove('theme-dark', 'theme-light');
    root.classList.add(resolvedTheme === 'light' ? 'theme-light' : 'theme-dark');

    root.classList.remove('glass-clear', 'glass-balanced', 'glass-frosted', 'glass-performance');
    root.classList.add(`glass-${settings.glassIntensity}`);

    root.classList.toggle('compact-ui', settings.compactMode);
    root.classList.toggle('reduce-motion', !settings.animationsEnabled);
  }, [
    resolvedTheme,
    settings.glassIntensity,
    settings.compactMode,
    settings.animationsEnabled,
  ]);

  const updateSettings = useCallback(
    async (patch: UserSettingsPatch) => {
      setSettings((prev) => {
        const next = { ...prev, ...patch };
        saveLocalSettings(next);
        return next;
      });
      if (patch.hideBalances === false) {
        setBalancesTemporarilyRevealed(false);
      }
      if (user) {
        try {
          await authApi.updateSettings(patch);
        } catch {
          // В офлайне настройки остаются в localStorage
        }
      }
    },
    [user]
  );

  const resetSettings = useCallback(async () => {
    setSettings({ ...DEFAULT_USER_SETTINGS });
    saveLocalSettings({ ...DEFAULT_USER_SETTINGS });
    if (user) {
      try {
        await authApi.updateSettings({ ...DEFAULT_USER_SETTINGS });
      } catch {
        // ignore
      }
    }
  }, [user]);

  const toggleTemporaryReveal = useCallback(() => {
    setBalancesTemporarilyRevealed((v) => !v);
  }, []);

  const formatAmount = useCallback(
    (amount: number, currency: string) => {
      const sym = CURRENCY_SYMBOLS[currency as CurrencyCode] || currency;
      if (settings.hideBalances && !balancesTemporarilyRevealed) {
        return `•••• ${sym}`;
      }
      const rounded = settings.showCents ? amount : Math.round(amount);
      return `${rounded.toLocaleString('ru-RU', {
        minimumFractionDigits: settings.showCents && amount % 1 !== 0 ? 2 : 0,
        maximumFractionDigits: settings.showCents ? 2 : 0,
      })} ${sym}`;
    },
    [settings.hideBalances, settings.showCents, balancesTemporarilyRevealed]
  );

  /**
   * Мягкий «стеклянный» звуковой отклик при завершении задачи
   */
  const playGlassSound = useCallback(() => {
    if (!settings.soundEffects) return;
    try {
      const AudioCtx = window.AudioContext || (window as any).webkitAudioContext;
      if (!AudioCtx) return;
      const ctx = new AudioCtx();
      const now = ctx.currentTime;

      const osc1 = ctx.createOscillator();
      const osc2 = ctx.createOscillator();
      const gain = ctx.createGain();

      osc1.type = 'sine';
      osc2.type = 'triangle';
      osc1.frequency.setValueAtTime(880, now);
      osc1.frequency.exponentialRampToValueAtTime(1318.5, now + 0.14);
      osc2.frequency.setValueAtTime(1760, now);

      gain.gain.setValueAtTime(0.001, now);
      gain.gain.exponentialRampToValueAtTime(0.06, now + 0.02);
      gain.gain.exponentialRampToValueAtTime(0.0001, now + 0.28);

      osc1.connect(gain);
      osc2.connect(gain);
      gain.connect(ctx.destination);

      osc1.start(now);
      osc2.start(now);
      osc1.stop(now + 0.3);
      osc2.stop(now + 0.3);

      setTimeout(() => ctx.close().catch(() => {}), 350);
    } catch {
      // ignore audio restrictions
    }
  }, [settings.soundEffects]);

  return (
    <SettingsContext.Provider
      value={{
        settings,
        resolvedTheme,
        balancesTemporarilyRevealed,
        toggleTemporaryReveal,
        updateSettings,
        resetSettings,
        formatAmount,
        playGlassSound,
      }}
    >
      {children}
    </SettingsContext.Provider>
  );
}

export function useSettings(): SettingsContextValue {
  const ctx = useContext(SettingsContext);
  if (!ctx) {
    throw new Error('useSettings должен использоваться внутри SettingsProvider');
  }
  return ctx;
}
