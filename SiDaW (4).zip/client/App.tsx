import React, { useEffect, useRef, useState } from 'react';
import { NAV_TAB_IDS, type NavTabId } from '@shared/constants';
import { AppShell } from './components/AppShell';
import { AuthScreen } from './components/AuthScreen';
import { LiquidBackground } from './components/LiquidBackground';
import { SiDaWLogo } from './components/SiDaWLogo';
import { AuthProvider, useAuth } from './context/AuthContext';
import { SettingsProvider, useSettings } from './context/SettingsContext';
import { DashboardPage } from './pages/DashboardPage';
import { FinancePage } from './pages/FinancePage';
import { HabitsPage } from './pages/HabitsPage';
import { NotesPage } from './pages/NotesPage';
import { ProfileDevicesPage, type AccountSubView } from './pages/ProfileDevicesPage';
import { TasksPage } from './pages/TasksPage';

function AppContent() {
  const { user, isLoading } = useAuth();
  const { settings } = useSettings();
  const [activeTab, setActiveTab] = useState<NavTabId>('dashboard');
  const [slideDirection, setSlideDirection] = useState<'forward' | 'backward'>('forward');
  const [accountSubView, setAccountSubView] = useState<AccountSubView>('overview');
  const appliedStartTabForUser = useRef<string | null>(null);

  // При входе открываем выбранную пользователем в Настройках стартовую вкладку
  useEffect(() => {
    if (user && appliedStartTabForUser.current !== user.id) {
      appliedStartTabForUser.current = user.id;
      setActiveTab(settings.startTab || 'dashboard');
    }
    if (!user) {
      appliedStartTabForUser.current = null;
    }
  }, [user, settings.startTab]);

  if (isLoading) {
    return (
      <div className="min-h-screen relative flex flex-col items-center justify-center gap-4">
        <LiquidBackground activeTab="dashboard" />
        <div className="liquid-glass px-8 py-6 rounded-3xl flex flex-col items-center gap-3">
          <SiDaWLogo size="lg" />
          <div className="flex items-center gap-2 text-slate-300 text-sm">
            <span className="h-2.5 w-2.5 rounded-[2px] bg-indigo-500 animate-ping" />
            <span>Загрузка рабочего пространства SiDaW...</span>
          </div>
        </div>
      </div>
    );
  }

  if (!user) {
    return <AuthScreen />;
  }

  function handleSelectTab(nextTab: NavTabId) {
    if (nextTab === activeTab) return;
    const prevIdx = NAV_TAB_IDS.indexOf(activeTab);
    const nextIdx = NAV_TAB_IDS.indexOf(nextTab);
    setSlideDirection(nextIdx >= prevIdx ? 'forward' : 'backward');
    setActiveTab(nextTab);
  }

  const stageAnimationClass =
    slideDirection === 'forward' ? 'tab-stage-forward' : 'tab-stage-backward';

  return (
    <AppShell activeTab={activeTab} onSelectTab={handleSelectTab}>
      <div key={activeTab} className={stageAnimationClass}>
        {activeTab === 'dashboard' && <DashboardPage onNavigate={handleSelectTab} />}
        {activeTab === 'tasks' && <TasksPage />}
        {activeTab === 'habits' && <HabitsPage />}
        {activeTab === 'notes' && <NotesPage />}
        {activeTab === 'finance' && <FinancePage />}
        {activeTab === 'profile' && (
          <ProfileDevicesPage
            subView={accountSubView}
            onChangeSubView={setAccountSubView}
          />
        )}
      </div>
    </AppShell>
  );
}

export function App() {
  return (
    <AuthProvider>
      <SettingsProvider>
        <AppContent />
      </SettingsProvider>
    </AuthProvider>
  );
}

export default App;
