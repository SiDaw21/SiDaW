import React, { useEffect, useState } from 'react';
import {
  Download,
  Eye,
  EyeOff,
  Laptop,
  RefreshCw,
  Smartphone,
  Wifi,
  WifiOff,
} from 'lucide-react';
import { TAB_COLOR_THEMES, type NavTabId } from '@shared/constants';
import { useAuth } from '../context/AuthContext';
import { useSettings } from '../context/SettingsContext';
import { useSyncAndPwa } from '../lib/usePwaAndSync';
import { LiquidBackground } from './LiquidBackground';
import { PIXEL_NAV_ICONS, PixelSpark } from './PixelIcons';
import { SiDaWLogo } from './SiDaWLogo';

interface NavItem {
  id: NavTabId;
  label: string;
  shortLabel: string;
}

const NAV_ITEMS: NavItem[] = [
  { id: 'dashboard', label: 'Дашборд', shortLabel: 'Обзор' },
  { id: 'tasks', label: 'Задачи', shortLabel: 'Задачи' },
  { id: 'habits', label: 'Привычки', shortLabel: 'Привычки' },
  { id: 'notes', label: 'Заметки', shortLabel: 'Заметки' },
  { id: 'finance', label: 'Финансы', shortLabel: 'Финансы' },
  { id: 'profile', label: 'Аккаунт', shortLabel: 'Аккаунт' },
];

interface AppShellProps {
  activeTab: NavTabId;
  onSelectTab: (tab: NavTabId) => void;
  children: React.ReactNode;
}

export function AppShell({
  activeTab,
  onSelectTab,
  children,
}: AppShellProps) {
  const { user, currentSession } = useAuth();
  const {
    settings,
    balancesTemporarilyRevealed,
    toggleTemporaryReveal,
  } = useSettings();
  const {
    isOnline,
    isSyncing,
    pendingCount,
    canInstallPwa,
    isStandalone,
    promptInstall,
    manualSync,
  } = useSyncAndPwa();

  const [simulatePhoneOnDesktop, setSimulatePhoneOnDesktop] = useState(false);

  const activeIndex = Math.max(
    0,
    NAV_ITEMS.findIndex((item) => item.id === activeTab)
  );
  const currentNav = NAV_ITEMS[activeIndex] || NAV_ITEMS[0];
  const activeTabColor = TAB_COLOR_THEMES[activeTab];

  // Обновляем глобальные CSS-переменные цвета активной вкладки
  useEffect(() => {
    const root = document.documentElement;
    root.style.setProperty('--tab-rgb', activeTabColor.accentRgb);
    root.style.setProperty('--tab-hex', activeTabColor.accentHex);
  }, [activeTabColor]);

  function renderSyncPill() {
    if (isSyncing) {
      return (
        <span className="liquid-glass-subtle pixel-num inline-flex items-center gap-1.5 px-2.5 py-1 rounded-lg text-[11px] font-medium text-indigo-400">
          <RefreshCw className="w-3 h-3 animate-spin" />
          <span>СИНХР...</span>
        </span>
      );
    }

    if (!isOnline) {
      return (
        <span className="liquid-glass-subtle pixel-num inline-flex items-center gap-1.5 px-2.5 py-1 rounded-lg text-[11px] font-medium text-amber-400">
          <WifiOff className="w-3 h-3" />
          <span>ОФЛАЙН{pendingCount > 0 ? ` [${pendingCount}]` : ''}</span>
        </span>
      );
    }

    if (pendingCount > 0) {
      return (
        <button
          type="button"
          onClick={manualSync}
          className="liquid-glass-subtle pixel-num inline-flex items-center gap-1.5 px-2.5 py-1 rounded-lg text-[11px] font-medium text-amber-400"
        >
          <RefreshCw className="w-3 h-3" />
          <span>ОТПРАВИТЬ [{pendingCount}]</span>
        </button>
      );
    }

    return (
      <span className="liquid-glass-subtle pixel-num inline-flex items-center gap-1.5 px-2.5 py-1 rounded-lg text-[11px] font-medium text-emerald-400">
        <Wifi className="w-3 h-3" />
        <span className="hidden sm:inline">ОНЛАЙН</span>
      </span>
    );
  }

  // Эмуляция экрана смартфона на ПК
  if (simulatePhoneOnDesktop) {
    return (
      <div className="min-h-screen relative flex flex-col items-center justify-center p-4">
        <LiquidBackground activeTab={activeTab} />

        <div className="mb-3 liquid-glass flex items-center gap-3 px-4 py-2 rounded-2xl">
          <span className="text-xs text-slate-200 flex items-center gap-1.5">
            <Smartphone className="w-3.5 h-3.5" style={{ color: activeTabColor.accentHex }} />
            Мобильный вид SiDaW • {activeTabColor.name}
          </span>
          <button
            type="button"
            onClick={() => setSimulatePhoneOnDesktop(false)}
            className="liquid-btn-accent text-xs font-medium px-3 py-1 rounded-lg flex items-center gap-1"
          >
            <Laptop className="w-3.5 h-3.5" />
            <span>Вернуть вид ПК</span>
          </button>
        </div>

        <div className="w-full max-w-[395px] h-[790px] rounded-[2.4rem] border-[4px] border-white/25 shadow-2xl overflow-hidden flex flex-col relative liquid-glass">
          <LiquidBackground activeTab={activeTab} />

          {/* Мобильная шапка */}
          <header className="px-4 py-3 liquid-glass-nav border-b flex items-center justify-between shrink-0 z-10">
            <SiDaWLogo size="sm" />
            {renderSyncPill()}
          </header>

          <main className="flex-1 overflow-y-auto overflow-x-hidden p-4 z-10">{children}</main>

          {/* Плавающая нижняя док-панель со скользящей капсулой */}
          <div className="p-2.5 pt-1 z-10 shrink-0">
            <nav className="relative liquid-glass-nav rounded-2xl border p-1.5 grid grid-cols-6">
              {/* Скользящая капсула активной вкладки */}
              <div
                aria-hidden="true"
                className="nav-sliding-pill pointer-events-none absolute top-1.5 bottom-1.5 left-1.5 w-[calc((100%-0.75rem)/6)] rounded-xl"
                style={{
                  transform: `translate3d(${activeIndex * 100}%, 0, 0)`,
                  background: `linear-gradient(135deg, rgba(${activeTabColor.accentRgb}, 0.94), rgba(${activeTabColor.accentRgb}, 0.7))`,
                  boxShadow: `inset 0 2px 0 rgba(255,255,255,0.38), 0 2px 0 rgba(0,0,0,0.22), 0 6px 14px -3px rgba(${activeTabColor.accentRgb}, 0.52)`,
                }}
              />

              {NAV_ITEMS.map((item) => {
                const PixelIcon = PIXEL_NAV_ICONS[item.id];
                const isActive = item.id === activeTab;
                const itemColor = TAB_COLOR_THEMES[item.id];
                return (
                  <button
                    key={item.id}
                    type="button"
                    onClick={() => onSelectTab(item.id)}
                    className={`relative z-10 flex flex-col items-center justify-center py-1.5 rounded-xl transition-colors duration-200 ${
                      isActive ? '!text-white' : 'text-slate-400 hover:text-white'
                    }`}
                  >
                    <PixelIcon
                      className="w-4 h-4 transition-transform duration-200"
                      style={
                        isActive
                          ? { color: '#ffffff', transform: 'translateY(-1px)' }
                          : { color: itemColor.accentHex }
                      }
                    />
                    <span
                      className={`text-[10px] font-medium mt-0.5 truncate max-w-full px-1 ${
                        isActive ? '!text-white font-semibold' : ''
                      }`}
                    >
                      {item.shortLabel}
                    </span>
                  </button>
                );
              })}
            </nav>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen relative flex flex-col md:flex-row">
      <LiquidBackground activeTab={activeTab} />

      {/* Парящий стеклянный сайдбар для ПК (md+) */}
      <aside className="hidden md:flex md:w-64 lg:w-72 shrink-0 flex-col p-3.5 md:sticky md:top-0 md:h-screen">
        <div className="liquid-glass-nav flex-1 rounded-3xl border p-4 flex flex-col justify-between">
          <div>
            <div className="px-2 py-1.5 flex items-center justify-between gap-2">
              <SiDaWLogo size="md" />
              <span className="pixel-badge text-[10px] px-2 py-0.5 rounded-md truncate transition-colors duration-300">
                {activeTabColor.name}
              </span>
            </div>

            {/* Навигация со скользящей вертикальной капсулой и пиксельными иконками */}
            <nav className="relative mt-6 flex flex-col gap-1.5">
              {/* Скользящая капсула активного раздела (высота 44px + отступ 6px = шаг 50px) */}
              <div
                aria-hidden="true"
                className="nav-sliding-pill pointer-events-none absolute left-0 right-0 top-0 h-11 rounded-2xl border border-white/30"
                style={{
                  transform: `translate3d(0, ${activeIndex * 50}px, 0)`,
                  background: `linear-gradient(135deg, rgba(${activeTabColor.accentRgb}, 0.95) 0%, rgba(${activeTabColor.accentRgb}, 0.72) 100%)`,
                  boxShadow: `inset 0 2px 0 rgba(255,255,255,0.4), 0 3px 0 rgba(0,0,0,0.22), 0 10px 22px -6px rgba(${activeTabColor.accentRgb}, 0.52)`,
                }}
              />

              {NAV_ITEMS.map((item) => {
                const PixelIcon = PIXEL_NAV_ICONS[item.id];
                const isActive = item.id === activeTab;
                const tabPalette = TAB_COLOR_THEMES[item.id];

                return (
                  <button
                    key={item.id}
                    type="button"
                    onClick={() => onSelectTab(item.id)}
                    className={`relative z-10 h-11 w-full flex items-center justify-between gap-3 px-3.5 rounded-2xl text-sm font-medium border transition-colors duration-200 ${
                      isActive
                        ? '!text-white border-transparent'
                        : 'border-transparent text-slate-300 hover:bg-white/5 hover:border-white/10'
                    }`}
                  >
                    <div className="flex items-center gap-3 min-w-0">
                      <span
                        className={`p-1.5 rounded-lg flex items-center justify-center transition-colors duration-200 ${
                          isActive ? 'bg-white/20' : 'liquid-glass-subtle'
                        }`}
                      >
                        <PixelIcon
                          className="w-4 h-4 shrink-0"
                          style={{ color: isActive ? '#ffffff' : tabPalette.accentHex }}
                        />
                      </span>
                      <span className={`truncate ${isActive ? '!text-white font-semibold' : ''}`}>
                        {item.label}
                      </span>
                    </div>

                    {/* Пиксельный светодиод вкладки */}
                    <span
                      className="w-2 h-2 rounded-[2px] shrink-0 transition-transform duration-200"
                      style={{
                        backgroundColor: isActive ? '#ffffff' : tabPalette.accentHex,
                        opacity: isActive ? 0.95 : 0.65,
                        transform: isActive ? 'scale(1.15)' : 'scale(1)',
                      }}
                    />
                  </button>
                );
              })}
            </nav>

            {canInstallPwa && !isStandalone && (
              <div className="mt-5 p-3.5 rounded-2xl liquid-glass-subtle">
                <p className="text-xs font-semibold text-white">Установить на ПК</p>
                <p className="text-[11px] text-slate-400 mt-0.5">
                  Отдельное окно и пиксельная иконка на рабочем столе
                </p>
                <button
                  type="button"
                  onClick={promptInstall}
                  className="mt-2.5 w-full py-2 px-3 rounded-xl liquid-btn-accent text-xs font-medium inline-flex items-center justify-center gap-1.5"
                >
                  <Download className="w-3.5 h-3.5" />
                  <span>Установить SiDaW</span>
                </button>
              </div>
            )}
          </div>

          {/* Нижняя карточка профиля (переход строго во вкладку Аккаунт) */}
          <div className="pt-3 border-t border-white/10 space-y-2.5">
            {currentSession && (
              <div className="px-3 py-1.5 rounded-xl liquid-glass-subtle text-[11px] text-slate-400 truncate">
                Устройство: <span className="text-slate-200">{currentSession.deviceLabel}</span>
              </div>
            )}

            <button
              type="button"
              onClick={() => onSelectTab('profile')}
              className="w-full flex items-center gap-2.5 p-2 rounded-2xl liquid-glass-subtle hover:border-white/25 text-left transition-all"
            >
              <div
                className="h-9 w-9 rounded-lg flex items-center justify-center text-sm pixel-brand font-bold !text-white shrink-0 shadow-md transition-colors duration-300"
                style={{
                  background: `linear-gradient(135deg, ${activeTabColor.accentHex}, ${activeTabColor.secondaryHex})`,
                }}
              >
                {user?.name.slice(0, 1).toUpperCase()}
              </div>
              <div className="min-w-0 flex-1">
                <p className="text-sm font-semibold text-white truncate">{user?.name}</p>
                <p className="text-[11px] text-slate-400 truncate">{user?.email}</p>
              </div>
            </button>
          </div>
        </div>
      </aside>

      {/* Мобильная верхняя стеклянная шапка (< md) */}
      <header className="md:hidden sticky top-0 z-30 liquid-glass-nav border-b px-4 py-3 flex items-center justify-between gap-2">
        <SiDaWLogo size="sm" />
        {renderSyncPill()}
      </header>

      {/* Основная рабочая область */}
      <div className="flex-1 flex flex-col min-w-0 pb-24 md:pb-6 overflow-x-hidden">
        {/* Верхняя панель заголовка (для ПК) */}
        <header className="hidden md:flex items-center justify-between px-8 py-5">
          <div className="flex items-center gap-3">
            <PixelSpark
              className="w-4 h-4 transition-colors duration-300"
              style={{ color: activeTabColor.accentHex }}
            />
            <h1
              key={activeTab}
              className="tab-title-animate text-2xl font-bold text-white tracking-tight"
            >
              {currentNav.label}
            </h1>
            {renderSyncPill()}
          </div>

          <div className="flex items-center gap-2">
            {settings.hideBalances && (
              <button
                type="button"
                onClick={toggleTemporaryReveal}
                className="liquid-glass-subtle inline-flex items-center gap-1.5 px-3 py-2 rounded-xl text-xs font-medium text-slate-200 hover:border-white/25"
                title="Временно показать или скрыть суммы"
              >
                {balancesTemporarilyRevealed ? (
                  <>
                    <EyeOff className="w-3.5 h-3.5 text-amber-400" />
                    <span>Скрыть суммы</span>
                  </>
                ) : (
                  <>
                    <Eye className="w-3.5 h-3.5 text-emerald-400" />
                    <span>Показать суммы</span>
                  </>
                )}
              </button>
            )}

            <button
              type="button"
              onClick={() => setSimulatePhoneOnDesktop(true)}
              className="liquid-glass-subtle inline-flex items-center gap-2 px-3.5 py-2 rounded-xl text-xs font-medium text-slate-200 hover:border-white/25"
            >
              <Smartphone
                className="w-4 h-4 transition-colors duration-300"
                style={{ color: activeTabColor.accentHex }}
              />
              <span>Вид на телефоне</span>
            </button>
          </div>
        </header>

        <main className="flex-1 px-4 sm:px-6 md:px-8 pt-3 md:pt-0 max-w-5xl w-full mx-auto">
          {children}
        </main>
      </div>

      {/* Плавающая нижняя док-панель на телефонах (< md) со скользящей капсулой */}
      <div className="md:hidden fixed bottom-0 inset-x-0 z-30 px-3 pb-safe pt-1 pointer-events-none">
        <nav className="pointer-events-auto relative liquid-glass-nav rounded-2xl border p-1.5 grid grid-cols-6">
          {/* Скользящая капсула активной вкладки */}
          <div
            aria-hidden="true"
            className="nav-sliding-pill pointer-events-none absolute top-1.5 bottom-1.5 left-1.5 w-[calc((100%-0.75rem)/6)] rounded-xl"
            style={{
              transform: `translate3d(${activeIndex * 100}%, 0, 0)`,
              background: `linear-gradient(135deg, rgba(${activeTabColor.accentRgb}, 0.94), rgba(${activeTabColor.accentRgb}, 0.7))`,
              boxShadow: `inset 0 2px 0 rgba(255,255,255,0.4), 0 2px 0 rgba(0,0,0,0.22), 0 6px 14px -3px rgba(${activeTabColor.accentRgb}, 0.54)`,
            }}
          />

          {NAV_ITEMS.map((item) => {
            const PixelIcon = PIXEL_NAV_ICONS[item.id];
            const isActive = item.id === activeTab;
            const itemColor = TAB_COLOR_THEMES[item.id];

            return (
              <button
                key={item.id}
                type="button"
                onClick={() => onSelectTab(item.id)}
                className={`relative z-10 flex flex-col items-center justify-center py-1.5 rounded-xl transition-colors duration-200 ${
                  isActive ? '!text-white' : 'text-slate-400 hover:text-white'
                }`}
              >
                <PixelIcon
                  className="w-5 h-5 transition-transform duration-200"
                  style={
                    isActive
                      ? { color: '#ffffff', transform: 'translateY(-1px)' }
                      : { color: itemColor.accentHex }
                  }
                />
                <span
                  className={`text-[10px] font-medium mt-0.5 truncate max-w-full px-1 ${
                    isActive ? '!text-white font-semibold' : ''
                  }`}
                >
                  {item.shortLabel}
                </span>
              </button>
            );
          })}
        </nav>
      </div>
    </div>
  );
}
