import React, { useState } from 'react';
import { CURRENCIES, CURRENCY_SYMBOLS, type CurrencyCode } from '@shared/constants';
import {
  AlertCircle,
  CheckCircle2,
  Laptop,
  Lock,
  Mail,
  ShieldCheck,
  Smartphone,
  User,
} from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import { LiquidBackground } from './LiquidBackground';
import { SiDaWLogo } from './SiDaWLogo';

export function AuthScreen() {
  const { login, register } = useAuth();
  const [mode, setMode] = useState<'login' | 'register'>('login');

  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [defaultCurrency, setDefaultCurrency] = useState<CurrencyCode>('EUR');

  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState<string | null>(null);

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setError(null);
    setSubmitting(true);

    try {
      if (mode === 'login') {
        await login({
          email: email.trim(),
          password,
        });
      } else {
        await register({
          name: name.trim(),
          email: email.trim(),
          password,
          defaultCurrency,
        });
      }
    } catch (err: any) {
      setError(err?.message || 'Не удалось выполнить запрос. Проверьте данные.');
    } finally {
      setSubmitting(false);
    }
  }

  return (
    <div className="min-h-screen relative flex flex-col justify-center items-center px-4 py-8">
      <LiquidBackground activeTab="dashboard" />

      <div className="w-full max-w-4xl grid grid-cols-1 lg:grid-cols-12 gap-6 items-center relative z-10">
        {/* Левая стеклянная витрина */}
        <div className="lg:col-span-6 space-y-6 text-center lg:text-left">
          <div className="inline-flex justify-center lg:justify-start">
            <SiDaWLogo size="lg" />
          </div>

          <div className="space-y-3">
            <h1 className="text-2xl sm:text-3xl font-bold text-white leading-tight">
              Задачи, заметки и личные финансы в эстетике Liquid Glass
            </h1>
            <p className="text-slate-300 text-sm sm:text-base leading-relaxed">
              Единая учётная запись SiDaW для вашего ПК и смартфона. Создайте аккаунт и продолжайте работу с любого устройства без потери данных.
            </p>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-left">
            <div className="p-4 rounded-2xl liquid-glass">
              <div className="flex items-center gap-2.5 text-indigo-400 font-semibold text-sm mb-1">
                <Laptop className="w-4 h-4" />
                <Smartphone className="w-4 h-4" />
                <span>ПК + Смартфон</span>
              </div>
              <p className="text-xs text-slate-400">
                Полностью одинаковые возможности и мгновенная синхронизация между устройствами.
              </p>
            </div>

            <div className="p-4 rounded-2xl liquid-glass">
              <div className="flex items-center gap-2 text-emerald-400 font-semibold text-sm mb-1">
                <ShieldCheck className="w-4 h-4" />
                <span>Приватность данных</span>
              </div>
              <p className="text-xs text-slate-400">
                Полная изоляция учётных записей, контроль активных устройств и экспорт бэкапа.
              </p>
            </div>
          </div>
        </div>

        {/* Правая карточка входа в стиле жидкого стекла */}
        <div className="lg:col-span-6">
          <div className="liquid-glass rounded-3xl p-6 sm:p-8">
            <div className="grid grid-cols-2 p-1.5 rounded-2xl liquid-glass-subtle mb-6">
              <button
                type="button"
                onClick={() => {
                  setMode('login');
                  setError(null);
                }}
                className={`py-2.5 text-sm font-semibold rounded-xl transition-all ${
                  mode === 'login'
                    ? 'liquid-btn-accent'
                    : 'text-slate-400 hover:text-white'
                }`}
              >
                Вход в аккаунт
              </button>
              <button
                type="button"
                onClick={() => {
                  setMode('register');
                  setError(null);
                }}
                className={`py-2.5 text-sm font-semibold rounded-xl transition-all ${
                  mode === 'register'
                    ? 'liquid-btn-accent'
                    : 'text-slate-400 hover:text-white'
                }`}
              >
                Регистрация
              </button>
            </div>

            {error && (
              <div className="mb-5 p-3.5 rounded-2xl bg-rose-500/15 border border-rose-500/35 flex items-start gap-2.5 text-rose-300 text-sm">
                <AlertCircle className="w-4 h-4 mt-0.5 shrink-0" />
                <span>{error}</span>
              </div>
            )}

            <form onSubmit={handleSubmit} className="space-y-4">
              {mode === 'register' && (
                <div>
                  <label className="block text-xs font-medium text-slate-300 mb-1.5">
                    Ваше имя
                  </label>
                  <div className="relative">
                    <User className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
                    <input
                      type="text"
                      required
                      value={name}
                      onChange={(e) => setName(e.target.value)}
                      placeholder="Например, Алексей"
                      className="w-full pl-10 pr-4 py-2.5 rounded-xl liquid-input text-sm"
                    />
                  </div>
                </div>
              )}

              <div>
                <label className="block text-xs font-medium text-slate-300 mb-1.5">
                  Электронная почта (логин)
                </label>
                <div className="relative">
                  <Mail className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
                  <input
                    type="email"
                    required
                    autoComplete="email"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    placeholder="you@example.com"
                    className="w-full pl-10 pr-4 py-2.5 rounded-xl liquid-input text-sm"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-medium text-slate-300 mb-1.5">
                  Пароль
                </label>
                <div className="relative">
                  <Lock className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
                  <input
                    type="password"
                    required
                    minLength={6}
                    autoComplete={mode === 'login' ? 'current-password' : 'new-password'}
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    placeholder="Минимум 6 символов"
                    className="w-full pl-10 pr-4 py-2.5 rounded-xl liquid-input text-sm"
                  />
                </div>
              </div>

              {mode === 'register' && (
                <div>
                  <label className="block text-xs font-medium text-slate-300 mb-1.5">
                    Основная валюта аккаунта
                  </label>
                  <select
                    value={defaultCurrency}
                    onChange={(e) => setDefaultCurrency(e.target.value as CurrencyCode)}
                    className="w-full px-3.5 py-2.5 rounded-xl liquid-input text-sm"
                  >
                    {CURRENCIES.map((cur) => (
                      <option key={cur} value={cur}>
                        {cur} ({CURRENCY_SYMBOLS[cur]})
                      </option>
                    ))}
                  </select>
                </div>
              )}

              <button
                type="submit"
                disabled={submitting}
                className="w-full py-3 px-4 rounded-xl liquid-btn-accent disabled:opacity-60 font-semibold text-sm flex items-center justify-center gap-2"
              >
                {submitting ? (
                  <span>Подождите...</span>
                ) : mode === 'login' ? (
                  <>
                    <CheckCircle2 className="w-4 h-4" />
                    <span>Войти в SiDaW</span>
                  </>
                ) : (
                  <>
                    <CheckCircle2 className="w-4 h-4" />
                    <span>Создать учётную запись</span>
                  </>
                )}
              </button>
            </form>
          </div>
        </div>
      </div>
    </div>
  );
}
