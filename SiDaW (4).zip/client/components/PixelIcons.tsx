import React from 'react';
import type { NavTabId } from '@shared/constants';

interface PixelIconProps {
  className?: string;
  style?: React.CSSProperties;
}

/**
 * Пиксельная иконка «Дашборд» (4 пиксельных модуля)
 */
export function PixelDashboardIcon({ className = 'w-4 h-4', style }: PixelIconProps) {
  return (
    <svg
      viewBox="0 0 16 16"
      fill="currentColor"
      shapeRendering="crispEdges"
      className={className}
      style={style}
      aria-hidden="true"
    >
      <rect x="2" y="2" width="5" height="5" />
      <rect x="9" y="2" width="5" height="3" />
      <rect x="9" y="7" width="5" height="7" />
      <rect x="2" y="9" width="5" height="5" />
    </svg>
  );
}

/**
 * Пиксельная иконка «Задачи» (пиксельная рамка + чёткая галочка)
 */
export function PixelTasksIcon({ className = 'w-4 h-4', style }: PixelIconProps) {
  return (
    <svg
      viewBox="0 0 16 16"
      fill="currentColor"
      shapeRendering="crispEdges"
      className={className}
      style={style}
      aria-hidden="true"
    >
      {/* Рамка */}
      <rect x="2" y="2" width="12" height="1" />
      <rect x="2" y="13" width="12" height="1" />
      <rect x="2" y="3" width="1" height="10" />
      <rect x="13" y="3" width="1" height="10" />
      {/* Пиксельная галочка */}
      <rect x="4" y="8" width="2" height="2" />
      <rect x="6" y="10" width="2" height="2" />
      <rect x="8" y="8" width="2" height="2" />
      <rect x="10" y="6" width="2" height="2" />
      <rect x="11" y="5" width="1" height="1" />
    </svg>
  );
}

/**
 * Пиксельная иконка «Привычки» (пиксельное пламя серии / стрик)
 */
export function PixelHabitsIcon({ className = 'w-4 h-4', style }: PixelIconProps) {
  return (
    <svg
      viewBox="0 0 16 16"
      fill="currentColor"
      shapeRendering="crispEdges"
      className={className}
      style={style}
      aria-hidden="true"
    >
      {/* Верхушка пламени */}
      <rect x="7" y="1" width="2" height="2" />
      <rect x="6" y="3" width="3" height="2" />
      <rect x="10" y="4" width="2" height="2" />
      {/* Тело пламени */}
      <rect x="4" y="5" width="7" height="3" />
      <rect x="3" y="8" width="10" height="4" />
      {/* Внутреннее ядро */}
      <rect x="6" y="9" width="4" height="3" fillOpacity="0.32" />
      {/* Основание */}
      <rect x="4" y="12" width="8" height="2" />
      <rect x="6" y="14" width="4" height="1" />
    </svg>
  );
}

/**
 * Пиксельная иконка «Заметки» (пиксельный лист с загнутым уголком и строками)
 */
export function PixelNotesIcon({ className = 'w-4 h-4', style }: PixelIconProps) {
  return (
    <svg
      viewBox="0 0 16 16"
      fill="currentColor"
      shapeRendering="crispEdges"
      className={className}
      style={style}
      aria-hidden="true"
    >
      <rect x="3" y="1" width="7" height="1" />
      <rect x="3" y="14" width="10" height="1" />
      <rect x="2" y="2" width="1" height="12" />
      <rect x="13" y="5" width="1" height="9" />
      {/* Уголок */}
      <rect x="10" y="2" width="1" height="3" />
      <rect x="11" y="3" width="1" height="2" />
      <rect x="10" y="4" width="3" height="1" />
      {/* Текстовые пиксельные линии */}
      <rect x="5" y="6" width="4" height="1" />
      <rect x="5" y="8" width="6" height="1" />
      <rect x="5" y="10" width="5" height="1" />
    </svg>
  );
}

/**
 * Пиксельная иконка «Финансы» (пиксельный кристалл-монета / кошелёк)
 */
export function PixelFinanceIcon({ className = 'w-4 h-4', style }: PixelIconProps) {
  return (
    <svg
      viewBox="0 0 16 16"
      fill="currentColor"
      shapeRendering="crispEdges"
      className={className}
      style={style}
      aria-hidden="true"
    >
      <rect x="2" y="3" width="11" height="1" />
      <rect x="2" y="12" width="11" height="1" />
      <rect x="1" y="4" width="1" height="8" />
      <rect x="13" y="4" width="1" height="2" />
      <rect x="13" y="10" width="1" height="2" />
      {/* Застёжка кошелька */}
      <rect x="10" y="6" width="5" height="4" />
      <rect x="11" y="7" width="2" height="2" fillOpacity="0.35" />
      {/* Блик */}
      <rect x="4" y="5" width="4" height="1" />
    </svg>
  );
}

/**
 * Пиксельная иконка «Аккаунт» (пиксельный силуэт персонажа)
 */
export function PixelProfileIcon({ className = 'w-4 h-4', style }: PixelIconProps) {
  return (
    <svg
      viewBox="0 0 16 16"
      fill="currentColor"
      shapeRendering="crispEdges"
      className={className}
      style={style}
      aria-hidden="true"
    >
      {/* Голова */}
      <rect x="6" y="2" width="4" height="1" />
      <rect x="5" y="3" width="6" height="4" />
      <rect x="6" y="7" width="4" height="1" />
      {/* Плечи */}
      <rect x="4" y="9" width="8" height="1" />
      <rect x="3" y="10" width="10" height="4" />
    </svg>
  );
}

/**
 * Пиксельная галочка для чекбоксов задач
 */
export function PixelCheckmark({ className = 'w-3.5 h-3.5' }: { className?: string }) {
  return (
    <svg
      viewBox="0 0 12 12"
      fill="currentColor"
      shapeRendering="crispEdges"
      className={className}
      aria-hidden="true"
    >
      <rect x="2" y="6" width="2" height="2" />
      <rect x="4" y="8" width="2" height="2" />
      <rect x="6" y="6" width="2" height="2" />
      <rect x="8" y="4" width="2" height="2" />
      <rect x="9" y="3" width="1" height="1" />
    </svg>
  );
}

/**
 * Декоративная пиксельная искра для баннеров и карточек
 */
export function PixelSpark({
  className = 'w-4 h-4',
  style,
}: PixelIconProps) {
  return (
    <svg
      viewBox="0 0 12 12"
      fill="currentColor"
      shapeRendering="crispEdges"
      className={className}
      style={style}
      aria-hidden="true"
    >
      <rect x="5" y="1" width="2" height="2" />
      <rect x="5" y="9" width="2" height="2" />
      <rect x="1" y="5" width="2" height="2" />
      <rect x="9" y="5" width="2" height="2" />
      <rect x="4" y="4" width="4" height="4" />
    </svg>
  );
}

export const PIXEL_NAV_ICONS: Record<
  NavTabId,
  React.ComponentType<PixelIconProps>
> = {
  dashboard: PixelDashboardIcon,
  tasks: PixelTasksIcon,
  habits: PixelHabitsIcon,
  notes: PixelNotesIcon,
  finance: PixelFinanceIcon,
  profile: PixelProfileIcon,
};
