import React, { memo } from 'react';
import {
  NAV_TAB_IDS,
  TAB_COLOR_THEMES,
  type BackgroundThemeId,
  type NavTabId,
} from '@shared/constants';
import { useSettings } from '../context/SettingsContext';

const SECONDARY_MOOD_RGB: Record<BackgroundThemeId, { rgb: string; strength: number }> = {
  aurora: { rgb: '56, 189, 248', strength: 0.18 },
  ocean: { rgb: '14, 165, 233', strength: 0.28 },
  sunset: { rgb: '244, 63, 94', strength: 0.25 },
  forest: { rgb: '16, 185, 129', strength: 0.25 },
  cosmic: { rgb: '139, 92, 246', strength: 0.24 },
  minimal: { rgb: '100, 116, 139', strength: 0.1 },
};

const LIGHT_TAB_BASE: Record<NavTabId, { top: string; mid: string; bottom: string }> = {
  dashboard: { top: '#d6e2ff', mid: '#e5ecff', bottom: '#dde7f8' },
  tasks: { top: '#ebd9ff', mid: '#f1e6ff', bottom: '#e6dff7' },
  habits: { top: '#c4f3fc', mid: '#dcf8fe', bottom: '#d2ebf5' },
  notes: { top: '#fde7bd', mid: '#fef2d6', bottom: '#f4e8d1' },
  finance: { top: '#c8f3e1', mid: '#dcf9ed', bottom: '#d5ece5' },
  profile: { top: '#fcd5e8', mid: '#fde4f0', bottom: '#f2dce9' },
};

/**
 * Оптимизированный GPU-фон в эстетике «Liquid Glass + Pixel Matrix».
 * При смене вкладки весь фон плавно перетекает в фирменный цвет раздела,
 * а поверх лежит чёткая пиксельная матрица без тяжёлых шейдеров размытия.
 */
export const LiquidBackground = memo(function LiquidBackground({
  activeTab = 'dashboard',
}: {
  activeTab?: NavTabId;
}) {
  const { settings, resolvedTheme } = useSettings();
  const isLight = resolvedTheme === 'light';
  const mood = SECONDARY_MOOD_RGB[settings.backgroundTheme] || SECONDARY_MOOD_RGB.aurora;
  const isMinimal = settings.backgroundTheme === 'minimal';

  return (
    <div
      className="fixed inset-0 pointer-events-none overflow-hidden -z-10 select-none"
      style={{
        backgroundColor: isLight ? '#e4ebf5' : '#050811',
      }}
      aria-hidden="true"
    >
      {/* Слои фона под каждую вкладку — плавный GPU crossfade через opacity */}
      {NAV_TAB_IDS.map((tabId) => {
        const t = TAB_COLOR_THEMES[tabId];
        const lightPalette = LIGHT_TAB_BASE[tabId];
        const isCurrent = tabId === activeTab;

        const mainAlpha = isMinimal
          ? isLight
            ? 0.18
            : 0.2
          : isLight
            ? 0.34
            : 0.44;

        const secAlpha = isMinimal
          ? isLight
            ? 0.1
            : 0.12
          : isLight
            ? 0.22
            : 0.26;

        const bgGradient = isLight
          ? `
            radial-gradient(circle at 15% 14%, rgba(${t.accentRgb}, ${mainAlpha}) 0%, rgba(${t.accentRgb}, 0.12) 40%, transparent 70%),
            radial-gradient(circle at 86% 22%, rgba(${t.secondaryRgb}, ${secAlpha}) 0%, transparent 62%),
            radial-gradient(circle at 52% 94%, rgba(${t.accentRgb}, ${secAlpha}) 0%, transparent 66%),
            linear-gradient(155deg, ${lightPalette.top} 0%, ${lightPalette.mid} 52%, ${lightPalette.bottom} 100%)
          `
          : `
            radial-gradient(circle at 18% 12%, rgba(${t.accentRgb}, ${mainAlpha}) 0%, rgba(${t.accentRgb}, 0.12) 40%, transparent 70%),
            radial-gradient(circle at 85% 22%, rgba(${t.secondaryRgb}, ${secAlpha}) 0%, transparent 62%),
            radial-gradient(circle at 48% 96%, rgba(${t.accentRgb}, ${secAlpha * 0.9}) 0%, transparent 66%),
            linear-gradient(160deg, ${t.darkBgTint} 0%, #070b16 58%, #04060d 100%)
          `;

        return (
          <div
            key={tabId}
            className="bg-tab-layer absolute inset-0"
            style={{
              background: bgGradient,
              opacity: isCurrent ? 1 : 0,
            }}
          />
        );
      })}

      {/* Оттенок выбранной в Настройках атмосферы фона */}
      <div
        className="absolute inset-0 transition-opacity duration-500"
        style={{
          background: `radial-gradient(circle at 82% 84%, rgba(${mood.rgb}, ${
            isLight ? mood.strength * 0.85 : mood.strength
          }) 0%, transparent 62%)`,
        }}
      />

      {/* Пиксельная матрица (Pixel Dot-Grid) — фирменная текстура преломления */}
      <div
        className="absolute inset-0"
        style={{
          backgroundImage: isLight
            ? `
              linear-gradient(to right, rgba(15, 23, 42, 0.035) 1px, transparent 1px),
              linear-gradient(to bottom, rgba(15, 23, 42, 0.035) 1px, transparent 1px),
              radial-gradient(rgba(var(--tab-rgb), 0.22) 1.25px, transparent 1.25px)
            `
            : `
              linear-gradient(to right, rgba(255, 255, 255, 0.022) 1px, transparent 1px),
              linear-gradient(to bottom, rgba(255, 255, 255, 0.022) 1px, transparent 1px),
              radial-gradient(rgba(var(--tab-rgb), 0.26) 1.25px, transparent 1.25px)
            `,
          backgroundSize: '64px 64px, 64px 64px, 16px 16px',
        }}
      />

      {/* Декоративные пиксельные созвездия по краям экрана */}
      <svg
        viewBox="0 0 64 64"
        shapeRendering="crispEdges"
        className="hidden sm:block absolute top-8 right-10 w-16 h-16 opacity-30"
        style={{ color: 'var(--tab-hex)' }}
      >
        <rect x="44" y="8" width="4" height="4" fill="currentColor" />
        <rect x="40" y="12" width="4" height="4" fill="currentColor" fillOpacity="0.5" />
        <rect x="48" y="12" width="4" height="4" fill="currentColor" fillOpacity="0.5" />
        <rect x="44" y="16" width="4" height="4" fill="currentColor" fillOpacity="0.5" />
        <rect x="20" y="28" width="4" height="4" fill="currentColor" fillOpacity="0.45" />
        <rect x="52" y="36" width="4" height="4" fill="currentColor" fillOpacity="0.35" />
      </svg>

      <svg
        viewBox="0 0 64 64"
        shapeRendering="crispEdges"
        className="hidden sm:block absolute bottom-10 left-10 w-16 h-16 opacity-25"
        style={{ color: 'var(--tab-hex)' }}
      >
        <rect x="12" y="40" width="4" height="4" fill="currentColor" />
        <rect x="16" y="44" width="4" height="4" fill="currentColor" fillOpacity="0.5" />
        <rect x="8" y="44" width="4" height="4" fill="currentColor" fillOpacity="0.5" />
        <rect x="12" y="48" width="4" height="4" fill="currentColor" fillOpacity="0.5" />
        <rect x="32" y="52" width="4" height="4" fill="currentColor" fillOpacity="0.4" />
      </svg>
    </div>
  );
});
