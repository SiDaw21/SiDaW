import React from 'react';
import { APP_CONFIG } from '@shared/constants';

export function SiDaWLogo({ size = 'md' }: { size?: 'sm' | 'md' | 'lg' }) {
  const boxSizes = {
    sm: 'h-8 w-8 rounded-lg',
    md: 'h-10 w-10 rounded-xl',
    lg: 'h-12 w-12 rounded-xl',
  }[size];

  const textSizes = {
    sm: 'text-base',
    md: 'text-xl',
    lg: 'text-2xl',
  }[size];

  return (
    <div className="inline-flex items-center gap-2.5 select-none">
      <div
        className={`${boxSizes} flex items-center justify-center border border-white/35 transition-all duration-300 relative`}
        style={{
          background:
            'linear-gradient(135deg, rgba(var(--tab-rgb), 0.96) 0%, rgba(14, 165, 233, 0.85) 100%)',
          boxShadow:
            'inset 0 2px 0 rgba(255,255,255,0.45), 0 3px 0 rgba(0,0,0,0.22), 0 8px 18px -4px rgba(var(--tab-rgb), 0.45)',
        }}
      >
        {/* Пиксельная монограмма «S» с кристаллической искрой */}
        <svg
          viewBox="0 0 16 16"
          shapeRendering="crispEdges"
          className="w-3/5 h-3/5"
          aria-hidden="true"
        >
          {/* Пиксельная буква S */}
          <rect x="4" y="3" width="7" height="2" fill="#ffffff" />
          <rect x="3" y="4" width="2" height="3" fill="#ffffff" />
          <rect x="4" y="7" width="7" height="2" fill="#ffffff" />
          <rect x="10" y="8" width="2" height="4" fill="#ffffff" />
          <rect x="3" y="11" width="8" height="2" fill="#ffffff" />
          {/* Пиксельный блик-искра в углу */}
          <rect x="12" y="2" width="2" height="2" fill="#bae6fd" />
        </svg>
      </div>
      <div className="flex items-baseline gap-1.5">
        <span className={`${textSizes} pixel-brand font-bold tracking-wider text-white`}>
          {APP_CONFIG.name}
        </span>
        {size !== 'sm' && (
          <span className="pixel-badge text-[9px] px-1.5 py-0.5 rounded">
            PX
          </span>
        )}
      </div>
    </div>
  );
}
