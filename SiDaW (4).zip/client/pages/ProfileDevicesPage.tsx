import React, { useCallback, useEffect, useRef, useState } from 'react';
import {
  Check,
  CheckCircle2,
  Download,
  EyeOff,
  FileDown,
  FileUp,
  KeyRound,
  Laptop,
  Layers,
  LogOut,
  Monitor,
  Moon,
  Palette,
  RefreshCw,
  RotateCcw,
  Settings,
  Shield,
  Smartphone,
  Sparkles,
  Sun,
  Trash2,
  User,
  Volume2,
} from 'lucide-react';
import {
  BACKGROUND_THEMES,
  BACKGROUND_THEME_META,
  CURRENCY_SYMBOLS,
  START_TABS,
  type BackgroundThemeId,
  type GlassIntensity,
  type StartTabId,
  type ThemeMode,
} from '@shared/constants';
import type { SessionDTO } from '@shared/schemas';
import { useAuth } from '../context/AuthContext';
import { useSettings } from '../context/SettingsContext';
import { authApi, backupApi, peekCachedGet } from '../lib/api';
import { useSyncAndPwa } from '../lib/usePwaAndSync';

export type AccountSubView = 'overview' | 'settings';

interface ProfileDevicesPageProps {
  subView: AccountSubView;
  onChangeSubView: (view: AccountSubView) => void;
}

const START_TAB_LABELS: Record<StartTabId, string> = {
  dashboard: 'Дашборд (Обзор)',
  tasks: 'Задачи',
  habits: 'Привычки',
  notes: 'Заметки',
  finance: 'Финансы',
};

function GlassSwitch({
  checked,
  onChange,
}: {
  checked: boolean;
  onChange: (next: boolean) => void;
}) {
  return (
    <button
      type="button"
      role="switch"
      aria-checked={checked}
      onClick={() => onChange(!checked)}
      className="liquid-switch"
    >
      <span className="liquid-switch-thumb" />
    </button>
  );
}

export function ProfileDevicesPage({
  subView,
  onChangeSubView,
}: ProfileDevicesPageProps) {
  const { user, logout } = useAuth();
  const { settings, updateSettings, resetSettings, playGlassSound } = useSettings();
  const { canInstallPwa, isStandalone, promptInstall } = useSyncAndPwa();

  const cachedSessions = peekCachedGet<{ sessions: SessionDTO[] }>('/api/auth/sessions');
  const [sessions, setSessions] = useState<SessionDTO[]>(
    () => cachedSessions?.sessions || []
  );
  const [loadingSessions, setLoadingSessions] = useState(() => !cachedSessions);
  const [actionMessage, setActionMessage] = useState<string | null>(null);

  // Резервное копирование
  const [exportingBackup, setExportingBackup] = useState(false);
  const [backupMessage, setBackupMessage] = useState<string | null>(null);
  const fileInputRef = useRef<HTMLInputElement | null>(null);

  // Поля смены пароля (в Настройках)
  const [currentPassword, setCurrentPassword] = useState('');
  const [newPassword, setNewPassword] = useState('');
  const [revokeOthers, setRevokeOthers] = useState(true);
  const [pwStatus, setPwStatus] = useState<{ type: 'ok' | 'err'; text: string } | null>(null);
  const [pwLoading, setPwLoading] = useState(false);

  const loadSessions = useCallback(async () => {
    setLoadingSessions(true);
    try {
      const res = await authApi.listSessions();
      setSessions(res.sessions);
    } catch {
      // ignore
    } finally {
      setLoadingSessions(false);
    }
  }, []);

  useEffect(() => {
    loadSessions();
  }, [loadSessions]);

  async function handleRevokeSession(id: string) {
    try {
      await authApi.revokeSession(id);
      setActionMessage('Устройство отключено от аккаунта');
      await loadSessions();
    } catch (err: any) {
      setActionMessage(err?.message || 'Ошибка при отключении устройства');
    }
  }

  async function handleLogoutOthers() {
    try {
      const res = await authApi.logoutOthers();
      setActionMessage(`Завершено других сессий: ${res.revokedCount}`);
      await loadSessions();
    } catch (err: any) {
      setActionMessage(err?.message || 'Не удалось завершить другие сессии');
    }
  }

  async function handleDownloadBackup() {
    setExportingBackup(true);
    setBackupMessage(null);
    try {
      const data = await backupApi.exportJson();
      const blob = new Blob([JSON.stringify(data, null, 2)], {
        type: 'application/json',
      });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      const dateStr = new Date().toISOString().slice(0, 10);
      a.href = url;
      a.download = `sidaw-backup-${dateStr}.json`;
      document.body.appendChild(a);
      a.click();
      a.remove();
      URL.revokeObjectURL(url);
      setBackupMessage('Резервная копия успешно сохранена на устройство.');
    } catch {
      setBackupMessage('Для скачивания полного бэкапа требуется соединение с сервером.');
    } finally {
      setExportingBackup(false);
    }
  }

  async function handleImportBackupFile(e: React.ChangeEvent<HTMLInputElement>) {
    const file = e.target.files?.[0];
    if (!file) return;
    setBackupMessage(null);
    try {
      const text = await file.text();
      const parsed = JSON.parse(text);
      const res = await backupApi.importJson(parsed);
      setBackupMessage(`Импорт завершён! Добавлено записей: ${res.importedCount}`);
    } catch (err: any) {
      setBackupMessage(err?.message || 'Не удалось прочитать JSON-файл резервной копии');
    } finally {
      if (fileInputRef.current) fileInputRef.current.value = '';
    }
  }

  function handleClearOfflineCache() {
    backupApi.clearOfflineCache();
    setBackupMessage('Локальный офлайн-кэш этого браузера очищен.');
  }

  async function handlePasswordChange(e: React.FormEvent) {
    e.preventDefault();
    setPwStatus(null);
    setPwLoading(true);
    try {
      await authApi.changePassword({
        currentPassword,
        newPassword,
        revokeOtherSessions: revokeOthers,
      });
      setCurrentPassword('');
      setNewPassword('');
      setPwStatus({ type: 'ok', text: 'Пароль успешно обновлён!' });
      await loadSessions();
    } catch (err: any) {
      setPwStatus({ type: 'err', text: err?.message || 'Не удалось сменить пароль' });
    } finally {
      setPwLoading(false);
    }
  }

  if (!user) return null;

  const otherSessionsCount = sessions.filter((s) => !s.isCurrent).length;

  return (
    <div className="space-y-6">
      {/* Переключатель подразделов Аккаунта со скользящей капсулой */}
      <div className="relative liquid-glass rounded-2xl p-1.5 grid grid-cols-2 max-w-md">
        <div
          aria-hidden="true"
          className="nav-sliding-pill pointer-events-none absolute top-1.5 bottom-1.5 left-1.5 w-[calc(50%-0.375rem)] rounded-xl liquid-btn-accent"
          style={{
            transform:
              subView === 'settings'
                ? 'translate3d(100%, 0, 0)'
                : 'translate3d(0%, 0, 0)',
          }}
        />

        <button
          type="button"
          onClick={() => onChangeSubView('overview')}
          className={`relative z-10 py-2.5 px-4 rounded-xl text-xs sm:text-sm font-semibold flex items-center justify-center gap-2 transition-colors duration-200 ${
            subView === 'overview'
              ? '!text-white'
              : 'text-slate-300 hover:text-white'
          }`}
        >
          <User className="w-4 h-4" />
          <span>Профиль и устройства</span>
        </button>

        <button
          type="button"
          onClick={() => onChangeSubView('settings')}
          className={`relative z-10 py-2.5 px-4 rounded-xl text-xs sm:text-sm font-semibold flex items-center justify-center gap-2 transition-colors duration-200 ${
            subView === 'settings'
              ? '!text-white'
              : 'text-slate-300 hover:text-white'
          }`}
        >
          <Settings className="w-4 h-4" />
          <span>Настройки</span>
        </button>
      </div>

      {subView === 'overview' ? (
        /* =========================================================
           ПОДРАЗДЕЛ 1: ПРОФИЛЬ И АКТИВНЫЕ УСТРОЙСТВА
           ========================================================= */
        <div key="overview" className="tab-stage-backward space-y-6">
          {/* Карточка профиля пользователя */}
          <div className="liquid-glass rounded-3xl p-6 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
            <div className="flex items-center gap-4">
              <div
                className="h-16 w-16 rounded-2xl flex items-center justify-center text-2xl pixel-brand font-bold !text-white shadow-xl shrink-0"
                style={{
                  background: 'linear-gradient(135deg, #ec4899 0%, #8b5cf6 100%)',
                }}
              >
                {user.name.slice(0, 1).toUpperCase()}
              </div>
              <div>
                <h2 className="text-xl font-bold text-white">{user.name}</h2>
                <p className="text-sm text-slate-400">{user.email}</p>
                <div className="mt-2 flex flex-wrap items-center gap-2 text-xs">
                  <span className="liquid-glass-subtle px-2.5 py-1 rounded-lg text-slate-200">
                    Валюта: {user.defaultCurrency} ({CURRENCY_SYMBOLS[user.defaultCurrency]})
                  </span>
                  <span className="liquid-glass-subtle px-2.5 py-1 rounded-lg text-slate-400">
                    В SiDaW с {new Date(user.createdAt).toLocaleDateString('ru-RU')}
                  </span>
                </div>
              </div>
            </div>
          </div>

          {/* Активные устройства (ПК и Телефоны) */}
          <div className="liquid-glass rounded-3xl p-6">
            <div className="flex flex-wrap items-center justify-between gap-3 mb-4">
              <div>
                <h3 className="text-base font-bold text-white flex items-center gap-2">
                  <Shield className="w-4 h-4 text-pink-400" />
                  <span>Активные устройства ({sessions.length})</span>
                </h3>
                <p className="text-xs text-slate-400 mt-0.5">
                  Компьютеры и смартфоны, подключённые к вашей учётной записи
                </p>
              </div>

              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={loadSessions}
                  className="p-2 rounded-xl liquid-glass-subtle text-slate-300 hover:text-white"
                  title="Обновить список устройств"
                >
                  <RefreshCw className={`w-4 h-4 ${loadingSessions ? 'animate-spin' : ''}`} />
                </button>
                {otherSessionsCount > 0 && (
                  <button
                    type="button"
                    onClick={handleLogoutOthers}
                    className="px-3 py-2 rounded-xl liquid-glass-subtle text-xs font-medium text-slate-200 hover:border-pink-500/40"
                  >
                    Отключить остальные ({otherSessionsCount})
                  </button>
                )}
              </div>
            </div>

            {actionMessage && (
              <div className="mb-4 p-3 rounded-xl bg-pink-500/15 border border-pink-500/30 text-pink-300 text-xs flex items-center gap-2">
                <CheckCircle2 className="w-4 h-4 shrink-0" />
                <span>{actionMessage}</span>
              </div>
            )}

            <div className="space-y-2.5">
              {sessions.map((s) => {
                const isMobileDevice = /Телефон|Планшет|iPhone|Android|iPad/i.test(
                  s.deviceLabel
                );
                return (
                  <div
                    key={s.id}
                    className={`flex items-center justify-between gap-3 p-3.5 rounded-2xl ${
                      s.isCurrent
                        ? 'liquid-accent-banner'
                        : 'liquid-glass-subtle'
                    }`}
                  >
                    <div className="flex items-center gap-3 min-w-0">
                      <div className="p-2.5 rounded-xl liquid-glass-subtle text-pink-400 shrink-0">
                        {isMobileDevice ? (
                          <Smartphone className="w-5 h-5" />
                        ) : (
                          <Laptop className="w-5 h-5" />
                        )}
                      </div>
                      <div className="min-w-0">
                        <div className="flex items-center gap-2 flex-wrap">
                          <span className="text-sm font-semibold text-white truncate">
                            {s.deviceLabel}
                          </span>
                          {s.isCurrent && (
                            <span className="text-[11px] font-medium px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 border border-emerald-500/30">
                              Текущее устройство
                            </span>
                          )}
                        </div>
                        <p className="text-xs text-slate-400 mt-0.5">
                          Активность: {new Date(s.lastSeenAt).toLocaleString('ru-RU')}
                        </p>
                      </div>
                    </div>

                    {!s.isCurrent && (
                      <button
                        type="button"
                        onClick={() => handleRevokeSession(s.id)}
                        className="p-2 rounded-xl text-slate-400 hover:text-rose-400 hover:bg-rose-500/10 transition-colors shrink-0"
                        title="Отключить это устройство"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    )}
                  </div>
                );
              })}
            </div>
          </div>
        </div>
      ) : (
        /* =========================================================
           ПОДРАЗДЕЛ 2: НАСТРОЙКИ ПРИЛОЖЕНИЯ (Тема, Фон, Пароль, Бэкап, Выход внизу)
           ========================================================= */
        <div key="settings" className="tab-stage-forward space-y-6">
          {/* 1. Светлая / Тёмная / Системная тема */}
          <div className="liquid-glass rounded-3xl p-6">
            <h3 className="text-base font-bold text-white flex items-center gap-2">
              <Sun className="w-4 h-4 text-pink-400" />
              <span>Тема оформления</span>
            </h3>
            <p className="text-xs text-slate-400 mt-0.5 mb-4">
              Выберите дневной пиксель-хрусталь или ночное тонированное жидкое стекло
            </p>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
              {(
                [
                  {
                    id: 'dark',
                    title: 'Тёмная',
                    desc: 'Глубокое ночное стекло',
                    icon: Moon,
                  },
                  {
                    id: 'light',
                    title: 'Светлая',
                    desc: 'Дневной пиксель-хрусталь',
                    icon: Sun,
                  },
                  {
                    id: 'system',
                    title: 'Системная',
                    desc: 'Подстраивается под ОС',
                    icon: Monitor,
                  },
                ] as { id: ThemeMode; title: string; desc: string; icon: any }[]
              ).map((item) => {
                const Icon = item.icon;
                const active = settings.themeMode === item.id;
                return (
                  <button
                    key={item.id}
                    type="button"
                    onClick={() => updateSettings({ themeMode: item.id })}
                    className={`p-4 rounded-2xl text-left transition-all flex items-start justify-between gap-3 ${
                      active
                        ? 'liquid-accent-banner'
                        : 'liquid-glass-subtle hover:border-white/25'
                    }`}
                  >
                    <div>
                      <div className="flex items-center gap-2">
                        <Icon className="w-4 h-4 text-pink-400" />
                        <span className="text-sm font-bold text-white">{item.title}</span>
                      </div>
                      <p className="text-xs text-slate-400 mt-1">{item.desc}</p>
                    </div>
                    {active && (
                      <span className="h-5 w-5 rounded-[4px] bg-pink-500 !text-white flex items-center justify-center shrink-0">
                        <Check className="w-3 h-3" />
                      </span>
                    )}
                  </button>
                );
              })}
            </div>
          </div>

          {/* 2. Выбор тематики заднего фона */}
          <div className="liquid-glass rounded-3xl p-6">
            <h3 className="text-base font-bold text-white flex items-center gap-2">
              <Palette className="w-4 h-4 text-pink-400" />
              <span>Тематика заднего фона</span>
            </h3>
            <p className="text-xs text-slate-400 mt-0.5 mb-4">
              Фоновая атмосфера мягко преломляется сквозь стеклянные панели всех разделов
            </p>

            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3.5">
              {BACKGROUND_THEMES.map((bgId: BackgroundThemeId) => {
                const meta = BACKGROUND_THEME_META[bgId];
                const isSelected = settings.backgroundTheme === bgId;

                return (
                  <button
                    key={bgId}
                    type="button"
                    onClick={() => updateSettings({ backgroundTheme: bgId })}
                    className={`group rounded-2xl p-3 text-left transition-all ${
                      isSelected
                        ? 'liquid-accent-banner scale-[1.01]'
                        : 'liquid-glass-subtle hover:border-white/25'
                    }`}
                  >
                    <div
                      className="h-16 w-full rounded-xl mb-3 relative overflow-hidden border border-white/20 shadow-inner"
                      style={{ background: meta.previewGradient }}
                    >
                      <div className="absolute inset-2 rounded-lg bg-black/25 backdrop-blur-sm border border-white/30 flex items-center justify-between px-3">
                        <span className="pixel-brand text-[10px] font-bold !text-white drop-shadow">
                          PIXEL // GLASS
                        </span>
                        {isSelected && (
                          <span className="h-5 w-5 rounded-[4px] bg-white text-slate-900 flex items-center justify-center shadow">
                            <Check className="w-3 h-3" />
                          </span>
                        )}
                      </div>
                    </div>

                    <p className="text-sm font-bold text-white">{meta.label}</p>
                    <p className="text-[11px] text-slate-400 mt-0.5 leading-snug">
                      {meta.description}
                    </p>
                  </button>
                );
              })}
            </div>
          </div>

          {/* 3. Настройки «Жидкого стекла» и персонализация интерфейса */}
          <div className="liquid-glass rounded-3xl p-6 space-y-5">
            <div>
              <h3 className="text-base font-bold text-white flex items-center gap-2">
                <Layers className="w-4 h-4 text-pink-400" />
                <span>Эффект «Жидкого стекла» и интерфейс</span>
              </h3>
              <p className="text-xs text-slate-400 mt-0.5">
                Тонкая настройка глубины размытия, анимации и поведения приложения
              </p>
            </div>

            {/* Прозрачность и производительность стекла */}
            <div>
              <label className="block text-xs font-medium text-slate-300 mb-2">
                Режим стекла и производительность
              </label>
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5">
                {(
                  [
                    { id: 'clear', label: 'Прозрачный кристалл' },
                    { id: 'balanced', label: 'Сбалансированное' },
                    { id: 'frosted', label: 'Матовый лёд' },
                    { id: 'performance', label: '⚡ Турбо (Макс. FPS)' },
                  ] as { id: GlassIntensity; label: string }[]
                ).map((g) => (
                  <button
                    key={g.id}
                    type="button"
                    onClick={() => updateSettings({ glassIntensity: g.id })}
                    className={`py-2.5 px-3 rounded-xl text-xs font-medium transition-all ${
                      settings.glassIntensity === g.id
                        ? 'liquid-btn-accent'
                        : 'liquid-glass-subtle text-slate-300'
                    }`}
                  >
                    {g.label}
                  </button>
                ))}
              </div>
            </div>

            {/* Стартовая вкладка */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-1">
              <div>
                <label className="block text-xs font-medium text-slate-300 mb-1.5">
                  Стартовая вкладка при открытии SiDaW
                </label>
                <select
                  value={settings.startTab}
                  onChange={(e) =>
                    updateSettings({ startTab: e.target.value as StartTabId })
                  }
                  className="w-full px-3.5 py-2.5 rounded-xl liquid-input text-sm"
                >
                  {START_TABS.map((t) => (
                    <option key={t} value={t}>
                      {START_TAB_LABELS[t]}
                    </option>
                  ))}
                </select>
              </div>
            </div>

            {/* Переключатели (Приватность, Копейки, Компактность, Анимация, Звук) */}
            <div className="divide-y divide-white/10 pt-1">
              <div className="py-3.5 flex items-center justify-between gap-4">
                <div className="flex items-start gap-3">
                  <EyeOff className="w-4 h-4 text-pink-400 mt-0.5 shrink-0" />
                  <div>
                    <p className="text-sm font-semibold text-white">
                      Скрывать финансовые балансы («Режим в людных местах»)
                    </p>
                    <p className="text-xs text-slate-400">
                      Маскирует суммы значками •••• на Дашборде и в Финансах
                    </p>
                  </div>
                </div>
                <GlassSwitch
                  checked={settings.hideBalances}
                  onChange={(val) => updateSettings({ hideBalances: val })}
                />
              </div>

              <div className="py-3.5 flex items-center justify-between gap-4">
                <div className="flex items-start gap-3">
                  <Sparkles className="w-4 h-4 text-pink-400 mt-0.5 shrink-0" />
                  <div>
                    <p className="text-sm font-semibold text-white">
                      Показывать копейки / центы в суммах
                    </p>
                    <p className="text-xs text-slate-400">
                      Если выключить — суммы округляются до целых чисел для более чистого вида
                    </p>
                  </div>
                </div>
                <GlassSwitch
                  checked={settings.showCents}
                  onChange={(val) => updateSettings({ showCents: val })}
                />
              </div>

              <div className="py-3.5 flex items-center justify-between gap-4">
                <div className="flex items-start gap-3">
                  <Volume2 className="w-4 h-4 text-pink-400 mt-0.5 shrink-0" />
                  <div>
                    <p className="text-sm font-semibold text-white">
                      Стеклянный звуковой отклик при выполнении задач
                    </p>
                    <p className="text-xs text-slate-400">
                      Мягкий кристальный звук при отметке задачи выполненной
                    </p>
                  </div>
                </div>
                <GlassSwitch
                  checked={settings.soundEffects}
                  onChange={(val) => {
                    updateSettings({ soundEffects: val });
                    if (val) setTimeout(() => playGlassSound(), 60);
                  }}
                />
              </div>

              <div className="py-3.5 flex items-center justify-between gap-4">
                <div>
                  <p className="text-sm font-semibold text-white">
                    Компактный режим карточек
                  </p>
                  <p className="text-xs text-slate-400">
                    Уменьшает внутренние отступы, чтобы на экране помещалось больше записей
                  </p>
                </div>
                <GlassSwitch
                  checked={settings.compactMode}
                  onChange={(val) => updateSettings({ compactMode: val })}
                />
              </div>

              <div className="py-3.5 flex items-center justify-between gap-4">
                <div>
                  <p className="text-sm font-semibold text-white">
                    Плавные анимации переходов и цвета фона
                  </p>
                  <p className="text-xs text-slate-400">
                    Мягкое скольжение вкладок, перетекание оттенка фона и пружинные ползунки
                  </p>
                </div>
                <GlassSwitch
                  checked={settings.animationsEnabled}
                  onChange={(val) => updateSettings({ animationsEnabled: val })}
                />
              </div>
            </div>

            <div className="pt-1 flex justify-end">
              <button
                type="button"
                onClick={resetSettings}
                className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-xl liquid-glass-subtle text-xs text-slate-300 hover:text-white"
              >
                <RotateCcw className="w-3.5 h-3.5" />
                <span>Сбросить оформление по умолчанию</span>
              </button>
            </div>
          </div>

          {/* 4. Безопасность: Смена пароля (перенесено в Настройки) */}
          <div className="liquid-glass rounded-3xl p-6">
            <h3 className="text-base font-bold text-white flex items-center gap-2">
              <KeyRound className="w-4 h-4 text-pink-400" />
              <span>Безопасность и смена пароля</span>
            </h3>
            <p className="text-xs text-slate-400 mt-0.5 mb-4">
              Защитите учётную запись и при необходимости сбросьте вход на других устройствах
            </p>

            {pwStatus && (
              <div
                className={`mb-4 p-3 rounded-xl text-xs border ${
                  pwStatus.type === 'ok'
                    ? 'bg-emerald-500/15 border-emerald-500/30 text-emerald-300'
                    : 'bg-rose-500/15 border-rose-500/30 text-rose-300'
                }`}
              >
                {pwStatus.text}
              </div>
            )}

            <form onSubmit={handlePasswordChange} className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block text-xs text-slate-300 mb-1.5">Текущий пароль</label>
                <input
                  type="password"
                  required
                  value={currentPassword}
                  onChange={(e) => setCurrentPassword(e.target.value)}
                  className="w-full px-3.5 py-2.5 rounded-xl liquid-input text-sm"
                />
              </div>
              <div>
                <label className="block text-xs text-slate-300 mb-1.5">
                  Новый пароль (мин. 6 символов)
                </label>
                <input
                  type="password"
                  required
                  minLength={6}
                  value={newPassword}
                  onChange={(e) => setNewPassword(e.target.value)}
                  className="w-full px-3.5 py-2.5 rounded-xl liquid-input text-sm"
                />
              </div>

              <div className="sm:col-span-2 flex flex-col sm:flex-row sm:items-center justify-between gap-3 pt-1">
                <label className="inline-flex items-center gap-2 text-xs text-slate-300 cursor-pointer select-none">
                  <input
                    type="checkbox"
                    checked={revokeOthers}
                    onChange={(e) => setRevokeOthers(e.target.checked)}
                    className="rounded border-slate-500 text-pink-500 focus:ring-pink-500"
                  />
                  <span>Выйти со всех остальных устройств после смены пароля</span>
                </label>

                <button
                  type="submit"
                  disabled={pwLoading}
                  className="px-5 py-2.5 rounded-xl liquid-btn-accent disabled:opacity-60 text-sm font-medium"
                >
                  {pwLoading ? 'Сохранение...' : 'Обновить пароль'}
                </button>
              </div>
            </form>
          </div>

          {/* 5. Установка PWA на ПК и телефон */}
          <div className="liquid-glass rounded-3xl p-6">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 mb-4">
              <div>
                <h3 className="text-base font-bold text-white flex items-center gap-2">
                  <Download className="w-4 h-4 text-pink-400" />
                  <span>Установка приложения на ПК и смартфон</span>
                </h3>
                <p className="text-xs text-slate-400 mt-0.5">
                  Работает в отдельном окне без рамок браузера с поддержкой офлайн-режима
                </p>
              </div>

              {isStandalone ? (
                <span className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-emerald-500/15 border border-emerald-500/30 text-emerald-300 text-xs font-medium">
                  <CheckCircle2 className="w-4 h-4" />
                  <span>Установлено</span>
                </span>
              ) : (
                canInstallPwa && (
                  <button
                    type="button"
                    onClick={promptInstall}
                    className="px-4 py-2.5 rounded-xl liquid-btn-accent text-xs font-semibold inline-flex items-center gap-2 shrink-0"
                  >
                    <Download className="w-4 h-4" />
                    <span>Установить в 1 клик</span>
                  </button>
                )
              )}
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-3 text-xs">
              <div className="p-3.5 rounded-2xl liquid-glass-subtle">
                <p className="font-semibold text-white mb-1">ПК (Windows / Mac / Linux)</p>
                <p className="text-slate-400">
                  В Chrome или Edge нажмите значок установки справа в адресной строке.
                </p>
              </div>
              <div className="p-3.5 rounded-2xl liquid-glass-subtle">
                <p className="font-semibold text-white mb-1">Android (Chrome)</p>
                <p className="text-slate-400">
                  Откройте меню «⋮» → «Установить приложение» на главный экран.
                </p>
              </div>
              <div className="p-3.5 rounded-2xl liquid-glass-subtle">
                <p className="font-semibold text-white mb-1">iPhone / iPad (Safari)</p>
                <p className="text-slate-400">
                  Нажмите «Поделиться» внизу → выберите «На экран „Домой“».
                </p>
              </div>
            </div>
          </div>

          {/* 6. Резервное копирование и управление данными */}
          <div className="liquid-glass rounded-3xl p-6">
            <h3 className="text-base font-bold text-white flex items-center gap-2">
              <FileDown className="w-4 h-4 text-pink-400" />
              <span>Резервная копия и данные</span>
            </h3>
            <p className="text-xs text-slate-400 mt-0.5 mb-4">
              Скачайте копию своих задач, заметок, счетов и операций в один JSON-файл или восстановите их
            </p>

            {backupMessage && (
              <div className="mb-4 p-3 rounded-xl bg-indigo-500/15 border border-indigo-500/30 text-indigo-300 text-xs">
                {backupMessage}
              </div>
            )}

            <div className="flex flex-wrap items-center gap-3">
              <button
                type="button"
                onClick={handleDownloadBackup}
                disabled={exportingBackup}
                className="inline-flex items-center gap-2 px-4 py-2.5 rounded-xl liquid-btn-accent text-xs sm:text-sm font-semibold"
              >
                <FileDown className="w-4 h-4" />
                <span>{exportingBackup ? 'Подготовка файла...' : 'Скачать JSON-бэкап'}</span>
              </button>

              <input
                ref={fileInputRef}
                type="file"
                accept="application/json,.json"
                onChange={handleImportBackupFile}
                className="hidden"
              />
              <button
                type="button"
                onClick={() => fileInputRef.current?.click()}
                className="inline-flex items-center gap-2 px-4 py-2.5 rounded-xl liquid-glass-subtle hover:border-white/25 text-xs sm:text-sm font-medium text-slate-200"
              >
                <FileUp className="w-4 h-4 text-sky-400" />
                <span>Восстановить из бэкапа</span>
              </button>

              <button
                type="button"
                onClick={handleClearOfflineCache}
                className="inline-flex items-center gap-2 px-4 py-2.5 rounded-xl liquid-glass-subtle hover:border-white/25 text-xs sm:text-sm font-medium text-slate-300"
              >
                <Trash2 className="w-4 h-4 text-amber-400" />
                <span>Очистить офлайн-кэш</span>
              </button>
            </div>
          </div>

          {/* 7. В САМОМ НИЗУ НАСТРОЕК: Плашка выхода из учётной записи */}
          <div
            className="liquid-glass rounded-3xl p-5 sm:p-6 border !border-rose-500/35 flex flex-col sm:flex-row sm:items-center justify-between gap-4"
            style={{
              background:
                'linear-gradient(135deg, rgba(244, 63, 94, 0.16) 0%, rgba(244, 63, 94, 0.04) 100%)',
            }}
          >
            <div>
              <h3 className="text-base font-bold text-white">Выход из учётной записи</h3>
              <p className="text-xs text-slate-300 mt-0.5">
                Завершить текущую сессию аккаунта <span className="font-semibold">{user.email}</span> на этом устройстве
              </p>
            </div>

            <button
              type="button"
              onClick={logout}
              className="inline-flex items-center justify-center gap-2 px-5 py-3 rounded-2xl bg-rose-600 hover:bg-rose-500 !text-white text-sm font-semibold shadow-lg shadow-rose-600/30 transition-all shrink-0"
            >
              <LogOut className="w-4 h-4" />
              <span>Выйти из аккаунта</span>
            </button>
          </div>
        </div>
      )}
    </div>
  );
}
