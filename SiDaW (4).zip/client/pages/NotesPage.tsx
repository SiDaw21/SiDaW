import React, { useCallback, useEffect, useMemo, useState } from 'react';
import {
  Edit3,
  Pin,
  Plus,
  Search,
  Trash2,
  X,
} from 'lucide-react';
import { NOTE_COLORS, type NoteColor } from '@shared/constants';
import type { NoteDTO } from '@shared/schemas';
import { notesApi, peekCachedGet } from '../lib/api';

const COLOR_TINT_STYLES: Record<NoteColor, string> = {
  default: '',
  amber: 'border-amber-400/35 bg-amber-500/10',
  emerald: 'border-emerald-400/35 bg-emerald-500/10',
  sky: 'border-sky-400/35 bg-sky-500/10',
  violet: 'border-violet-400/35 bg-violet-500/10',
  rose: 'border-rose-400/35 bg-rose-500/10',
};

const COLOR_SWATCH: Record<NoteColor, string> = {
  default: 'bg-slate-500',
  amber: 'bg-amber-500',
  emerald: 'bg-emerald-500',
  sky: 'bg-sky-500',
  violet: 'bg-violet-500',
  rose: 'bg-rose-500',
};

export function NotesPage() {
  const initialNotes = peekCachedGet<{ notes: NoteDTO[] }>('/api/notes');
  const [notes, setNotes] = useState<NoteDTO[]>(() => initialNotes?.notes || []);
  const [loading, setLoading] = useState(() => !initialNotes);
  const [searchQuery, setSearchQuery] = useState('');
  const [activeTag, setActiveTag] = useState<string | null>(null);

  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingNote, setEditingNote] = useState<NoteDTO | null>(null);
  const [formError, setFormError] = useState<string | null>(null);

  const [title, setTitle] = useState('');
  const [content, setContent] = useState('');
  const [tagsText, setTagsText] = useState('');
  const [color, setColor] = useState<NoteColor>('default');
  const [isPinned, setIsPinned] = useState(false);

  const loadNotes = useCallback(async () => {
    try {
      const res = await notesApi.list();
      setNotes(res.notes);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    loadNotes();
    const onSynced = () => loadNotes();
    window.addEventListener('sidaw:synced', onSynced);
    return () => window.removeEventListener('sidaw:synced', onSynced);
  }, [loadNotes]);

  const allTags = useMemo(() => {
    const s = new Set<string>();
    notes.forEach((n) => n.tags.forEach((t) => s.add(t)));
    return Array.from(s);
  }, [notes]);

  const filteredNotes = useMemo(() => {
    return notes.filter((n) => {
      if (activeTag && !n.tags.includes(activeTag)) return false;
      if (searchQuery.trim()) {
        const q = searchQuery.toLowerCase();
        const hay = `${n.title} ${n.content} ${n.tags.join(' ')}`.toLowerCase();
        if (!hay.includes(q)) return false;
      }
      return true;
    });
  }, [notes, activeTag, searchQuery]);

  function openCreate() {
    setEditingNote(null);
    setTitle('');
    setContent('');
    setTagsText('');
    setColor('amber');
    setIsPinned(false);
    setIsModalOpen(true);
  }

  function openEdit(note: NoteDTO) {
    setEditingNote(note);
    setTitle(note.title);
    setContent(note.content);
    setTagsText(note.tags.join(', '));
    setColor(note.color);
    setIsPinned(note.isPinned);
    setIsModalOpen(true);
  }

  async function handleSave(e: React.FormEvent) {
    e.preventDefault();
    if (!title.trim()) return;
    setFormError(null);

    try {
      const parsedTags = tagsText
        .split(',')
        .map((t) => t.trim().replace(/^#/, ''))
        .filter(Boolean)
        .slice(0, 12);

      const payload = {
        title: title.trim(),
        content,
        tags: parsedTags,
        color,
        isPinned,
      };

      if (editingNote) {
        await notesApi.update(editingNote.id, payload);
      } else {
        await notesApi.create(payload);
      }

      setIsModalOpen(false);
      await loadNotes();
    } catch (err: any) {
      setFormError(err?.message || 'Не удалось сохранить заметку');
    }
  }

  async function togglePin(note: NoteDTO, e: React.MouseEvent) {
    e.stopPropagation();
    await notesApi.update(note.id, { isPinned: !note.isPinned });
    await loadNotes();
  }

  async function removeNote(id: string, e: React.MouseEvent) {
    e.stopPropagation();
    await notesApi.remove(id);
    await loadNotes();
  }

  return (
    <div className="space-y-5">
      {/* Панель поиска и создания заметки (фирменный цвет вкладки: Янтарь #f59e0b) */}
      <div className="liquid-glass rounded-3xl p-4 sm:p-5 space-y-3">
        <div className="flex flex-col sm:flex-row gap-3 justify-between">
          <div className="relative flex-1">
            <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Поиск заметок по заголовку, тексту или #тегу..."
              className="w-full pl-10 pr-4 py-2.5 rounded-xl liquid-input text-sm"
            />
          </div>
          <button
            type="button"
            onClick={openCreate}
            className="inline-flex items-center justify-center gap-2 px-4 py-2.5 rounded-xl liquid-btn-accent text-sm font-semibold shrink-0"
          >
            <Plus className="w-4 h-4" />
            <span>Новая заметка</span>
          </button>
        </div>

        {allTags.length > 0 && (
          <div className="flex flex-wrap items-center gap-1.5 pt-1">
            <button
              type="button"
              onClick={() => setActiveTag(null)}
              className={`px-3 py-1 rounded-full text-xs font-medium transition-all ${
                activeTag === null
                  ? 'liquid-btn-accent'
                  : 'liquid-glass-subtle text-slate-300 hover:text-white'
              }`}
            >
              Все теги
            </button>
            {allTags.map((tag) => (
              <button
                key={tag}
                type="button"
                onClick={() => setActiveTag(activeTag === tag ? null : tag)}
                className={`px-3 py-1 rounded-full text-xs font-medium transition-all ${
                  activeTag === tag
                    ? 'liquid-btn-accent'
                    : 'liquid-glass-subtle text-slate-300 hover:text-white'
                }`}
              >
                #{tag}
              </button>
            ))}
          </div>
        )}
      </div>

      {/* Сетка стеклянных заметок */}
      {loading ? (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {[1, 2, 3].map((i) => (
            <div key={i} className="h-44 rounded-3xl liquid-glass animate-pulse" />
          ))}
        </div>
      ) : filteredNotes.length === 0 ? (
        <div className="text-center py-14 rounded-3xl liquid-glass">
          <p className="text-slate-200 font-semibold">Заметок не найдено</p>
          <p className="text-xs text-slate-400 mt-1">
            Нажмите «Новая заметка», чтобы сохранить мысль, конспект или чек-лист
          </p>
        </div>
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {filteredNotes.map((note) => (
            <div
              key={note.id}
              onClick={() => openEdit(note)}
              className={`group cursor-pointer rounded-3xl liquid-glass p-5 flex flex-col justify-between transition-all hover:-translate-y-0.5 hover:border-amber-400/50 ${
                COLOR_TINT_STYLES[note.color] || ''
              }`}
            >
              <div>
                <div className="flex items-start justify-between gap-2">
                  <h3 className="text-base font-bold text-white line-clamp-2">
                    {note.title}
                  </h3>
                  <div className="flex items-center gap-1 shrink-0">
                    <button
                      type="button"
                      onClick={(e) => togglePin(note, e)}
                      title={note.isPinned ? 'Открепить' : 'Закрепить'}
                      className={`p-1.5 rounded-lg transition-colors ${
                        note.isPinned
                          ? 'text-amber-400 bg-amber-500/15'
                          : 'text-slate-400 hover:text-amber-400 hover:bg-white/10'
                      }`}
                    >
                      <Pin className="w-3.5 h-3.5" />
                    </button>
                    <button
                      type="button"
                      onClick={(e) => removeNote(note.id, e)}
                      title="Удалить"
                      className="p-1.5 rounded-lg text-slate-400 hover:text-rose-400 hover:bg-rose-500/10 transition-colors"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>

                <p className="text-sm text-slate-300 mt-2.5 whitespace-pre-line line-clamp-6">
                  {note.content || 'Нет текста...'}
                </p>
              </div>

              <div className="mt-4 pt-3 border-t border-white/10 flex items-center justify-between gap-2">
                <div className="flex flex-wrap gap-1">
                  {note.tags.map((t) => (
                    <span
                      key={t}
                      className="text-[11px] px-2 py-0.5 rounded-md bg-amber-500/15 text-amber-400"
                    >
                      #{t}
                    </span>
                  ))}
                </div>
                <span className="text-[10px] text-slate-400 flex items-center gap-1 shrink-0">
                  <Edit3 className="w-3 h-3" />
                  {new Date(note.updatedAt).toLocaleDateString('ru-RU')}
                </span>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* Стеклянное модальное окно редактора заметки */}
      {isModalOpen && (
        <div className="fixed inset-0 z-50 bg-black/55 backdrop-blur-md flex items-center justify-center p-4">
          <div className="w-full max-w-xl liquid-glass rounded-3xl p-6">
            <div className="flex items-center justify-between mb-4">
              <h2 className="text-lg font-bold text-white">
                {editingNote ? 'Редактирование заметки' : 'Новая заметка'}
              </h2>
              <button
                type="button"
                onClick={() => setIsModalOpen(false)}
                className="p-1.5 rounded-xl text-slate-400 hover:text-white hover:bg-white/10"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSave} className="space-y-4">
              {formError && (
                <div className="p-3 rounded-xl bg-rose-500/15 border border-rose-500/30 text-rose-300 text-xs">
                  {formError}
                </div>
              )}
              <div>
                <label className="block text-xs font-medium text-slate-300 mb-1">
                  Заголовок
                </label>
                <input
                  type="text"
                  required
                  autoFocus
                  value={title}
                  onChange={(e) => setTitle(e.target.value)}
                  placeholder="Название заметки..."
                  className="w-full px-3.5 py-2.5 rounded-xl liquid-input text-sm"
                />
              </div>

              <div>
                <label className="block text-xs font-medium text-slate-300 mb-1">
                  Содержимое
                </label>
                <textarea
                  rows={8}
                  value={content}
                  onChange={(e) => setContent(e.target.value)}
                  placeholder="Пишите мысли, списки, ссылки или заметки со встреч..."
                  className="w-full px-3.5 py-2.5 rounded-xl liquid-input text-sm"
                />
              </div>

              <div>
                <label className="block text-xs font-medium text-slate-300 mb-1">
                  Теги через запятую
                </label>
                <input
                  type="text"
                  value={tagsText}
                  onChange={(e) => setTagsText(e.target.value)}
                  placeholder="идеи, работа, покупки"
                  className="w-full px-3.5 py-2.5 rounded-xl liquid-input text-sm"
                />
              </div>

              <div className="flex flex-wrap items-center justify-between gap-4 pt-1">
                <div className="flex items-center gap-2">
                  <span className="text-xs text-slate-300">Оттенок стекла:</span>
                  {NOTE_COLORS.map((c) => (
                    <button
                      key={c}
                      type="button"
                      onClick={() => setColor(c)}
                      className={`h-6 w-6 rounded-full ${COLOR_SWATCH[c]} transition-transform ${
                        color === c ? 'ring-2 ring-white scale-110' : 'opacity-65 hover:opacity-100'
                      }`}
                    />
                  ))}
                </div>

                <label className="inline-flex items-center gap-2 text-xs text-slate-200 cursor-pointer select-none">
                  <input
                    type="checkbox"
                    checked={isPinned}
                    onChange={(e) => setIsPinned(e.target.checked)}
                    className="rounded border-slate-500 text-amber-500 focus:ring-amber-500"
                  />
                  <span>Закрепить наверху</span>
                </label>
              </div>

              <div className="flex justify-end gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setIsModalOpen(false)}
                  className="px-4 py-2.5 rounded-xl liquid-glass-subtle text-slate-300 text-sm font-medium"
                >
                  Отмена
                </button>
                <button
                  type="submit"
                  className="px-5 py-2.5 rounded-xl liquid-btn-accent text-sm font-semibold"
                >
                  Сохранить заметку
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
