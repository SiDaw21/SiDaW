import React, { useCallback, useEffect, useMemo, useState } from 'react';
import {
  Edit3,
  Flame,
  Plus,
  Trophy,
  Trash2,
  X,
} from 'lucide-react';
import { HABIT_COLORS, type HabitColor } from '@shared/constants';
import type { HabitDTO } from '@shared/schemas';
import { PixelCheckmark } from '../components/PixelIcons';
import { useSettings } from '../context/SettingsContext';
import { habitsApi, peekCachedGet } from '../lib/api';

const HABIT_COLOR_META: Record<
  HabitColor,
  { hex: string; swatch: string; badge: string }
> = {
  cyan: {
    hex: '#06b6d4',
    swatch: 'bg-cyan-500',
    badge: 'bg-cyan-500/15 text-cyan-400',
  },
  emerald: {
    hex: '#10b981',
    swatch: 'bg-emerald-500',
    badge: 'bg-emerald-500/15 text-emerald-400',
  },
  violet: {
    hex: '#a855f7',
    swatch: 'bg-violet-500',
    badge: 'bg-violet-500/15 text-violet-400',
  },
  amber: {
    hex: '#f59e0b',
    swatch: 'bg-amber-500',
    badge: 'bg-amber-500/15 text-amber-400',
  },
  rose: {
    hex: '#f43f5e',
    swatch: 'bg-rose-500',
    badge: 'bg-rose-500/15 text-rose-400',
  },
  indigo: {
    hex: '#6366f1',
    swatch: 'bg-indigo-500',
    badge: 'bg-indigo-500/15 text-indigo-400',
  },
};

const WEEKDAY_SHORT = ['Вс', 'Пн', 'Вт', 'Ср', 'Чт', 'Пт', 'Сб'];

function getPastDaysIso(daysCount: number): { iso: string; dayNum: string; weekday: string }[] {
  const result: { iso: string; dayNum: string; weekday: string }[] = [];
  const now = new Date();
  for (let i = daysCount - 1; i >= 0; i--) {
    const d = new Date(
      Date.UTC(now.getUTCFullYear(), now.getUTCMonth(), now.getUTCDate() - i)
    );
    const iso = d.toISOString().slice(0, 10);
    result.push({
      iso,
      dayNum: iso.slice(8, 10),
      weekday: WEEKDAY_SHORT[d.getUTCDay()],
    });
  }
  return result;
}

export function HabitsPage() {
  const { playGlassSound } = useSettings();
  const initialHabits = peekCachedGet<{ habits: HabitDTO[] }>('/api/habits');
  const [habits, setHabits] = useState<HabitDTO[]>(() => initialHabits?.habits || []);
  const [loading, setLoading] = useState(() => !initialHabits);

  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingHabit, setEditingHabit] = useState<HabitDTO | null>(null);
  const [formError, setFormError] = useState<string | null>(null);
  const [saving, setSaving] = useState(false);

  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [color, setColor] = useState<HabitColor>('cyan');
  const [targetDaysPerWeek, setTargetDaysPerWeek] = useState(7);

  const loadHabits = useCallback(async () => {
    try {
      const res = await habitsApi.list();
      setHabits(res.habits);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    loadHabits();
    const onSynced = () => loadHabits();
    window.addEventListener('sidaw:synced', onSynced);
    return () => window.removeEventListener('sidaw:synced', onSynced);
  }, [loadHabits]);

  const todayIso = useMemo(() => new Date().toISOString().slice(0, 10), []);
  const last7Days = useMemo(() => getPastDaysIso(7), []);
  const last28Days = useMemo(() => getPastDaysIso(28), []);

  const completedTodayCount = useMemo(
    () => habits.filter((h) => h.completedDates.includes(todayIso)).length,
    [habits, todayIso]
  );

  const bestCurrentStreak = useMemo(
    () => habits.reduce((m, h) => (h.currentStreak > m ? h.currentStreak : m), 0),
    [habits]
  );

  const todayPct =
    habits.length > 0 ? Math.round((completedTodayCount / habits.length) * 100) : 0;

  function openCreateModal() {
    setEditingHabit(null);
    setTitle('');
    setDescription('');
    setColor('cyan');
    setTargetDaysPerWeek(7);
    setFormError(null);
    setIsModalOpen(true);
  }

  function openEditModal(habit: HabitDTO) {
    setEditingHabit(habit);
    setTitle(habit.title);
    setDescription(habit.description);
    setColor(habit.color);
    setTargetDaysPerWeek(habit.targetDaysPerWeek);
    setFormError(null);
    setIsModalOpen(true);
  }

  async function handleSave(e: React.FormEvent) {
    e.preventDefault();
    if (!title.trim()) return;
    setFormError(null);
    setSaving(true);

    try {
      const payload = {
        title: title.trim(),
        description: description.trim(),
        color,
        targetDaysPerWeek,
      };

      if (editingHabit) {
        await habitsApi.update(editingHabit.id, payload);
      } else {
        await habitsApi.create(payload);
      }

      setIsModalOpen(false);
      await loadHabits();
    } catch (err: any) {
      setFormError(err?.message || 'Не удалось сохранить привычку');
    } finally {
      setSaving(false);
    }
  }

  async function handleToggleDate(habit: HabitDTO, dateIso: string) {
    const wasCompleted = habit.completedDates.includes(dateIso);
    if (!wasCompleted) {
      playGlassSound();
    }
    try {
      const res = await habitsApi.toggleDate(habit.id, dateIso);
      if (res.habit) {
        setHabits((prev) =>
          prev.map((h) => (h.id === habit.id ? res.habit : h))
        );
      } else {
        await loadHabits();
      }
    } catch {
      await loadHabits();
    }
  }

  async function handleDelete(id: string) {
    if (!window.confirm('Удалить эту привычку и всю историю её отметок?')) return;
    await habitsApi.remove(id);
    await loadHabits();
  }

  return (
    <div className="space-y-6">
      {/* Верхний баннер прогресса привычек (цвет вкладки: Топаз / Циан #06b6d4) */}
      <div className="liquid-accent-banner rounded-3xl p-5 sm:p-6 space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div>
            <span className="pixel-badge inline-block text-[10px] px-2 py-0.5 rounded mb-2">
              ТОПАЗ // ТРЕКЕР ПРИВЫЧЕК
            </span>
            <h2 className="text-xl sm:text-2xl font-bold text-white">
              Ежедневная дисциплина и серии
            </h2>
            <p className="text-xs sm:text-sm text-slate-300 mt-1">
              Отмечайте привычки в 1 клик, копите непрерывные серии и следите за пиксельной картой регулярности
            </p>
          </div>

          <button
            type="button"
            onClick={openCreateModal}
            className="inline-flex items-center justify-center gap-2 px-4 py-2.5 rounded-xl liquid-btn-accent text-sm font-semibold shrink-0"
          >
            <Plus className="w-4 h-4" />
            <span>Новая привычка</span>
          </button>
        </div>

        {/* Полоса дневного прогресса */}
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 pt-1">
          <div className="sm:col-span-2 p-3.5 rounded-2xl liquid-glass-subtle flex flex-col justify-center">
            <div className="flex items-center justify-between text-xs mb-1.5">
              <span className="font-semibold text-white">
                Прогресс на сегодня ({todayIso})
              </span>
              <span className="pixel-num font-bold text-cyan-400">
                {completedTodayCount} / {habits.length} ({todayPct}%)
              </span>
            </div>
            <div className="pixel-progress-track">
              <div
                className="pixel-progress-fill transition-all duration-300"
                style={{ width: `${habits.length > 0 ? Math.max(todayPct, 4) : 0}%` }}
              />
            </div>
          </div>

          <div className="p-3.5 rounded-2xl liquid-glass-subtle flex items-center justify-between">
            <div>
              <p className="text-xs text-slate-400">Лучшая активная серия</p>
              <p className="pixel-num text-xl font-bold text-white mt-0.5">
                {bestCurrentStreak} дн.
              </p>
            </div>
            <div className="p-2.5 rounded-xl bg-amber-500/15 text-amber-400">
              <Flame className="w-5 h-5" />
            </div>
          </div>
        </div>
      </div>

      {/* Список привычек */}
      {loading ? (
        <div className="space-y-3">
          {[1, 2].map((n) => (
            <div key={n} className="h-36 rounded-3xl liquid-glass animate-pulse" />
          ))}
        </div>
      ) : habits.length === 0 ? (
        <div className="text-center py-14 rounded-3xl liquid-glass">
          <p className="text-slate-200 font-semibold">
            У вас пока не добавлено ни одной привычки
          </p>
          <p className="text-xs text-slate-400 mt-1 mb-4">
            Создайте первую привычку — например: чтение, спорт, вода или изучение языка
          </p>
          <button
            type="button"
            onClick={openCreateModal}
            className="inline-flex items-center gap-2 px-4 py-2.5 rounded-xl liquid-btn-accent text-xs font-semibold"
          >
            <Plus className="w-4 h-4" />
            <span>Создать первую привычку</span>
          </button>
        </div>
      ) : (
        <div className="space-y-4">
          {habits.map((habit) => {
            const meta = HABIT_COLOR_META[habit.color] || HABIT_COLOR_META.cyan;
            const doneToday = habit.completedDates.includes(todayIso);
            const completedSet = new Set(habit.completedDates);

            // Подсчёт выполнений за последние 7 дней
            const doneLast7 = last7Days.filter((d) => completedSet.has(d.iso)).length;

            return (
              <div
                key={habit.id}
                className="liquid-glass rounded-3xl p-5 space-y-4 hover:border-cyan-400/40"
              >
                {/* Верхняя строка привычки */}
                <div className="flex items-start justify-between gap-3">
                  <div className="flex items-start gap-3.5 min-w-0">
                    {/* Главная пиксельная кнопка «Отметить сегодня» */}
                    <button
                      type="button"
                      onClick={() => handleToggleDate(habit, todayIso)}
                      title={
                        doneToday
                          ? 'Выполнено сегодня (нажмите, чтобы снять отметку)'
                          : 'Отметить выполнение за сегодня'
                      }
                      style={
                        doneToday
                          ? {
                              backgroundColor: meta.hex,
                              borderColor: meta.hex,
                              boxShadow: `0 0 16px -2px ${meta.hex}`,
                            }
                          : undefined
                      }
                      className={`mt-0.5 h-10 w-10 rounded-xl border-2 flex items-center justify-center shrink-0 transition-all ${
                        doneToday
                          ? '!text-white scale-[1.03]'
                          : 'liquid-glass-subtle border-slate-400/40 hover:border-cyan-400 text-slate-400'
                      }`}
                    >
                      {doneToday ? (
                        <PixelCheckmark className="w-5 h-5" />
                      ) : (
                        <span
                          className="w-2.5 h-2.5 rounded-[2px]"
                          style={{ backgroundColor: meta.hex, opacity: 0.65 }}
                        />
                      )}
                    </button>

                    <div className="min-w-0">
                      <div className="flex flex-wrap items-center gap-2">
                        <h3 className="text-base font-bold text-white">{habit.title}</h3>
                        <span
                          className={`pixel-num inline-flex items-center gap-1 text-[11px] font-semibold px-2 py-0.5 rounded-md ${meta.badge}`}
                        >
                          <Flame className="w-3 h-3" />
                          Серия: {habit.currentStreak} дн.
                        </span>
                        <span className="pixel-num inline-flex items-center gap-1 text-[11px] px-2 py-0.5 rounded-md liquid-glass-subtle text-slate-300">
                          <Trophy className="w-3 h-3 text-amber-400" />
                          Рекорд: {habit.bestStreak}
                        </span>
                      </div>

                      {habit.description && (
                        <p className="text-xs text-slate-400 mt-1">{habit.description}</p>
                      )}

                      <p className="pixel-num text-[11px] text-slate-400 mt-1.5">
                        За 7 дней: {doneLast7} из {habit.targetDaysPerWeek} по цели • Всего отметок: {habit.totalCompletions}
                      </p>
                    </div>
                  </div>

                  {/* Действия */}
                  <div className="flex items-center gap-1 shrink-0">
                    <button
                      type="button"
                      onClick={() => openEditModal(habit)}
                      className="p-2 rounded-xl text-slate-400 hover:text-white hover:bg-white/10 transition-colors"
                      title="Редактировать привычку"
                    >
                      <Edit3 className="w-4 h-4" />
                    </button>
                    <button
                      type="button"
                      onClick={() => handleDelete(habit.id)}
                      className="p-2 rounded-xl text-slate-400 hover:text-rose-400 hover:bg-rose-500/10 transition-colors"
                      title="Удалить привычку"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                </div>

                {/* Нижняя панель: Интерактивные 7 дней + 28-дневная пиксельная тепловая матрица */}
                <div className="pt-3 border-t border-white/10 flex flex-col lg:flex-row lg:items-center justify-between gap-4">
                  {/* Быстрые кнопки за последние 7 дней */}
                  <div className="grid grid-cols-7 gap-1.5 sm:w-auto">
                    {last7Days.map((d) => {
                      const active = completedSet.has(d.iso);
                      const isToday = d.iso === todayIso;
                      return (
                        <button
                          key={d.iso}
                          type="button"
                          onClick={() => handleToggleDate(habit, d.iso)}
                          style={
                            active
                              ? {
                                  backgroundColor: meta.hex,
                                  borderColor: 'rgba(255,255,255,0.35)',
                                }
                              : undefined
                          }
                          className={`px-2.5 py-1.5 rounded-lg border text-center transition-all ${
                            active
                              ? '!text-white shadow-sm'
                              : isToday
                                ? 'liquid-glass-subtle border-cyan-400/50 text-slate-200'
                                : 'liquid-glass-subtle border-transparent text-slate-400 hover:text-white'
                          }`}
                          title={`Переключить отметку за ${d.iso}`}
                        >
                          <div className="text-[9px] uppercase opacity-80">{d.weekday}</div>
                          <div className="pixel-num text-xs font-bold mt-0.5">{d.dayNum}</div>
                        </button>
                      );
                    })}
                  </div>

                  {/* 28-дневная пиксельная матрица активности */}
                  <div className="flex flex-col items-start lg:items-end gap-1">
                    <span className="text-[10px] text-slate-400 pixel-num">
                      Последние 28 дней
                    </span>
                    <div className="grid grid-cols-14 gap-1">
                      {last28Days.map((d) => {
                        const active = completedSet.has(d.iso);
                        return (
                          <button
                            key={d.iso}
                            type="button"
                            onClick={() => handleToggleDate(habit, d.iso)}
                            title={`${d.iso}: ${active ? 'Выполнено' : 'Не отмечено'}`}
                            style={
                              active
                                ? {
                                    backgroundColor: meta.hex,
                                    boxShadow: `0 0 6px ${meta.hex}`,
                                  }
                                : undefined
                            }
                            className={`w-3.5 h-3.5 rounded-[3px] transition-transform hover:scale-125 ${
                              active
                                ? ''
                                : 'bg-slate-500/20 border border-white/10'
                            }`}
                          />
                        );
                      })}
                    </div>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* Модальное окно создания / редактирования привычки */}
      {isModalOpen && (
        <div className="fixed inset-0 z-50 bg-black/55 backdrop-blur-md flex items-center justify-center p-4">
          <div className="w-full max-w-md liquid-glass rounded-3xl p-6">
            <div className="flex items-center justify-between mb-4">
              <h2 className="text-lg font-bold text-white">
                {editingHabit ? 'Редактировать привычку' : 'Новая привычка'}
              </h2>
              <button
                type="button"
                onClick={() => setIsModalOpen(false)}
                className="p-1.5 rounded-xl text-slate-400 hover:text-white"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {formError && (
              <div className="mb-4 p-3 rounded-xl bg-rose-500/15 border border-rose-500/30 text-rose-300 text-xs">
                {formError}
              </div>
            )}

            <form onSubmit={handleSave} className="space-y-4">
              <div>
                <label className="block text-xs font-medium text-slate-300 mb-1">
                  Название привычки
                </label>
                <input
                  type="text"
                  required
                  autoFocus
                  value={title}
                  onChange={(e) => setTitle(e.target.value)}
                  placeholder="Например: Чтение 30 минут, Зарядка, 2 л воды..."
                  className="w-full px-3.5 py-2.5 rounded-xl liquid-input text-sm"
                />
              </div>

              <div>
                <label className="block text-xs font-medium text-slate-300 mb-1">
                  Заметка / мотивация (необязательно)
                </label>
                <input
                  type="text"
                  value={description}
                  onChange={(e) => setDescription(e.target.value)}
                  placeholder="Почему это важно для меня..."
                  className="w-full px-3.5 py-2.5 rounded-xl liquid-input text-sm"
                />
              </div>

              <div>
                <label className="block text-xs font-medium text-slate-300 mb-1.5">
                  Цель дней в неделю: <span className="pixel-num font-bold text-white">{targetDaysPerWeek}</span>
                </label>
                <div className="grid grid-cols-7 gap-1.5">
                  {[1, 2, 3, 4, 5, 6, 7].map((num) => (
                    <button
                      key={num}
                      type="button"
                      onClick={() => setTargetDaysPerWeek(num)}
                      className={`pixel-num py-2 rounded-lg text-xs font-bold transition-all ${
                        targetDaysPerWeek === num
                          ? 'liquid-btn-accent'
                          : 'liquid-glass-subtle text-slate-300'
                      }`}
                    >
                      {num}
                    </button>
                  ))}
                </div>
              </div>

              <div>
                <label className="block text-xs font-medium text-slate-300 mb-2">
                  Цвет пиксельного индикатора
                </label>
                <div className="flex items-center gap-2.5">
                  {HABIT_COLORS.map((c) => (
                    <button
                      key={c}
                      type="button"
                      onClick={() => setColor(c)}
                      className={`h-7 w-7 rounded-lg ${HABIT_COLOR_META[c].swatch} transition-transform ${
                        color === c ? 'ring-2 ring-white scale-110' : 'opacity-70 hover:opacity-100'
                      }`}
                    />
                  ))}
                </div>
              </div>

              <div className="flex justify-end gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setIsModalOpen(false)}
                  className="px-4 py-2.5 rounded-xl liquid-glass-subtle text-slate-300 text-sm"
                >
                  Отмена
                </button>
                <button
                  type="submit"
                  disabled={saving}
                  className="px-5 py-2.5 rounded-xl liquid-btn-accent disabled:opacity-60 text-sm font-semibold"
                >
                  {saving ? 'Сохранение...' : 'Сохранить'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
