import React, { useCallback, useEffect, useMemo, useState } from 'react';
import {
  ArrowDownRight,
  ArrowUpRight,
  CreditCard,
  PiggyBank,
  Plus,
  Trash2,
  Wallet,
  X,
} from 'lucide-react';
import {
  ACCOUNT_TYPES,
  CURRENCIES,
  CURRENCY_SYMBOLS,
  type AccountType,
  type CurrencyCode,
  type TransactionType,
} from '@shared/constants';
import type { AccountDTO, TransactionDTO } from '@shared/schemas';
import { useAuth } from '../context/AuthContext';
import { useSettings } from '../context/SettingsContext';
import { financeApi, peekCachedGet } from '../lib/api';

const ACCOUNT_TYPE_LABELS: Record<AccountType, string> = {
  cash: 'Наличные',
  card: 'Банковская карта',
  savings: 'Накопительный счёт',
};

const EXPENSE_CATEGORIES = [
  'Продукты',
  'Кафе и рестораны',
  'Транспорт',
  'Жильё и ЖКХ',
  'Подписки и связь',
  'Покупки',
  'Здоровье',
  'Развлечения',
  'Другое',
];

const INCOME_CATEGORIES = [
  'Зарплата',
  'Фриланс / Проект',
  'Бизнес',
  'Подарок',
  'Кэшбэк / Проценты',
  'Другое',
];

export function FinancePage() {
  const { user } = useAuth();
  const { formatAmount } = useSettings();
  const initialAccs = peekCachedGet<{ accounts: AccountDTO[] }>('/api/finance/accounts');
  const initialTxs = peekCachedGet<{ transactions: TransactionDTO[] }>(
    '/api/finance/transactions'
  );
  const [accounts, setAccounts] = useState<AccountDTO[]>(
    () => initialAccs?.accounts || []
  );
  const [transactions, setTransactions] = useState<TransactionDTO[]>(
    () => initialTxs?.transactions || []
  );
  const [loading, setLoading] = useState(() => !initialAccs || !initialTxs);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);

  const [selectedAccountId, setSelectedAccountId] = useState<string>('all');
  const [typeFilter, setTypeFilter] = useState<'all' | TransactionType>('all');

  const [isAccountModalOpen, setIsAccountModalOpen] = useState(false);
  const [accName, setAccName] = useState('');
  const [accType, setAccType] = useState<AccountType>('card');
  const [accCurrency, setAccCurrency] = useState<CurrencyCode>(
    user?.defaultCurrency || 'EUR'
  );
  const [accInitialBalance, setAccInitialBalance] = useState('0');
  const [accColor, setAccColor] = useState('#10b981');

  const [isTxModalOpen, setIsTxModalOpen] = useState(false);
  const [txType, setTxType] = useState<TransactionType>('expense');
  const [txAccountId, setTxAccountId] = useState('');
  const [txAmount, setTxAmount] = useState('');
  const [txCategory, setTxCategory] = useState('Продукты');
  const [txDescription, setTxDescription] = useState('');
  const [txDate, setTxDate] = useState(() => new Date().toISOString().slice(0, 10));

  const loadFinance = useCallback(async () => {
    try {
      const [accRes, txRes] = await Promise.all([
        financeApi.listAccounts(),
        financeApi.listTransactions(),
      ]);
      setAccounts(accRes.accounts);
      setTransactions(txRes.transactions);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    loadFinance();
    const onSynced = () => loadFinance();
    window.addEventListener('sidaw:synced', onSynced);
    return () => window.removeEventListener('sidaw:synced', onSynced);
  }, [loadFinance]);

  const accountMap = useMemo(() => {
    const map = new Map<string, AccountDTO>();
    accounts.forEach((a) => map.set(a.id, a));
    return map;
  }, [accounts]);

  const filteredTransactions = useMemo(() => {
    return transactions.filter((tx) => {
      if (selectedAccountId !== 'all' && tx.accountId !== selectedAccountId) {
        return false;
      }
      if (typeFilter !== 'all' && tx.type !== typeFilter) return false;
      return true;
    });
  }, [transactions, selectedAccountId, typeFilter]);

  const categorySummary = useMemo(() => {
    const currentMonth = new Date().toISOString().slice(0, 7);
    const totals: Record<string, number> = {};
    let sum = 0;

    transactions.forEach((tx) => {
      if (tx.type === 'expense' && tx.date.startsWith(currentMonth)) {
        totals[tx.category] = (totals[tx.category] || 0) + tx.amount;
        sum += tx.amount;
      }
    });

    return {
      totalExpense: sum,
      items: Object.entries(totals)
        .sort((a, b) => b[1] - a[1])
        .slice(0, 5),
    };
  }, [transactions]);

  function openNewTxModal(presetType: TransactionType = 'expense') {
    if (accounts.length === 0) {
      setIsAccountModalOpen(true);
      return;
    }
    setErrorMsg(null);
    setTxType(presetType);
    const firstAcc = accounts[0]?.id || '';
    setTxAccountId(selectedAccountId !== 'all' ? selectedAccountId : firstAcc);
    setTxAmount('');
    setTxCategory(presetType === 'income' ? 'Зарплата' : 'Продукты');
    setTxDescription('');
    setTxDate(new Date().toISOString().slice(0, 10));
    setIsTxModalOpen(true);
  }

  async function handleCreateAccount(e: React.FormEvent) {
    e.preventDefault();
    setErrorMsg(null);
    try {
      await financeApi.createAccount({
        name: accName.trim(),
        type: accType,
        currency: accCurrency,
        initialBalance: Number(accInitialBalance) || 0,
        color: accColor,
      });
      setAccName('');
      setAccInitialBalance('0');
      setIsAccountModalOpen(false);
      await loadFinance();
    } catch (err: any) {
      setErrorMsg(err?.message || 'Ошибка создания счёта');
    }
  }

  async function handleDeleteAccount(id: string) {
    if (
      !window.confirm(
        'Удалить этот счёт и связанные с ним операции? Это действие необратимо.'
      )
    ) {
      return;
    }
    await financeApi.removeAccount(id);
    if (selectedAccountId === id) setSelectedAccountId('all');
    await loadFinance();
  }

  async function handleCreateTransaction(e: React.FormEvent) {
    e.preventDefault();
    setErrorMsg(null);
    const numericAmount = Number(txAmount);
    if (!numericAmount || numericAmount <= 0) {
      setErrorMsg('Введите сумму больше нуля');
      return;
    }

    try {
      await financeApi.createTransaction({
        accountId: txAccountId,
        type: txType,
        amount: numericAmount,
        category: txCategory,
        description: txDescription.trim(),
        date: txDate,
      });
      setIsTxModalOpen(false);
      await loadFinance();
    } catch (err: any) {
      setErrorMsg(err?.message || 'Ошибка сохранения операции');
    }
  }

  async function handleDeleteTransaction(id: string) {
    await financeApi.removeTransaction(id);
    await loadFinance();
  }

  function renderAccountIcon(type: AccountType) {
    switch (type) {
      case 'card':
        return <CreditCard className="w-4 h-4" />;
      case 'savings':
        return <PiggyBank className="w-4 h-4" />;
      case 'cash':
        return <Wallet className="w-4 h-4" />;
    }
  }

  return (
    <div className="space-y-6">
      {/* Верхние кнопки действий (фирменный цвет вкладки: Изумруд #10b981) */}
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div className="flex flex-wrap gap-2">
          <button
            type="button"
            onClick={() => openNewTxModal('expense')}
            className="inline-flex items-center gap-1.5 px-4 py-2.5 rounded-xl bg-rose-600 hover:bg-rose-500 !text-white text-xs sm:text-sm font-semibold shadow-lg shadow-rose-600/25 transition-all"
          >
            <ArrowDownRight className="w-4 h-4" />
            <span>Расход</span>
          </button>
          <button
            type="button"
            onClick={() => openNewTxModal('income')}
            className="inline-flex items-center gap-1.5 px-4 py-2.5 rounded-xl liquid-btn-accent text-xs sm:text-sm font-semibold"
          >
            <ArrowUpRight className="w-4 h-4" />
            <span>Доход</span>
          </button>
        </div>

        <button
          type="button"
          onClick={() => setIsAccountModalOpen(true)}
          className="inline-flex items-center gap-1.5 px-3.5 py-2.5 rounded-xl liquid-glass-subtle hover:border-emerald-400/40 text-slate-200 text-xs sm:text-sm font-medium"
        >
          <Plus className="w-4 h-4 text-emerald-400" />
          <span>Новый счёт</span>
        </button>
      </div>

      {/* Стеклянные карточки счетов и кошельков */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
        {accounts.map((acc) => {
          const isSelected = selectedAccountId === acc.id;
          return (
            <div
              key={acc.id}
              onClick={() => setSelectedAccountId(isSelected ? 'all' : acc.id)}
              className={`cursor-pointer rounded-3xl p-5 transition-all relative overflow-hidden ${
                isSelected
                  ? 'liquid-accent-banner'
                  : 'liquid-glass hover:border-emerald-400/40'
              }`}
            >
              <div className="flex items-center justify-between mb-3">
                <div className="flex items-center gap-2.5">
                  <span
                    className="p-2 rounded-xl !text-white shadow-md"
                    style={{ backgroundColor: acc.color }}
                  >
                    {renderAccountIcon(acc.type)}
                  </span>
                  <div>
                    <h3 className="text-sm font-bold text-white">{acc.name}</h3>
                    <p className="text-[11px] text-slate-400">
                      {ACCOUNT_TYPE_LABELS[acc.type]}
                    </p>
                  </div>
                </div>

                {accounts.length > 1 && (
                  <button
                    type="button"
                    onClick={(e) => {
                      e.stopPropagation();
                      handleDeleteAccount(acc.id);
                    }}
                    className="p-1.5 rounded-lg text-slate-400 hover:text-rose-400 hover:bg-rose-500/10"
                    title="Удалить счёт"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                )}
              </div>

              <p className="pixel-num text-2xl font-bold text-white tracking-tight">
                {formatAmount(acc.balance, acc.currency)}
              </p>
              {isSelected && (
                <span className="inline-block mt-2 text-[10px] font-medium text-emerald-400">
                  Фильтр по этому счёту активен
                </span>
              )}
            </div>
          );
        })}
      </div>

      {/* Нижний блок: Аналитика расходов за месяц + История операций */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        <div className="lg:col-span-4 liquid-glass rounded-3xl p-5 h-fit">
          <h3 className="text-sm font-bold text-white mb-1">
            Структура расходов (месяц)
          </h3>
          <p className="text-xs text-slate-400 mb-4">
            Топ категорий трат за текущий месяц
          </p>

          {categorySummary.items.length === 0 ? (
            <p className="text-xs text-slate-400 py-6 text-center">
              Пока нет расходов в этом месяце
            </p>
          ) : (
            <div className="space-y-3.5">
              {categorySummary.items.map(([cat, val]) => {
                const pct =
                  categorySummary.totalExpense > 0
                    ? Math.round((val / categorySummary.totalExpense) * 100)
                    : 0;
                return (
                  <div key={cat}>
                    <div className="flex justify-between text-xs mb-1">
                      <span className="text-slate-200 font-medium">{cat}</span>
                      <span className="pixel-num text-slate-400">
                        {formatAmount(val, user?.defaultCurrency || 'EUR')} ({pct}%)
                      </span>
                    </div>
                    <div className="pixel-progress-track">
                      <div
                        className="pixel-progress-fill"
                        style={{ width: `${Math.max(pct, 6)}%` }}
                      />
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>

        {/* История транзакций */}
        <div className="lg:col-span-8 liquid-glass rounded-3xl p-5">
          <div className="flex flex-wrap items-center justify-between gap-2 mb-4">
            <h3 className="text-sm font-bold text-white">История операций</h3>

            <div className="flex flex-wrap gap-1.5">
              {(['all', 'expense', 'income'] as const).map((tp) => (
                <button
                  key={tp}
                  type="button"
                  onClick={() => setTypeFilter(tp)}
                  className={`px-2.5 py-1 rounded-lg text-xs font-medium transition-all ${
                    typeFilter === tp
                      ? 'liquid-btn-accent'
                      : 'liquid-glass-subtle text-slate-300 hover:text-white'
                  }`}
                >
                  {tp === 'all' ? 'Все' : tp === 'expense' ? 'Расходы' : 'Доходы'}
                </button>
              ))}
            </div>
          </div>

          {loading ? (
            <div className="space-y-2.5">
              {[1, 2, 3].map((i) => (
                <div key={i} className="h-14 rounded-2xl liquid-glass-subtle animate-pulse" />
              ))}
            </div>
          ) : filteredTransactions.length === 0 ? (
            <div className="text-center py-10">
              <p className="text-sm text-slate-300">Операций пока нет</p>
              <p className="text-xs text-slate-400 mt-1">
                Добавьте первый доход или расход кнопками сверху
              </p>
            </div>
          ) : (
            <div className="space-y-2.5">
              {filteredTransactions.map((tx) => {
                const acc = accountMap.get(tx.accountId);
                const cur = tx.currency || acc?.currency || user?.defaultCurrency || 'EUR';

                return (
                  <div
                    key={tx.id}
                    className="flex items-center justify-between gap-3 p-3.5 rounded-2xl liquid-glass-subtle hover:border-emerald-400/35 transition-colors"
                  >
                    <div className="flex items-center gap-3 min-w-0">
                      <div
                        className={`p-2 rounded-xl shrink-0 ${
                          tx.type === 'income'
                            ? 'bg-emerald-500/15 text-emerald-400'
                            : 'bg-rose-500/15 text-rose-400'
                        }`}
                      >
                        {tx.type === 'income' ? (
                          <ArrowUpRight className="w-4 h-4" />
                        ) : (
                          <ArrowDownRight className="w-4 h-4" />
                        )}
                      </div>

                      <div className="min-w-0">
                        <p className="text-sm font-semibold text-white truncate">
                          {tx.category}
                        </p>
                        <p className="text-xs text-slate-400 truncate">
                          {tx.accountName || acc?.name || 'Счёт'} • {tx.date}
                          {tx.description ? ` • ${tx.description}` : ''}
                        </p>
                      </div>
                    </div>

                    <div className="flex items-center gap-2 shrink-0">
                      <span
                        className={`pixel-num text-sm font-bold ${
                          tx.type === 'income' ? 'text-emerald-400' : 'text-rose-400'
                        }`}
                      >
                        {tx.type === 'income' ? '+' : '−'}
                        {formatAmount(tx.amount, cur)}
                      </span>
                      <button
                        type="button"
                        onClick={() => handleDeleteTransaction(tx.id)}
                        className="p-1.5 rounded-lg text-slate-400 hover:text-rose-400 hover:bg-rose-500/10"
                        title="Удалить операцию"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>
      </div>

      {/* Стеклянное модальное окно нового счёта */}
      {isAccountModalOpen && (
        <div className="fixed inset-0 z-50 bg-black/55 backdrop-blur-md flex items-center justify-center p-4">
          <div className="w-full max-w-md liquid-glass rounded-3xl p-6">
            <div className="flex items-center justify-between mb-4">
              <h2 className="text-lg font-bold text-white">Новый счёт / кошелёк</h2>
              <button
                type="button"
                onClick={() => setIsAccountModalOpen(false)}
                className="p-1.5 rounded-xl text-slate-400 hover:text-white"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleCreateAccount} className="space-y-4">
              <div>
                <label className="block text-xs font-medium text-slate-300 mb-1">
                  Название счёта
                </label>
                <input
                  type="text"
                  required
                  autoFocus
                  value={accName}
                  onChange={(e) => setAccName(e.target.value)}
                  placeholder="Основная карта, Наличные, Копилка..."
                  className="w-full px-3.5 py-2.5 rounded-xl liquid-input text-sm"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-medium text-slate-300 mb-1">
                    Тип
                  </label>
                  <select
                    value={accType}
                    onChange={(e) => setAccType(e.target.value as AccountType)}
                    className="w-full px-3 py-2.5 rounded-xl liquid-input text-sm"
                  >
                    {ACCOUNT_TYPES.map((t) => (
                      <option key={t} value={t}>
                        {ACCOUNT_TYPE_LABELS[t]}
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-medium text-slate-300 mb-1">
                    Валюта
                  </label>
                  <select
                    value={accCurrency}
                    onChange={(e) => setAccCurrency(e.target.value as CurrencyCode)}
                    className="w-full px-3 py-2.5 rounded-xl liquid-input text-sm"
                  >
                    {CURRENCIES.map((c) => (
                      <option key={c} value={c}>
                        {c} ({CURRENCY_SYMBOLS[c]})
                      </option>
                    ))}
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-medium text-slate-300 mb-1">
                    Начальный остаток
                  </label>
                  <input
                    type="number"
                    step="0.01"
                    value={accInitialBalance}
                    onChange={(e) => setAccInitialBalance(e.target.value)}
                    className="w-full px-3.5 py-2.5 rounded-xl liquid-input text-sm"
                  />
                </div>

                <div>
                  <label className="block text-xs font-medium text-slate-300 mb-1">
                    Цвет иконки
                  </label>
                  <div className="flex items-center gap-2 pt-1.5">
                    {['#10b981', '#6366f1', '#f59e0b', '#ec4899', '#0ea5e9'].map(
                      (hex) => (
                        <button
                          key={hex}
                          type="button"
                          onClick={() => setAccColor(hex)}
                          style={{ backgroundColor: hex }}
                          className={`h-7 w-7 rounded-full ${
                            accColor === hex ? 'ring-2 ring-white scale-110' : 'opacity-70'
                          }`}
                        />
                      )
                    )}
                  </div>
                </div>
              </div>

              <div className="flex justify-end gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setIsAccountModalOpen(false)}
                  className="px-4 py-2.5 rounded-xl liquid-glass-subtle text-slate-300 text-sm"
                >
                  Отмена
                </button>
                <button
                  type="submit"
                  className="px-5 py-2.5 rounded-xl liquid-btn-accent text-sm font-semibold"
                >
                  Создать счёт
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Стеклянное модальное окно новой финансовой операции */}
      {isTxModalOpen && (
        <div className="fixed inset-0 z-50 bg-black/55 backdrop-blur-md flex items-center justify-center p-4">
          <div className="w-full max-w-md liquid-glass rounded-3xl p-6">
            <div className="flex items-center justify-between mb-4">
              <h2 className="text-lg font-bold text-white">Новая операция</h2>
              <button
                type="button"
                onClick={() => setIsTxModalOpen(false)}
                className="p-1.5 rounded-xl text-slate-400 hover:text-white"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {errorMsg && (
              <div className="mb-4 p-3 rounded-xl bg-rose-500/15 border border-rose-500/30 text-rose-300 text-xs">
                {errorMsg}
              </div>
            )}

            <form onSubmit={handleCreateTransaction} className="space-y-4">
              <div className="grid grid-cols-2 p-1 rounded-2xl liquid-glass-subtle">
                {(['expense', 'income'] as const).map((t) => (
                  <button
                    key={t}
                    type="button"
                    onClick={() => {
                      setTxType(t);
                      setTxCategory(t === 'income' ? 'Зарплата' : 'Продукты');
                    }}
                    className={`py-2 rounded-xl text-xs font-semibold transition-all ${
                      txType === t
                        ? t === 'expense'
                          ? 'bg-rose-600 !text-white'
                          : 'liquid-btn-accent'
                        : 'text-slate-400'
                    }`}
                  >
                    {t === 'expense' ? 'Расход' : 'Доход'}
                  </button>
                ))}
              </div>

              <div>
                <label className="block text-xs font-medium text-slate-300 mb-1">
                  Сумма
                </label>
                <input
                  type="number"
                  step="0.01"
                  min="0.01"
                  required
                  autoFocus
                  value={txAmount}
                  onChange={(e) => setTxAmount(e.target.value)}
                  placeholder="0.00"
                  className="w-full px-3.5 py-2.5 rounded-xl liquid-input text-lg font-bold"
                />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-medium text-slate-300 mb-1">
                    Счёт
                  </label>
                  <select
                    value={txAccountId}
                    onChange={(e) => setTxAccountId(e.target.value)}
                    className="w-full px-3 py-2.5 rounded-xl liquid-input text-sm"
                  >
                    {accounts.map((a) => (
                      <option key={a.id} value={a.id}>
                        {a.name} ({a.currency})
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-medium text-slate-300 mb-1">
                    Категория
                  </label>
                  <select
                    value={txCategory}
                    onChange={(e) => setTxCategory(e.target.value)}
                    className="w-full px-3 py-2.5 rounded-xl liquid-input text-sm"
                  >
                    {(txType === 'income' ? INCOME_CATEGORIES : EXPENSE_CATEGORIES).map(
                      (cat) => (
                        <option key={cat} value={cat}>
                          {cat}
                        </option>
                      )
                    )}
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-medium text-slate-300 mb-1">
                    Дата операции
                  </label>
                  <input
                    type="date"
                    value={txDate}
                    onChange={(e) => setTxDate(e.target.value)}
                    className="w-full px-3.5 py-2.5 rounded-xl liquid-input text-sm"
                  />
                </div>
                <div>
                  <label className="block text-xs font-medium text-slate-300 mb-1">
                    Комментарий
                  </label>
                  <input
                    type="text"
                    value={txDescription}
                    onChange={(e) => setTxDescription(e.target.value)}
                    placeholder="Необязательно"
                    className="w-full px-3.5 py-2.5 rounded-xl liquid-input text-sm"
                  />
                </div>
              </div>

              <div className="flex justify-end gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setIsTxModalOpen(false)}
                  className="px-4 py-2.5 rounded-xl liquid-glass-subtle text-slate-300 text-sm"
                >
                  Отмена
                </button>
                <button
                  type="submit"
                  className="px-5 py-2.5 rounded-xl liquid-btn-accent text-sm font-semibold"
                >
                  Сохранить
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
