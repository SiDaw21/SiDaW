import React, { useCallback, useEffect, useMemo, useState } from 'react';
import {
  Calendar,
  Edit3,
  Plus,
  Search,
  Tag,
  Trash2,
  X,
} from 'lucide-react';
import type { TaskPriority, TaskStatus } from '@shared/constants';
import type { TaskDTO } from '@shared/schemas';
import { useSettings } from '../context/SettingsContext';
import { PixelCheckmark } from '../components/PixelIcons';
import { peekCachedGet, tasksApi } from '../lib/api';

const PRIORITY_LABELS: Record<TaskPriority, string> = {
  low: 'Низкий',
  medium: 'Средний',
  high: 'Высокий',
};

const STATUS_LABELS: Record<TaskStatus, string> = {
  todo: 'К выполнению',
  in_progress: 'В работе',
  done: 'Готово',
};

export function TasksPage() {
  const { playGlassSound } = useSettings();
  const initialTasks = peekCachedGet<{ tasks: TaskDTO[] }>('/api/tasks');
  const [tasks, setTasks] = useState<TaskDTO[]>(() => initialTasks?.tasks || []);
  const [loading, setLoading] = useState(() => !initialTasks);

  const [statusFilter, setStatusFilter] = useState<'all' | TaskStatus>('all');
  const [priorityFilter, setPriorityFilter] = useState<'all' | TaskPriority>('all');
  const [searchQuery, setSearchQuery] = useState('');

  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingTask, setEditingTask] = useState<TaskDTO | null>(null);
  const [formError, setFormError] = useState<string | null>(null);

  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [priority, setPriority] = useState<TaskPriority>('medium');
  const [status, setStatus] = useState<TaskStatus>('todo');
  const [category, setCategory] = useState('Общее');
  const [dueDate, setDueDate] = useState('');

  const loadTasks = useCallback(async () => {
    try {
      const res = await tasksApi.list();
      setTasks(res.tasks);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    loadTasks();
    const onSynced = () => loadTasks();
    window.addEventListener('sidaw:synced', onSynced);
    return () => window.removeEventListener('sidaw:synced', onSynced);
  }, [loadTasks]);

  function openCreateModal() {
    setEditingTask(null);
    setTitle('');
    setDescription('');
    setPriority('medium');
    setStatus('todo');
    setCategory('Общее');
    setDueDate('');
    setIsModalOpen(true);
  }

  function openEditModal(task: TaskDTO) {
    setEditingTask(task);
    setTitle(task.title);
    setDescription(task.description);
    setPriority(task.priority);
    setStatus(task.status);
    setCategory(task.category);
    setDueDate(task.dueDate || '');
    setIsModalOpen(true);
  }

  async function handleSave(e: React.FormEvent) {
    e.preventDefault();
    if (!title.trim()) return;
    setFormError(null);

    try {
      const payload = {
        title: title.trim(),
        description: description.trim(),
        priority,
        status,
        category: category.trim() || 'Общее',
        dueDate: dueDate ? dueDate : null,
      };

      if (editingTask) {
        await tasksApi.update(editingTask.id, payload);
      } else {
        await tasksApi.create(payload);
      }

      setIsModalOpen(false);
      await loadTasks();
    } catch (err: any) {
      setFormError(err?.message || 'Не удалось сохранить задачу');
    }
  }

  async function toggleDone(task: TaskDTO) {
    const nextStatus: TaskStatus = task.status === 'done' ? 'todo' : 'done';
    if (nextStatus === 'done') {
      playGlassSound();
    }
    await tasksApi.update(task.id, { status: nextStatus });
    await loadTasks();
  }

  async function handleDelete(id: string) {
    await tasksApi.remove(id);
    await loadTasks();
  }

  const filteredTasks = useMemo(() => {
    return tasks.filter((t) => {
      if (statusFilter !== 'all' && t.status !== statusFilter) return false;
      if (priorityFilter !== 'all' && t.priority !== priorityFilter) return false;
      if (searchQuery.trim()) {
        const q = searchQuery.toLowerCase();
        const hay = `${t.title} ${t.description} ${t.category}`.toLowerCase();
        if (!hay.includes(q)) return false;
      }
      return true;
    });
  }, [tasks, statusFilter, priorityFilter, searchQuery]);

  const todayIso = new Date().toISOString().slice(0, 10);

  return (
    <div className="space-y-5">
      {/* Панель управления задачами (фирменный цвет вкладки: Аметист #a855f7) */}
      <div className="liquid-glass rounded-3xl p-4 sm:p-5 flex flex-col gap-3">
        <div className="flex flex-col sm:flex-row gap-3 justify-between">
          <div className="relative flex-1">
            <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Поиск задач по названию, описанию или категории..."
              className="w-full pl-10 pr-4 py-2.5 rounded-xl liquid-input text-sm"
            />
          </div>
          <button
            type="button"
            onClick={openCreateModal}
            className="inline-flex items-center justify-center gap-2 px-4 py-2.5 rounded-xl liquid-btn-accent text-sm font-semibold shrink-0"
          >
            <Plus className="w-4 h-4" />
            <span>Добавить задачу</span>
          </button>
        </div>

        {/* Стеклянные чипы фильтров */}
        <div className="flex flex-wrap items-center justify-between gap-2 pt-1">
          <div className="flex flex-wrap gap-1.5">
            {(['all', 'todo', 'in_progress', 'done'] as const).map((st) => (
              <button
                key={st}
                type="button"
                onClick={() => setStatusFilter(st)}
                className={`px-3 py-1.5 rounded-xl text-xs font-medium transition-all ${
                  statusFilter === st
                    ? 'liquid-btn-accent'
                    : 'liquid-glass-subtle text-slate-300 hover:text-white'
                }`}
              >
                {st === 'all' ? 'Все' : STATUS_LABELS[st]}
              </button>
            ))}
          </div>

          <select
            value={priorityFilter}
            onChange={(e) => setPriorityFilter(e.target.value as any)}
            className="px-3 py-1.5 rounded-xl liquid-input text-xs"
          >
            <option value="all">Любой приоритет</option>
            <option value="high">Высокий приоритет</option>
            <option value="medium">Средний приоритет</option>
            <option value="low">Низкий приоритет</option>
          </select>
        </div>
      </div>

      {/* Список задач в карточках жидкого стекла */}
      {loading ? (
        <div className="space-y-3">
          {[1, 2, 3].map((i) => (
            <div key={i} className="h-20 rounded-2xl liquid-glass animate-pulse" />
          ))}
        </div>
      ) : filteredTasks.length === 0 ? (
        <div className="text-center py-14 rounded-3xl liquid-glass">
          <p className="text-slate-200 font-semibold">Задач по выбранному фильтру пока нет</p>
          <p className="text-xs text-slate-400 mt-1">
            Создайте задачу — она мгновенно появится на вашем ПК и смартфоне
          </p>
        </div>
      ) : (
        <div className="space-y-3">
          {filteredTasks.map((task) => {
            const isDone = task.status === 'done';
            const isOverdue = !isDone && task.dueDate && task.dueDate < todayIso;

            return (
              <div
                key={task.id}
                className={`p-4 rounded-2xl liquid-glass transition-all flex items-start justify-between gap-3 ${
                  isDone ? 'opacity-65' : 'hover:border-violet-400/45'
                }`}
              >
                <div className="flex items-start gap-3.5 min-w-0 flex-1">
                  <button
                    type="button"
                    onClick={() => toggleDone(task)}
                    className={`mt-0.5 h-5 w-5 rounded-[4px] border-2 flex items-center justify-center shrink-0 transition-all ${
                      isDone
                        ? 'bg-emerald-500 border-emerald-500 !text-white shadow-sm shadow-emerald-500/40'
                        : 'border-slate-400/60 hover:border-violet-400'
                    }`}
                  >
                    {isDone && <PixelCheckmark className="w-3.5 h-3.5" />}
                  </button>

                  <div className="min-w-0 flex-1">
                    <div className="flex flex-wrap items-center gap-2">
                      <h3
                        className={`text-sm sm:text-base font-semibold ${
                          isDone ? 'line-through text-slate-400' : 'text-white'
                        }`}
                      >
                        {task.title}
                      </h3>
                      <span
                        className={`text-[10px] font-semibold px-2 py-0.5 rounded-full ${
                          task.priority === 'high'
                            ? 'bg-rose-500/20 text-rose-400'
                            : task.priority === 'medium'
                              ? 'bg-amber-500/20 text-amber-400'
                              : 'bg-slate-500/20 text-slate-300'
                        }`}
                      >
                        {PRIORITY_LABELS[task.priority]}
                      </span>
                      {task.status === 'in_progress' && (
                        <span className="text-[10px] font-semibold px-2 py-0.5 rounded-full bg-violet-500/20 text-violet-300">
                          В работе
                        </span>
                      )}
                    </div>

                    {task.description && (
                      <p className="text-xs sm:text-sm text-slate-400 mt-1 whitespace-pre-line">
                        {task.description}
                      </p>
                    )}

                    <div className="flex flex-wrap items-center gap-3 mt-2.5 text-xs text-slate-400">
                      <span className="inline-flex items-center gap-1 text-violet-300">
                        <Tag className="w-3 h-3" />
                        {task.category}
                      </span>
                      {task.dueDate && (
                        <span
                          className={`inline-flex items-center gap-1 ${
                            isOverdue ? 'text-rose-400 font-semibold' : ''
                          }`}
                        >
                          <Calendar className="w-3 h-3" />
                          {isOverdue ? `Просрочено (${task.dueDate})` : `Срок: ${task.dueDate}`}
                        </span>
                      )}
                    </div>
                  </div>
                </div>

                <div className="flex items-center gap-1 shrink-0">
                  <button
                    type="button"
                    onClick={() => openEditModal(task)}
                    className="p-2 rounded-xl text-slate-400 hover:text-white hover:bg-white/10 transition-colors"
                    title="Редактировать"
                  >
                    <Edit3 className="w-4 h-4" />
                  </button>
                  <button
                    type="button"
                    onClick={() => handleDelete(task.id)}
                    className="p-2 rounded-xl text-slate-400 hover:text-rose-400 hover:bg-rose-500/10 transition-colors"
                    title="Удалить"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* Стеклянное модальное окно создания / редактирования задачи */}
      {isModalOpen && (
        <div className="fixed inset-0 z-50 bg-black/55 backdrop-blur-md flex items-center justify-center p-4">
          <div className="w-full max-w-lg liquid-glass rounded-3xl p-6">
            <div className="flex items-center justify-between mb-4">
              <h2 className="text-lg font-bold text-white">
                {editingTask ? 'Редактировать задачу' : 'Новая задача'}
              </h2>
              <button
                type="button"
                onClick={() => setIsModalOpen(false)}
                className="p-1.5 rounded-xl text-slate-400 hover:text-white hover:bg-white/10"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSave} className="space-y-4">
              {formError && (
                <div className="p-3 rounded-xl bg-rose-500/15 border border-rose-500/30 text-rose-300 text-xs">
                  {formError}
                </div>
              )}
              <div>
                <label className="block text-xs font-medium text-slate-300 mb-1">
                  Название задачи
                </label>
                <input
                  type="text"
                  required
                  autoFocus
                  value={title}
                  onChange={(e) => setTitle(e.target.value)}
                  placeholder="Что нужно сделать?"
                  className="w-full px-3.5 py-2.5 rounded-xl liquid-input text-sm"
                />
              </div>

              <div>
                <label className="block text-xs font-medium text-slate-300 mb-1">
                  Описание / детали
                </label>
                <textarea
                  rows={3}
                  value={description}
                  onChange={(e) => setDescription(e.target.value)}
                  placeholder="Подробности, ссылки или шаги..."
                  className="w-full px-3.5 py-2.5 rounded-xl liquid-input text-sm resize-none"
                />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-medium text-slate-300 mb-1">
                    Приоритет
                  </label>
                  <select
                    value={priority}
                    onChange={(e) => setPriority(e.target.value as TaskPriority)}
                    className="w-full px-3 py-2.5 rounded-xl liquid-input text-sm"
                  >
                    <option value="low">Низкий</option>
                    <option value="medium">Средний</option>
                    <option value="high">Высокий</option>
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-medium text-slate-300 mb-1">
                    Статус
                  </label>
                  <select
                    value={status}
                    onChange={(e) => setStatus(e.target.value as TaskStatus)}
                    className="w-full px-3 py-2.5 rounded-xl liquid-input text-sm"
                  >
                    <option value="todo">К выполнению</option>
                    <option value="in_progress">В работе</option>
                    <option value="done">Готово</option>
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-medium text-slate-300 mb-1">
                    Категория / Проект
                  </label>
                  <input
                    type="text"
                    value={category}
                    onChange={(e) => setCategory(e.target.value)}
                    placeholder="Работа, Дом, Покупки..."
                    className="w-full px-3.5 py-2.5 rounded-xl liquid-input text-sm"
                  />
                </div>

                <div>
                  <label className="block text-xs font-medium text-slate-300 mb-1">
                    Дедлайн (необязательно)
                  </label>
                  <input
                    type="date"
                    value={dueDate}
                    onChange={(e) => setDueDate(e.target.value)}
                    className="w-full px-3.5 py-2.5 rounded-xl liquid-input text-sm"
                  />
                </div>
              </div>

              <div className="flex justify-end gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setIsModalOpen(false)}
                  className="px-4 py-2.5 rounded-xl liquid-glass-subtle text-slate-300 text-sm font-medium"
                >
                  Отмена
                </button>
                <button
                  type="submit"
                  className="px-5 py-2.5 rounded-xl liquid-btn-accent text-sm font-semibold"
                >
                  Сохранить
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
