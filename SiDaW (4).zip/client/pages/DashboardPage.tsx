import React, { useCallback, useEffect, useState } from 'react';
import {
  AlertTriangle,
  ArrowDownRight,
  ArrowRight,
  ArrowUpRight,
  CheckCircle2,
  CheckSquare,
  Clock,
  FileText,
  Flame,
  Pin,
  TrendingUp,
  Wallet,
} from 'lucide-react';
import type { NavTabId } from '@shared/constants';
import type { DashboardSummaryDTO } from '@shared/schemas';
import { useAuth } from '../context/AuthContext';
import { useSettings } from '../context/SettingsContext';
import { dashboardApi, peekCachedGet, tasksApi } from '../lib/api';

interface DashboardPageProps {
  onNavigate: (tab: NavTabId) => void;
}

export function DashboardPage({ onNavigate }: DashboardPageProps) {
  const { user } = useAuth();
  const { formatAmount, playGlassSound } = useSettings();
  const initialDashboard = peekCachedGet<DashboardSummaryDTO>('/api/dashboard');
  const [data, setData] = useState<DashboardSummaryDTO | null>(() => initialDashboard);
  const [loading, setLoading] = useState(() => !initialDashboard);

  const load = useCallback(async () => {
    try {
      const res = await dashboardApi.getSummary();
      setData(res);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    load();
    const handler = () => load();
    window.addEventListener('sidaw:synced', handler);
    return () => window.removeEventListener('sidaw:synced', handler);
  }, [load]);

  async function quickCompleteTask(taskId: string) {
    playGlassSound();
    await tasksApi.update(taskId, { status: 'done' });
    await load();
  }

  if (loading && !data) {
    return (
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4 animate-pulse">
        {[1, 2, 3].map((n) => (
          <div key={n} className="h-32 rounded-3xl liquid-glass" />
        ))}
      </div>
    );
  }

  if (!data) return null;

  const balanceEntries = Object.entries(data.financeStats.balancesByCurrency);
  const primaryCurrency = user?.defaultCurrency || 'EUR';
  const monthCurrencies = Array.from(
    new Set([
      ...Object.keys(data.financeStats.monthIncomeByCurrency),
      ...Object.keys(data.financeStats.monthExpenseByCurrency),
    ])
  );

  return (
    <div className="space-y-6">
      {/* Приветственный баннер вкладки Дашборд (цвет: Сапфир / Индиго) */}
      <div className="liquid-accent-banner rounded-3xl p-6 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <span className="pixel-badge inline-block text-[10px] px-2 py-0.5 rounded mb-2">
            САПФИР // СВОДКА АККАУНТА
          </span>
          <h2 className="text-xl sm:text-2xl font-bold text-white">
            Привет, {user?.name}!
          </h2>
          <p className="text-slate-300 text-sm mt-1">
            Все задачи, заметки и личные финансы синхронизированы для ПК и смартфона.
          </p>
        </div>

        <div className="flex flex-wrap gap-2">
          <button
            type="button"
            onClick={() => onNavigate('tasks')}
            className="px-4 py-2.5 rounded-xl liquid-btn-accent text-xs font-semibold transition-all"
          >
            + Новая задача
          </button>
          <button
            type="button"
            onClick={() => onNavigate('habits')}
            className="px-4 py-2.5 rounded-xl liquid-glass-subtle hover:border-cyan-400/40 text-cyan-400 text-xs font-semibold transition-all"
          >
            Привычки ({data.habitsStats?.completedToday ?? 0}/{data.habitsStats?.total ?? 0})
          </button>
          <button
            type="button"
            onClick={() => onNavigate('finance')}
            className="px-4 py-2.5 rounded-xl liquid-glass-subtle hover:border-emerald-400/40 text-emerald-400 text-xs font-semibold transition-all"
          >
            + Доход / Расход
          </button>
        </div>
      </div>

      {/* Верхние KPI карточки в стиле жидкого стекла */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-4">
        {/* Общий баланс */}
        <div
          onClick={() => onNavigate('finance')}
          className="cursor-pointer liquid-glass hover:border-emerald-400/40 rounded-3xl p-5"
        >
          <div className="flex items-center justify-between mb-3">
            <span className="text-xs font-medium text-slate-400">Баланс счетов</span>
            <div className="p-2 rounded-xl bg-emerald-500/15 text-emerald-400 border border-emerald-500/20">
              <Wallet className="w-4 h-4" />
            </div>
          </div>
          {balanceEntries.length === 0 ? (
            <p className="pixel-num text-xl font-bold text-white">
              {formatAmount(0, primaryCurrency)}
            </p>
          ) : (
            <div className="space-y-1">
              {balanceEntries.map(([cur, val]) => (
                <p key={cur} className="pixel-num text-xl font-bold text-white">
                  {formatAmount(val, cur)}
                </p>
              ))}
            </div>
          )}
          <p className="text-[11px] text-slate-400 mt-2">
            Счетов в аккаунте: {data.accounts.length}
          </p>
        </div>

        {/* Месячный поток */}
        <div
          onClick={() => onNavigate('finance')}
          className="cursor-pointer liquid-glass hover:border-indigo-400/40 rounded-3xl p-5"
        >
          <div className="flex items-center justify-between mb-3">
            <span className="text-xs font-medium text-slate-400">Этот месяц</span>
            <div className="p-2 rounded-xl bg-indigo-500/15 text-indigo-400 border border-indigo-500/20">
              <TrendingUp className="w-4 h-4" />
            </div>
          </div>
          {monthCurrencies.length === 0 ? (
            <div className="space-y-1">
              <p className="text-sm font-semibold text-emerald-400 flex items-center gap-1">
                <ArrowUpRight className="w-4 h-4" /> +{formatAmount(0, primaryCurrency)}
              </p>
              <p className="text-sm font-semibold text-rose-400 flex items-center gap-1">
                <ArrowDownRight className="w-4 h-4" /> −{formatAmount(0, primaryCurrency)}
              </p>
            </div>
          ) : (
            <div className="space-y-1.5">
              {monthCurrencies.slice(0, 2).map((cur) => {
                const inc = data.financeStats.monthIncomeByCurrency[cur] || 0;
                const exp = data.financeStats.monthExpenseByCurrency[cur] || 0;
                return (
                  <div key={cur} className="text-xs space-y-0.5">
                    <div className="text-emerald-400 font-semibold">
                      +{formatAmount(inc, cur)} доход
                    </div>
                    <div className="text-rose-400 font-semibold">
                      −{formatAmount(exp, cur)} расход
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>

        {/* Активные задачи (цвет вкладки Задачи — Аметист) */}
        <div
          onClick={() => onNavigate('tasks')}
          className="cursor-pointer liquid-glass hover:border-violet-400/40 rounded-3xl p-5"
        >
          <div className="flex items-center justify-between mb-3">
            <span className="text-xs font-medium text-slate-400">Активные задачи</span>
            <div className="p-2 rounded-xl bg-violet-500/15 text-violet-400 border border-violet-500/20">
              <CheckSquare className="w-4 h-4" />
            </div>
          </div>
          <p className="pixel-num text-2xl font-bold text-white">
            {data.tasksStats.todo + data.tasksStats.inProgress}
          </p>
          <div className="flex items-center gap-3 mt-2 text-[11px]">
            <span className="text-emerald-400">Выполнено: {data.tasksStats.done}</span>
            {data.tasksStats.overdue > 0 && (
              <span className="text-rose-400 flex items-center gap-1">
                <AlertTriangle className="w-3 h-3" /> Просрочено: {data.tasksStats.overdue}
              </span>
            )}
          </div>
        </div>

        {/* Привычки (цвет вкладки Привычки — Топаз / Циан) */}
        <div
          onClick={() => onNavigate('habits')}
          className="cursor-pointer liquid-glass hover:border-cyan-400/40 rounded-3xl p-5"
        >
          <div className="flex items-center justify-between mb-3">
            <span className="text-xs font-medium text-slate-400">Привычки сегодня</span>
            <div className="p-2 rounded-xl bg-cyan-500/15 text-cyan-400 border border-cyan-500/20">
              <Flame className="w-4 h-4" />
            </div>
          </div>
          <p className="pixel-num text-2xl font-bold text-white">
            {data.habitsStats?.completedToday ?? 0} / {data.habitsStats?.total ?? 0}
          </p>
          <p className="text-[11px] text-cyan-400 mt-2">
            Серия: {data.habitsStats?.bestActiveStreak ?? 0} дн.
          </p>
        </div>

        {/* Заметки (цвет вкладки Заметки — Янтарь) */}
        <div
          onClick={() => onNavigate('notes')}
          className="cursor-pointer liquid-glass hover:border-amber-400/40 rounded-3xl p-5"
        >
          <div className="flex items-center justify-between mb-3">
            <span className="text-xs font-medium text-slate-400">Заметки и идеи</span>
            <div className="p-2 rounded-xl bg-amber-500/15 text-amber-400 border border-amber-500/20">
              <FileText className="w-4 h-4" />
            </div>
          </div>
          <p className="pixel-num text-2xl font-bold text-white">{data.notesStats.total}</p>
          <p className="text-[11px] text-slate-400 mt-2">
            Закреплено: {data.notesStats.pinned}
          </p>
        </div>
      </div>

      {/* Нижняя сетка: ближайшие задачи и заметки */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Ближайшие задачи */}
        <div className="liquid-glass rounded-3xl p-5 flex flex-col">
          <div className="flex items-center justify-between mb-4">
            <h3 className="font-bold text-white flex items-center gap-2">
              <Clock className="w-4 h-4 text-violet-400" />
              <span>Приоритетные задачи</span>
            </h3>
            <button
              type="button"
              onClick={() => onNavigate('tasks')}
              className="text-xs text-violet-400 hover:underline flex items-center gap-1"
            >
              <span>Все задачи</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
          </div>

          {data.activeTasks.length === 0 ? (
            <div className="flex-1 flex flex-col items-center justify-center py-8 text-center">
              <CheckCircle2 className="w-9 h-9 text-emerald-400/70 mb-2" />
              <p className="text-sm text-slate-300 font-medium">Все задачи закрыты!</p>
              <p className="text-xs text-slate-500 mt-0.5">
                Добавьте новую задачу во вкладке «Задачи»
              </p>
            </div>
          ) : (
            <div className="space-y-2.5">
              {data.activeTasks.map((task) => (
                <div
                  key={task.id}
                  className="flex items-center justify-between gap-3 p-3 rounded-2xl liquid-glass-subtle"
                >
                  <div className="flex items-center gap-3 min-w-0">
                    <button
                      type="button"
                      onClick={() => quickCompleteTask(task.id)}
                      title="Отметить выполненной"
                      className="h-5 w-5 rounded-[4px] border-2 border-slate-400/60 hover:border-emerald-400 hover:bg-emerald-500/20 shrink-0 transition-colors"
                    />
                    <div className="min-w-0">
                      <p className="text-sm font-medium text-white truncate">{task.title}</p>
                      <div className="flex items-center gap-2 text-[11px] text-slate-400 mt-0.5">
                        <span>{task.category}</span>
                        {task.dueDate && <span>• до {task.dueDate}</span>}
                      </div>
                    </div>
                  </div>
                  <span
                    className={`text-[10px] font-semibold px-2 py-0.5 rounded-full shrink-0 ${
                      task.priority === 'high'
                        ? 'bg-rose-500/20 text-rose-400'
                        : task.priority === 'medium'
                          ? 'bg-amber-500/20 text-amber-400'
                          : 'bg-slate-500/20 text-slate-300'
                    }`}
                  >
                    {task.priority === 'high'
                      ? 'Высокий'
                      : task.priority === 'medium'
                        ? 'Средний'
                        : 'Низкий'}
                  </span>
                </div>
              ))}
            </div>
          )}
        </div>

        {/* Закреплённые и свежие заметки */}
        <div className="liquid-glass rounded-3xl p-5 flex flex-col">
          <div className="flex items-center justify-between mb-4">
            <h3 className="font-bold text-white flex items-center gap-2">
              <Pin className="w-4 h-4 text-amber-400" />
              <span>Быстрые заметки</span>
            </h3>
            <button
              type="button"
              onClick={() => onNavigate('notes')}
              className="text-xs text-amber-400 hover:underline flex items-center gap-1"
            >
              <span>Открыть заметки</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
          </div>

          {data.recentNotes.length === 0 ? (
            <div className="flex-1 flex flex-col items-center justify-center py-8 text-center">
              <FileText className="w-9 h-9 text-slate-400/60 mb-2" />
              <p className="text-sm text-slate-300 font-medium">Пока нет заметок</p>
              <p className="text-xs text-slate-500 mt-0.5">
                Записывайте важные идеи, списки и конспекты
              </p>
            </div>
          ) : (
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              {data.recentNotes.map((note) => (
                <div
                  key={note.id}
                  onClick={() => onNavigate('notes')}
                  className="cursor-pointer p-3.5 rounded-2xl liquid-glass-subtle hover:border-amber-400/40 flex flex-col justify-between"
                >
                  <div>
                    <div className="flex items-start justify-between gap-2">
                      <h4 className="text-sm font-semibold text-white line-clamp-1">
                        {note.title}
                      </h4>
                      {note.isPinned && (
                        <Pin className="w-3.5 h-3.5 text-amber-400 shrink-0" />
                      )}
                    </div>
                    <p className="text-xs text-slate-400 mt-1.5 line-clamp-3 whitespace-pre-line">
                      {note.content || 'Пустая заметка'}
                    </p>
                  </div>
                  {note.tags.length > 0 && (
                    <div className="flex flex-wrap gap-1 mt-3">
                      {note.tags.slice(0, 3).map((tag) => (
                        <span
                          key={tag}
                          className="text-[10px] px-1.5 py-0.5 rounded bg-amber-500/15 text-amber-400"
                        >
                          #{tag}
                        </span>
                      ))}
                    </div>
                  )}
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
