import type { HabitColor } from '@shared/constants';
import {
  habitCreateSchema,
  habitToggleSchema,
  habitUpdateSchema,
  type HabitDTO,
} from '@shared/schemas';
import { generateUuid } from '@shared/uuid';
import { dbExecute, dbQueryAll, dbQueryOne } from '../db';
import { requireAuth } from '../middleware/auth';
import type { ApiRouter } from '../lib/http';

export interface DbHabitRow {
  id: string;
  user_id: string;
  title: string;
  description: string;
  color: HabitColor;
  target_days_per_week: number;
  created_at: string;
  updated_at: string;
}

export interface DbHabitLogRow {
  id: string;
  habit_id: string;
  user_id: string;
  date: string;
  created_at: string;
}

function addDaysIso(isoDate: string, deltaDays: number): string {
  const [y, m, d] = isoDate.split('-').map(Number);
  const dt = new Date(Date.UTC(y, m - 1, d + deltaDays));
  return dt.toISOString().slice(0, 10);
}

export function computeHabitStreaks(
  sortedDatesDesc: string[],
  todayIso: string
): { currentStreak: number; bestStreak: number } {
  if (sortedDatesDesc.length === 0) {
    return { currentStreak: 0, bestStreak: 0 };
  }

  const dateSet = new Set(sortedDatesDesc);

  // Текущая серия: считается от сегодня (или от вчера, если сегодня ещё не отмечено)
  let currentStreak = 0;
  const yesterdayIso = addDaysIso(todayIso, -1);
  let cursor: string | null = null;
  if (dateSet.has(todayIso)) {
    cursor = todayIso;
  } else if (dateSet.has(yesterdayIso)) {
    cursor = yesterdayIso;
  }

  while (cursor && dateSet.has(cursor)) {
    currentStreak++;
    cursor = addDaysIso(cursor, -1);
  }

  // Лучшая серия за всё время
  const asc = Array.from(dateSet).sort();
  let bestStreak = 1;
  let run = 1;
  for (let i = 1; i < asc.length; i++) {
    if (addDaysIso(asc[i - 1], 1) === asc[i]) {
      run++;
      if (run > bestStreak) bestStreak = run;
    } else {
      run = 1;
    }
  }

  return { currentStreak, bestStreak };
}

export function buildHabitDTO(
  row: DbHabitRow,
  completedDates: string[],
  todayIso: string
): HabitDTO {
  const uniqueDesc = Array.from(new Set(completedDates)).sort((a, b) =>
    b.localeCompare(a)
  );
  const { currentStreak, bestStreak } = computeHabitStreaks(uniqueDesc, todayIso);

  return {
    id: row.id,
    title: row.title,
    description: row.description,
    color: row.color,
    targetDaysPerWeek: row.target_days_per_week,
    completedDates: uniqueDesc.slice(0, 90),
    currentStreak,
    bestStreak,
    totalCompletions: uniqueDesc.length,
    createdAt: row.created_at,
    updatedAt: row.updated_at,
  };
}

export function listUserHabitsWithStats(userId: string): HabitDTO[] {
  const habitRows = dbQueryAll<DbHabitRow>(
    'SELECT * FROM habits WHERE user_id = ? ORDER BY created_at ASC',
    [userId]
  );

  if (habitRows.length === 0) return [];

  const logRows = dbQueryAll<DbHabitLogRow>(
    'SELECT * FROM habit_logs WHERE user_id = ? ORDER BY date DESC',
    [userId]
  );

  const logsByHabit = new Map<string, string[]>();
  for (const log of logRows) {
    const arr = logsByHabit.get(log.habit_id) || [];
    arr.push(log.date);
    logsByHabit.set(log.habit_id, arr);
  }

  const todayIso = new Date().toISOString().slice(0, 10);
  return habitRows.map((h) =>
    buildHabitDTO(h, logsByHabit.get(h.id) || [], todayIso)
  );
}

export function registerHabitsRoutes(router: ApiRouter): void {
  router.get('/api/habits', requireAuth, (ctx) => {
    const habits = listUserHabitsWithStats(ctx.user.id);
    return ctx.json({ habits });
  });

  router.post('/api/habits', requireAuth, (ctx) => {
    const parsed = habitCreateSchema.safeParse(ctx.parseJson());
    if (!parsed.success) {
      const msg = parsed.error.issues[0]
        ? parsed.error.issues[0].message
        : 'Проверьте поля привычки';
      return ctx.json({ error: msg }, 400);
    }

    const body = parsed.data;
    const now = new Date().toISOString();
    const id = body.id || generateUuid();

    dbExecute(
      `INSERT INTO habits (id, user_id, title, description, color, target_days_per_week, created_at, updated_at)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?)`,
      [
        id,
        ctx.user.id,
        body.title,
        body.description || '',
        body.color || 'cyan',
        body.targetDaysPerWeek || 7,
        now,
        now,
      ]
    );

    const created = dbQueryOne<DbHabitRow>(
      'SELECT * FROM habits WHERE id = ? AND user_id = ?',
      [id, ctx.user.id]
    );

    return ctx.json(
      { habit: buildHabitDTO(created!, [], now.slice(0, 10)) },
      201
    );
  });

  router.patch('/api/habits/:id', requireAuth, (ctx) => {
    const parsed = habitUpdateSchema.safeParse(ctx.parseJson());
    if (!parsed.success) {
      const msg = parsed.error.issues[0]
        ? parsed.error.issues[0].message
        : 'Некорректные данные привычки';
      return ctx.json({ error: msg }, 400);
    }

    const id = ctx.params.id;
    const patch = parsed.data;

    const existing = dbQueryOne<DbHabitRow>(
      'SELECT * FROM habits WHERE id = ? AND user_id = ?',
      [id, ctx.user.id]
    );

    if (!existing) {
      return ctx.json({ error: 'Привычка не найдена' }, 404);
    }

    const now = new Date().toISOString();

    dbExecute(
      `UPDATE habits
       SET title = ?, description = ?, color = ?, target_days_per_week = ?, updated_at = ?
       WHERE id = ? AND user_id = ?`,
      [
        patch.title !== undefined ? patch.title : existing.title,
        patch.description !== undefined ? patch.description : existing.description,
        patch.color !== undefined ? patch.color : existing.color,
        patch.targetDaysPerWeek !== undefined
          ? patch.targetDaysPerWeek
          : existing.target_days_per_week,
        now,
        id,
        ctx.user.id,
      ]
    );

    const updated = dbQueryOne<DbHabitRow>(
      'SELECT * FROM habits WHERE id = ? AND user_id = ?',
      [id, ctx.user.id]
    );
    const logs = dbQueryAll<{ date: string }>(
      'SELECT date FROM habit_logs WHERE habit_id = ? AND user_id = ?',
      [id, ctx.user.id]
    );

    return ctx.json({
      habit: buildHabitDTO(
        updated!,
        logs.map((l) => l.date),
        now.slice(0, 10)
      ),
    });
  });

  router.post('/api/habits/:id/toggle', requireAuth, (ctx) => {
    const parsed = habitToggleSchema.safeParse(ctx.parseJson());
    if (!parsed.success) {
      return ctx.json({ error: 'Некорректная дата' }, 400);
    }

    const habitId = ctx.params.id;
    const existing = dbQueryOne<DbHabitRow>(
      'SELECT * FROM habits WHERE id = ? AND user_id = ?',
      [habitId, ctx.user.id]
    );

    if (!existing) {
      return ctx.json({ error: 'Привычка не найдена' }, 404);
    }

    const now = new Date().toISOString();
    const targetDate = parsed.data.date || now.slice(0, 10);

    const logRow = dbQueryOne<{ id: string }>(
      'SELECT id FROM habit_logs WHERE habit_id = ? AND user_id = ? AND date = ?',
      [habitId, ctx.user.id, targetDate]
    );

    let completed: boolean;
    if (logRow) {
      dbExecute('DELETE FROM habit_logs WHERE id = ?', [logRow.id]);
      completed = false;
    } else {
      dbExecute(
        'INSERT INTO habit_logs (id, habit_id, user_id, date, created_at) VALUES (?, ?, ?, ?, ?)',
        [generateUuid(), habitId, ctx.user.id, targetDate, now]
      );
      completed = true;
    }

    const logs = dbQueryAll<{ date: string }>(
      'SELECT date FROM habit_logs WHERE habit_id = ? AND user_id = ?',
      [habitId, ctx.user.id]
    );

    return ctx.json({
      completed,
      date: targetDate,
      habit: buildHabitDTO(
        existing,
        logs.map((l) => l.date),
        now.slice(0, 10)
      ),
    });
  });

  router.delete('/api/habits/:id', requireAuth, (ctx) => {
    const res = dbExecute('DELETE FROM habits WHERE id = ? AND user_id = ?', [
      ctx.params.id,
      ctx.user.id,
    ]);

    if (res.changes === 0) {
      return ctx.json({ error: 'Привычка не найдена' }, 404);
    }

    return ctx.json({ ok: true });
  });
}
