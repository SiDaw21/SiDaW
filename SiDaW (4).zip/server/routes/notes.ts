import type { NoteColor } from '@shared/constants';
import {
  noteCreateSchema,
  noteUpdateSchema,
  type NoteDTO,
} from '@shared/schemas';
import { generateUuid } from '@shared/uuid';
import { dbExecute, dbQueryAll, dbQueryOne } from '../db';
import { requireAuth } from '../middleware/auth';
import type { ApiRouter } from '../lib/http';

export interface DbNoteRow {
  id: string;
  user_id: string;
  title: string;
  content: string;
  tags_json: string;
  color: NoteColor;
  is_pinned: number;
  created_at: string;
  updated_at: string;
}

export function mapNoteRow(row: DbNoteRow): NoteDTO {
  let parsedTags: string[] = [];
  try {
    const raw = JSON.parse(row.tags_json);
    if (Array.isArray(raw)) {
      parsedTags = raw.map((t) => String(t));
    }
  } catch {
    parsedTags = [];
  }

  return {
    id: row.id,
    title: row.title,
    content: row.content,
    tags: parsedTags,
    color: row.color,
    isPinned: Boolean(row.is_pinned),
    createdAt: row.created_at,
    updatedAt: row.updated_at,
  };
}

export function registerNotesRoutes(router: ApiRouter): void {
  router.get('/api/notes', requireAuth, (ctx) => {
    const rows = dbQueryAll<DbNoteRow>(
      'SELECT * FROM notes WHERE user_id = ? ORDER BY is_pinned DESC, updated_at DESC',
      [ctx.user.id]
    );

    return ctx.json({ notes: rows.map(mapNoteRow) });
  });

  router.post('/api/notes', requireAuth, (ctx) => {
    const parsed = noteCreateSchema.safeParse(ctx.parseJson());
    if (!parsed.success) {
      const msg = parsed.error.issues[0] ? parsed.error.issues[0].message : 'Проверьте поля заметки';
      return ctx.json({ error: msg }, 400);
    }

    const body = parsed.data;
    const now = new Date().toISOString();
    const id = body.id || generateUuid();
    const cleanTags = Array.from(
      new Set((body.tags || []).map((t) => t.trim()).filter(Boolean))
    );

    dbExecute(
      `INSERT INTO notes (id, user_id, title, content, tags_json, color, is_pinned, created_at, updated_at)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`,
      [
        id,
        ctx.user.id,
        body.title,
        body.content || '',
        JSON.stringify(cleanTags),
        body.color || 'default',
        body.isPinned ? 1 : 0,
        now,
        now,
      ]
    );

    const created = dbQueryOne<DbNoteRow>(
      'SELECT * FROM notes WHERE id = ? AND user_id = ?',
      [id, ctx.user.id]
    );

    return ctx.json({ note: mapNoteRow(created!) }, 201);
  });

  router.patch('/api/notes/:id', requireAuth, (ctx) => {
    const parsed = noteUpdateSchema.safeParse(ctx.parseJson());
    if (!parsed.success) {
      const msg = parsed.error.issues[0] ? parsed.error.issues[0].message : 'Некорректные данные';
      return ctx.json({ error: msg }, 400);
    }

    const id = ctx.params.id;
    const patch = parsed.data;

    const existing = dbQueryOne<DbNoteRow>(
      'SELECT * FROM notes WHERE id = ? AND user_id = ?',
      [id, ctx.user.id]
    );

    if (!existing) {
      return ctx.json({ error: 'Заметка не найдена' }, 404);
    }

    const now = new Date().toISOString();
    const nextTagsJson =
      patch.tags !== undefined
        ? JSON.stringify(
            Array.from(new Set(patch.tags.map((t) => t.trim()).filter(Boolean)))
          )
        : existing.tags_json;

    const nextPinned =
      patch.isPinned !== undefined ? (patch.isPinned ? 1 : 0) : existing.is_pinned;

    dbExecute(
      `UPDATE notes
       SET title = ?, content = ?, tags_json = ?, color = ?, is_pinned = ?, updated_at = ?
       WHERE id = ? AND user_id = ?`,
      [
        patch.title !== undefined ? patch.title : existing.title,
        patch.content !== undefined ? patch.content : existing.content,
        nextTagsJson,
        patch.color !== undefined ? patch.color : existing.color,
        nextPinned,
        now,
        id,
        ctx.user.id,
      ]
    );

    const updated = dbQueryOne<DbNoteRow>(
      'SELECT * FROM notes WHERE id = ? AND user_id = ?',
      [id, ctx.user.id]
    );

    return ctx.json({ note: mapNoteRow(updated!) });
  });

  router.delete('/api/notes/:id', requireAuth, (ctx) => {
    const res = dbExecute('DELETE FROM notes WHERE id = ? AND user_id = ?', [
      ctx.params.id,
      ctx.user.id,
    ]);

    if (res.changes === 0) {
      return ctx.json({ error: 'Заметка не найдена' }, 404);
    }

    return ctx.json({ ok: true });
  });
}
