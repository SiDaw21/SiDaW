import type { TaskPriority, TaskStatus } from '@shared/constants';
import {
  taskCreateSchema,
  taskUpdateSchema,
  type TaskDTO,
} from '@shared/schemas';
import { generateUuid } from '@shared/uuid';
import { dbExecute, dbQueryAll, dbQueryOne } from '../db';
import { requireAuth } from '../middleware/auth';
import type { ApiRouter } from '../lib/http';

export interface DbTaskRow {
  id: string;
  user_id: string;
  title: string;
  description: string;
  status: TaskStatus;
  priority: TaskPriority;
  category: string;
  due_date: string | null;
  completed_at: string | null;
  created_at: string;
  updated_at: string;
}

export function mapTaskRow(row: DbTaskRow): TaskDTO {
  return {
    id: row.id,
    title: row.title,
    description: row.description,
    status: row.status,
    priority: row.priority,
    category: row.category,
    dueDate: row.due_date,
    completedAt: row.completed_at,
    createdAt: row.created_at,
    updatedAt: row.updated_at,
  };
}

export function registerTasksRoutes(router: ApiRouter): void {
  router.get('/api/tasks', requireAuth, (ctx) => {
    const rows = dbQueryAll<DbTaskRow>(
      'SELECT * FROM tasks WHERE user_id = ? ORDER BY updated_at DESC',
      [ctx.user.id]
    );

    const priorityRank: Record<string, number> = { high: 0, medium: 1, low: 2 };
    const statusRank: Record<string, number> = { in_progress: 0, todo: 1, done: 2 };

    const sorted = rows
      .map(mapTaskRow)
      .sort((a, b) => {
        if (statusRank[a.status] !== statusRank[b.status]) {
          return statusRank[a.status] - statusRank[b.status];
        }
        if (priorityRank[a.priority] !== priorityRank[b.priority]) {
          return priorityRank[a.priority] - priorityRank[b.priority];
        }
        return b.updatedAt.localeCompare(a.updatedAt);
      });

    return ctx.json({ tasks: sorted });
  });

  router.post('/api/tasks', requireAuth, (ctx) => {
    const parsed = taskCreateSchema.safeParse(ctx.parseJson());
    if (!parsed.success) {
      const msg = parsed.error.issues[0] ? parsed.error.issues[0].message : 'Проверьте поля задачи';
      return ctx.json({ error: msg }, 400);
    }

    const body = parsed.data;
    const now = new Date().toISOString();
    const id = body.id || generateUuid();
    const status = body.status || 'todo';
    const completedAt = status === 'done' ? now : null;

    dbExecute(
      `INSERT INTO tasks (id, user_id, title, description, status, priority, category, due_date, completed_at, created_at, updated_at)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
      [
        id,
        ctx.user.id,
        body.title,
        body.description || '',
        status,
        body.priority || 'medium',
        body.category || 'Личное',
        body.dueDate || null,
        completedAt,
        now,
        now,
      ]
    );

    const created = dbQueryOne<DbTaskRow>(
      'SELECT * FROM tasks WHERE id = ? AND user_id = ?',
      [id, ctx.user.id]
    );

    return ctx.json({ task: mapTaskRow(created!) }, 201);
  });

  router.patch('/api/tasks/:id', requireAuth, (ctx) => {
    const parsed = taskUpdateSchema.safeParse(ctx.parseJson());
    if (!parsed.success) {
      const msg = parsed.error.issues[0] ? parsed.error.issues[0].message : 'Некорректные данные';
      return ctx.json({ error: msg }, 400);
    }

    const id = ctx.params.id;
    const patch = parsed.data;

    const existing = dbQueryOne<DbTaskRow>(
      'SELECT * FROM tasks WHERE id = ? AND user_id = ?',
      [id, ctx.user.id]
    );

    if (!existing) {
      return ctx.json({ error: 'Задача не найдена' }, 404);
    }

    const now = new Date().toISOString();
    const nextStatus = patch.status !== undefined ? patch.status : existing.status;

    let nextCompletedAt = existing.completed_at;
    if (patch.status !== undefined) {
      nextCompletedAt = nextStatus === 'done' ? existing.completed_at || now : null;
    }

    dbExecute(
      `UPDATE tasks
       SET title = ?, description = ?, status = ?, priority = ?, category = ?, due_date = ?, completed_at = ?, updated_at = ?
       WHERE id = ? AND user_id = ?`,
      [
        patch.title !== undefined ? patch.title : existing.title,
        patch.description !== undefined ? patch.description : existing.description,
        nextStatus,
        patch.priority !== undefined ? patch.priority : existing.priority,
        patch.category !== undefined ? patch.category : existing.category,
        patch.dueDate !== undefined ? patch.dueDate || null : existing.due_date,
        nextCompletedAt,
        now,
        id,
        ctx.user.id,
      ]
    );

    const updated = dbQueryOne<DbTaskRow>(
      'SELECT * FROM tasks WHERE id = ? AND user_id = ?',
      [id, ctx.user.id]
    );

    return ctx.json({ task: mapTaskRow(updated!) });
  });

  router.delete('/api/tasks/:id', requireAuth, (ctx) => {
    const res = dbExecute('DELETE FROM tasks WHERE id = ? AND user_id = ?', [
      ctx.params.id,
      ctx.user.id,
    ]);

    if (res.changes === 0) {
      return ctx.json({ error: 'Задача не найдена' }, 404);
    }

    return ctx.json({ ok: true });
  });
}
