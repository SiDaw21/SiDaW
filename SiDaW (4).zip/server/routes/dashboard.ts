import type { DashboardSummaryDTO, TransactionDTO } from '@shared/schemas';
import { dbQueryAll } from '../db';
import { requireAuth } from '../middleware/auth';
import type { ApiRouter } from '../lib/http';
import { mapTaskRow, type DbTaskRow } from './tasks';
import { listUserHabitsWithStats } from './habits';
import { mapNoteRow, type DbNoteRow } from './notes';
import { mapAccountRow, type DbAccountRow, type DbTxJoinRow } from './finance';

export function registerDashboardRoutes(router: ApiRouter): void {
  router.get('/api/dashboard', requireAuth, (ctx) => {
    const todayIso = new Date().toISOString().slice(0, 10);
    const currentMonthPrefix = todayIso.slice(0, 7);

    // 1. Задачи
    const userTasks = dbQueryAll<DbTaskRow>(
      'SELECT * FROM tasks WHERE user_id = ? ORDER BY updated_at DESC',
      [ctx.user.id]
    );

    const priorityRank: Record<string, number> = { high: 0, medium: 1, low: 2 };

    const activeTasks = userTasks
      .filter((t) => t.status !== 'done')
      .sort((a, b) => {
        if (priorityRank[a.priority] !== priorityRank[b.priority]) {
          return priorityRank[a.priority] - priorityRank[b.priority];
        }
        return b.updated_at.localeCompare(a.updated_at);
      })
      .slice(0, 5)
      .map(mapTaskRow);

    const tasksStats = {
      total: userTasks.length,
      todo: userTasks.filter((t) => t.status === 'todo').length,
      inProgress: userTasks.filter((t) => t.status === 'in_progress').length,
      done: userTasks.filter((t) => t.status === 'done').length,
      overdue: userTasks.filter(
        (t) => t.status !== 'done' && t.due_date && t.due_date < todayIso
      ).length,
    };

    // 1.5. Привычки
    const userHabits = listUserHabitsWithStats(ctx.user.id);
    const habitsStats = {
      total: userHabits.length,
      completedToday: userHabits.filter((h) => h.completedDates.indexOf(todayIso) !== -1)
        .length,
      bestActiveStreak: userHabits.reduce(
        (max, h) => (h.currentStreak > max ? h.currentStreak : max),
        0
      ),
    };

    // 2. Заметки
    const userNotes = dbQueryAll<DbNoteRow>(
      'SELECT * FROM notes WHERE user_id = ? ORDER BY is_pinned DESC, updated_at DESC',
      [ctx.user.id]
    );

    const notesStats = {
      total: userNotes.length,
      pinned: userNotes.filter((n) => Boolean(n.is_pinned)).length,
    };

    const recentNotes = userNotes.slice(0, 4).map(mapNoteRow);

    // 3. Финансы
    const userAccounts = dbQueryAll<DbAccountRow>(
      'SELECT * FROM accounts WHERE user_id = ? ORDER BY created_at DESC',
      [ctx.user.id]
    );

    const balancesByCurrency: Record<string, number> = {};
    for (const acc of userAccounts) {
      balancesByCurrency[acc.currency] =
        Math.round(((balancesByCurrency[acc.currency] || 0) + acc.balance) * 100) / 100;
    }

    const txRows = dbQueryAll<DbTxJoinRow>(
      `SELECT t.*, a.name AS account_name, a.currency
       FROM transactions t
       INNER JOIN accounts a ON a.id = t.account_id
       WHERE t.user_id = ?
       ORDER BY t.date DESC, t.created_at DESC`,
      [ctx.user.id]
    );

    const monthIncomeByCurrency: Record<string, number> = {};
    const monthExpenseByCurrency: Record<string, number> = {};

    for (const row of txRows) {
      if (row.date.indexOf(currentMonthPrefix) === 0) {
        if (row.type === 'income') {
          monthIncomeByCurrency[row.currency] =
            Math.round(((monthIncomeByCurrency[row.currency] || 0) + row.amount) * 100) /
            100;
        } else {
          monthExpenseByCurrency[row.currency] =
            Math.round(
              ((monthExpenseByCurrency[row.currency] || 0) + row.amount) * 100
            ) / 100;
        }
      }
    }

    const recentTransactions: TransactionDTO[] = txRows.slice(0, 5).map((row) => ({
      id: row.id,
      accountId: row.account_id,
      accountName: row.account_name,
      currency: row.currency,
      type: row.type,
      amount: Math.round(row.amount * 100) / 100,
      category: row.category,
      description: row.description,
      date: row.date,
      createdAt: row.created_at,
      updatedAt: row.updated_at,
    }));

    const summary: DashboardSummaryDTO = {
      tasksStats,
      activeTasks,
      habitsStats,
      notesStats,
      recentNotes,
      financeStats: {
        balancesByCurrency,
        monthIncomeByCurrency,
        monthExpenseByCurrency,
      },
      accounts: userAccounts.map(mapAccountRow),
      recentTransactions,
    };

    return ctx.json(summary);
  });
}
