import { APP_CONFIG } from '@shared/constants';
import { generateUuid } from '@shared/uuid';
import { dbExecute, dbQueryAll, dbQueryOne, dbTransaction } from '../db';
import { requireAuth } from '../middleware/auth';
import type { ApiRouter } from '../lib/http';
import { mapTaskRow, type DbTaskRow } from './tasks';
import { listUserHabitsWithStats } from './habits';
import { mapNoteRow, type DbNoteRow } from './notes';
import { mapAccountRow, type DbAccountRow } from './finance';

export function registerBackupRoutes(router: ApiRouter): void {
  router.get('/api/backup/export', requireAuth, (ctx) => {
    const userTasks = dbQueryAll<DbTaskRow>(
      'SELECT * FROM tasks WHERE user_id = ? ORDER BY updated_at DESC',
      [ctx.user.id]
    ).map(mapTaskRow);

    const userHabits = listUserHabitsWithStats(ctx.user.id);

    const userNotes = dbQueryAll<DbNoteRow>(
      'SELECT * FROM notes WHERE user_id = ? ORDER BY updated_at DESC',
      [ctx.user.id]
    ).map(mapNoteRow);

    const userAccounts = dbQueryAll<DbAccountRow>(
      'SELECT * FROM accounts WHERE user_id = ?',
      [ctx.user.id]
    ).map(mapAccountRow);

    const userTransactions = dbQueryAll(
      'SELECT * FROM transactions WHERE user_id = ? ORDER BY date DESC',
      [ctx.user.id]
    );

    return ctx.json({
      app: APP_CONFIG.name,
      version: '1.1',
      exportedAt: new Date().toISOString(),
      user: {
        email: ctx.user.email,
        name: ctx.user.name,
        defaultCurrency: ctx.user.defaultCurrency,
      },
      data: {
        tasks: userTasks,
        habits: userHabits,
        notes: userNotes,
        accounts: userAccounts,
        transactions: userTransactions,
      },
    });
  });

  /**
   * POST /api/backup/import — безопасное восстановление задач, заметок и финансов из JSON-бэкапа
   */
  router.post('/api/backup/import', requireAuth, (ctx) => {
    const body = ctx.parseJson<{ data?: any }>();
    const payload = body && body.data ? body.data : null;

    if (!payload || typeof payload !== 'object') {
      return ctx.json({ error: 'Файл не похож на резервную копию SiDaW' }, 400);
    }

    const now = new Date().toISOString();
    let importedCount = 0;

    dbTransaction(() => {
      // 1. Импорт счетов (сопоставляем старый ID -> актуальный ID)
      const accountIdMap = new Map<string, string>();
      if (Array.isArray(payload.accounts)) {
        for (const acc of payload.accounts) {
          if (!acc || !acc.name) continue;
          const existing = acc.id
            ? dbQueryOne<{ id: string }>(
                'SELECT id FROM accounts WHERE id = ? AND user_id = ?',
                [String(acc.id), ctx.user.id]
              )
            : undefined;

          if (existing) {
            accountIdMap.set(String(acc.id), existing.id);
          } else {
            const newId = generateUuid();
            if (acc.id) accountIdMap.set(String(acc.id), newId);
            dbExecute(
              `INSERT INTO accounts (id, user_id, name, type, currency, balance, color, created_at, updated_at)
               VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`,
              [
                newId,
                ctx.user.id,
                String(acc.name).slice(0, 80),
                acc.type || 'card',
                acc.currency || ctx.user.defaultCurrency,
                Number(acc.balance) || 0,
                acc.color || '#10b981',
                acc.createdAt || now,
                now,
              ]
            );
            importedCount++;
          }
        }
      }

      // 2. Импорт задач
      if (Array.isArray(payload.tasks)) {
        for (const t of payload.tasks) {
          if (!t || !t.title) continue;
          const exists = t.id
            ? dbQueryOne<{ id: string }>(
                'SELECT id FROM tasks WHERE id = ? AND user_id = ?',
                [String(t.id), ctx.user.id]
              )
            : undefined;
          if (exists) continue;

          dbExecute(
            `INSERT INTO tasks (id, user_id, title, description, status, priority, category, due_date, completed_at, created_at, updated_at)
             VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
            [
              generateUuid(),
              ctx.user.id,
              String(t.title).slice(0, 200),
              String(t.description || ''),
              t.status || 'todo',
              t.priority || 'medium',
              String(t.category || 'Личное'),
              t.dueDate || t.due_date || null,
              t.completedAt || t.completed_at || null,
              t.createdAt || t.created_at || now,
              now,
            ]
          );
          importedCount++;
        }
      }

      // 2.5. Импорт привычек
      if (Array.isArray(payload.habits)) {
        for (const h of payload.habits) {
          if (!h || !h.title) continue;
          const exists = h.id
            ? dbQueryOne<{ id: string }>(
                'SELECT id FROM habits WHERE id = ? AND user_id = ?',
                [String(h.id), ctx.user.id]
              )
            : undefined;
          if (exists) continue;

          const newHabitId = generateUuid();
          dbExecute(
            `INSERT INTO habits (id, user_id, title, description, color, target_days_per_week, created_at, updated_at)
             VALUES (?, ?, ?, ?, ?, ?, ?, ?)`,
            [
              newHabitId,
              ctx.user.id,
              String(h.title).slice(0, 120),
              String(h.description || ''),
              h.color || 'cyan',
              Number(h.targetDaysPerWeek) || 7,
              h.createdAt || now,
              now,
            ]
          );
          if (Array.isArray(h.completedDates)) {
            for (const dt of h.completedDates) {
              if (typeof dt === 'string' && /^\d{4}-\d{2}-\d{2}$/.test(dt)) {
                dbExecute(
                  'INSERT OR IGNORE INTO habit_logs (id, habit_id, user_id, date, created_at) VALUES (?, ?, ?, ?, ?)',
                  [generateUuid(), newHabitId, ctx.user.id, dt, now]
                );
              }
            }
          }
          importedCount++;
        }
      }

      // 3. Импорт заметок
      if (Array.isArray(payload.notes)) {
        for (const n of payload.notes) {
          if (!n || !n.title) continue;
          const exists = n.id
            ? dbQueryOne<{ id: string }>(
                'SELECT id FROM notes WHERE id = ? AND user_id = ?',
                [String(n.id), ctx.user.id]
              )
            : undefined;
          if (exists) continue;

          const tagsArr = Array.isArray(n.tags) ? n.tags : [];
          dbExecute(
            `INSERT INTO notes (id, user_id, title, content, tags_json, color, is_pinned, created_at, updated_at)
             VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`,
            [
              generateUuid(),
              ctx.user.id,
              String(n.title).slice(0, 200),
              String(n.content || ''),
              JSON.stringify(tagsArr),
              n.color || 'default',
              n.isPinned || n.is_pinned ? 1 : 0,
              n.createdAt || n.created_at || now,
              now,
            ]
          );
          importedCount++;
        }
      }

      // 4. Импорт операций
      if (Array.isArray(payload.transactions)) {
        for (const tx of payload.transactions) {
          if (!tx || !tx.amount) continue;
          const origAccId = String(tx.accountId || tx.account_id || '');
          const mappedAccId = accountIdMap.get(origAccId) || origAccId;
          const validAcc = dbQueryOne<{ id: string }>(
            'SELECT id FROM accounts WHERE id = ? AND user_id = ?',
            [mappedAccId, ctx.user.id]
          );
          if (!validAcc) continue;

          const exists = tx.id
            ? dbQueryOne<{ id: string }>(
                'SELECT id FROM transactions WHERE id = ? AND user_id = ?',
                [String(tx.id), ctx.user.id]
              )
            : undefined;
          if (exists) continue;

          dbExecute(
            `INSERT INTO transactions (id, user_id, account_id, type, amount, category, description, date, created_at, updated_at)
             VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
            [
              generateUuid(),
              ctx.user.id,
              validAcc.id,
              tx.type === 'income' ? 'income' : 'expense',
              Number(tx.amount) || 0,
              String(tx.category || 'Другое'),
              String(tx.description || ''),
              String(tx.date || now.slice(0, 10)),
              tx.createdAt || tx.created_at || now,
              now,
            ]
          );
          importedCount++;
        }
      }
    });

    return ctx.json({ ok: true, importedCount });
  });
}
