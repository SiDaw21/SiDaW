import type { AccountType, CurrencyCode, TransactionType } from '@shared/constants';
import {
  accountCreateSchema,
  accountUpdateSchema,
  transactionCreateSchema,
  type AccountDTO,
  type TransactionDTO,
} from '@shared/schemas';
import { generateUuid } from '@shared/uuid';
import { dbExecute, dbQueryAll, dbQueryOne, dbTransaction } from '../db';
import { requireAuth } from '../middleware/auth';
import type { ApiRouter } from '../lib/http';

export interface DbAccountRow {
  id: string;
  user_id: string;
  name: string;
  type: AccountType;
  currency: CurrencyCode;
  balance: number;
  color: string;
  created_at: string;
  updated_at: string;
}

export interface DbTxJoinRow {
  id: string;
  user_id: string;
  account_id: string;
  type: TransactionType;
  amount: number;
  category: string;
  description: string;
  date: string;
  created_at: string;
  updated_at: string;
  account_name: string;
  currency: CurrencyCode;
}

function roundMoney(value: number): number {
  return Math.round(value * 100) / 100;
}

export function mapAccountRow(row: DbAccountRow): AccountDTO {
  return {
    id: row.id,
    name: row.name,
    type: row.type,
    currency: row.currency,
    balance: roundMoney(row.balance),
    color: row.color,
    createdAt: row.created_at,
    updatedAt: row.updated_at,
  };
}

export function registerFinanceRoutes(router: ApiRouter): void {
  router.get('/api/finance/accounts', requireAuth, (ctx) => {
    const rows = dbQueryAll<DbAccountRow>(
      'SELECT * FROM accounts WHERE user_id = ? ORDER BY created_at DESC',
      [ctx.user.id]
    );

    return ctx.json({ accounts: rows.map(mapAccountRow) });
  });

  router.post('/api/finance/accounts', requireAuth, (ctx) => {
    const parsed = accountCreateSchema.safeParse(ctx.parseJson());
    if (!parsed.success) {
      const msg = parsed.error.issues[0] ? parsed.error.issues[0].message : 'Проверьте поля счёта';
      return ctx.json({ error: msg }, 400);
    }

    const body = parsed.data;
    const now = new Date().toISOString();
    const id = body.id || generateUuid();

    dbExecute(
      `INSERT INTO accounts (id, user_id, name, type, currency, balance, color, created_at, updated_at)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`,
      [
        id,
        ctx.user.id,
        body.name,
        body.type || 'card',
        body.currency || ctx.user.defaultCurrency,
        roundMoney(body.initialBalance || 0),
        body.color || '#6366f1',
        now,
        now,
      ]
    );

    const created = dbQueryOne<DbAccountRow>(
      'SELECT * FROM accounts WHERE id = ? AND user_id = ?',
      [id, ctx.user.id]
    );

    return ctx.json({ account: mapAccountRow(created!) }, 201);
  });

  router.patch('/api/finance/accounts/:id', requireAuth, (ctx) => {
    const parsed = accountUpdateSchema.safeParse(ctx.parseJson());
    if (!parsed.success) {
      const msg = parsed.error.issues[0] ? parsed.error.issues[0].message : 'Некорректные данные';
      return ctx.json({ error: msg }, 400);
    }

    const id = ctx.params.id;
    const patch = parsed.data;

    const existing = dbQueryOne<DbAccountRow>(
      'SELECT * FROM accounts WHERE id = ? AND user_id = ?',
      [id, ctx.user.id]
    );

    if (!existing) {
      return ctx.json({ error: 'Счёт не найден' }, 404);
    }

    dbExecute(
      `UPDATE accounts SET name = ?, type = ?, color = ?, updated_at = ?
       WHERE id = ? AND user_id = ?`,
      [
        patch.name !== undefined ? patch.name : existing.name,
        patch.type !== undefined ? patch.type : existing.type,
        patch.color !== undefined ? patch.color : existing.color,
        new Date().toISOString(),
        id,
        ctx.user.id,
      ]
    );

    const updated = dbQueryOne<DbAccountRow>(
      'SELECT * FROM accounts WHERE id = ? AND user_id = ?',
      [id, ctx.user.id]
    );

    return ctx.json({ account: mapAccountRow(updated!) });
  });

  router.delete('/api/finance/accounts/:id', requireAuth, (ctx) => {
    const res = dbExecute('DELETE FROM accounts WHERE id = ? AND user_id = ?', [
      ctx.params.id,
      ctx.user.id,
    ]);

    if (res.changes === 0) {
      return ctx.json({ error: 'Счёт не найден' }, 404);
    }

    return ctx.json({ ok: true });
  });

  router.get('/api/finance/transactions', requireAuth, (ctx) => {
    const rows = dbQueryAll<DbTxJoinRow>(
      `SELECT t.*, a.name AS account_name, a.currency
       FROM transactions t
       INNER JOIN accounts a ON a.id = t.account_id
       WHERE t.user_id = ?
       ORDER BY t.date DESC, t.created_at DESC`,
      [ctx.user.id]
    );

    const items: TransactionDTO[] = rows.map((row) => ({
      id: row.id,
      accountId: row.account_id,
      accountName: row.account_name,
      currency: row.currency,
      type: row.type,
      amount: roundMoney(row.amount),
      category: row.category,
      description: row.description,
      date: row.date,
      createdAt: row.created_at,
      updatedAt: row.updated_at,
    }));

    return ctx.json({ transactions: items });
  });

  router.post('/api/finance/transactions', requireAuth, (ctx) => {
    const parsed = transactionCreateSchema.safeParse(ctx.parseJson());
    if (!parsed.success) {
      const msg = parsed.error.issues[0] ? parsed.error.issues[0].message : 'Проверьте поля операции';
      return ctx.json({ error: msg }, 400);
    }

    const body = parsed.data;
    const account = dbQueryOne<DbAccountRow>(
      'SELECT * FROM accounts WHERE id = ? AND user_id = ?',
      [body.accountId, ctx.user.id]
    );

    if (!account) {
      return ctx.json({ error: 'Выбранный счёт не найден' }, 404);
    }

    const now = new Date().toISOString();
    const txId = body.id || generateUuid();
    const txDate = body.date || now.slice(0, 10);
    const cleanAmount = roundMoney(body.amount);
    const delta = body.type === 'income' ? cleanAmount : -cleanAmount;
    const nextBalance = roundMoney(account.balance + delta);

    dbTransaction(() => {
      dbExecute(
        `INSERT INTO transactions (id, user_id, account_id, type, amount, category, description, date, created_at, updated_at)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
        [
          txId,
          ctx.user.id,
          account.id,
          body.type,
          cleanAmount,
          body.category,
          body.description || '',
          txDate,
          now,
          now,
        ]
      );

      dbExecute('UPDATE accounts SET balance = ?, updated_at = ? WHERE id = ?', [
        nextBalance,
        now,
        account.id,
      ]);
    });

    const txDto: TransactionDTO = {
      id: txId,
      accountId: account.id,
      accountName: account.name,
      currency: account.currency,
      type: body.type,
      amount: cleanAmount,
      category: body.category,
      description: body.description || '',
      date: txDate,
      createdAt: now,
      updatedAt: now,
    };

    return ctx.json(
      {
        transaction: txDto,
        accountBalance: nextBalance,
      },
      201
    );
  });

  router.delete('/api/finance/transactions/:id', requireAuth, (ctx) => {
    const existing = dbQueryOne<{
      id: string;
      account_id: string;
      type: TransactionType;
      amount: number;
    }>('SELECT id, account_id, type, amount FROM transactions WHERE id = ? AND user_id = ?', [
      ctx.params.id,
      ctx.user.id,
    ]);

    if (!existing) {
      return ctx.json({ error: 'Операция не найдена' }, 404);
    }

    const account = dbQueryOne<DbAccountRow>(
      'SELECT * FROM accounts WHERE id = ? AND user_id = ?',
      [existing.account_id, ctx.user.id]
    );

    const now = new Date().toISOString();

    dbTransaction(() => {
      dbExecute('DELETE FROM transactions WHERE id = ? AND user_id = ?', [
        existing.id,
        ctx.user.id,
      ]);

      if (account) {
        const reverseDelta =
          existing.type === 'income' ? -existing.amount : existing.amount;
        dbExecute('UPDATE accounts SET balance = ?, updated_at = ? WHERE id = ?', [
          roundMoney(account.balance + reverseDelta),
          now,
          account.id,
        ]);
      }
    });

    return ctx.json({ ok: true });
  });
}
