import { APP_CONFIG, type CurrencyCode } from '@shared/constants';
import {
  changePasswordSchema,
  DEFAULT_USER_SETTINGS,
  loginSchema,
  registerSchema,
  userSettingsPatchSchema,
  type AuthResponseDTO,
  type SessionDTO,
  type UserDTO,
} from '@shared/schemas';
import { generateUuid } from '@shared/uuid';
import { dbExecute, dbQueryAll, dbQueryOne } from '../db';
import {
  generateSessionToken,
  hashPassword,
  hashSessionToken,
  parseDeviceLabel,
  verifyPassword,
} from '../auth/crypto';
import { seedNewUserWorkspace } from '../auth/seed-user';
import { parseUserSettingsJson, requireAuth } from '../middleware/auth';
import type { ApiRouter, RequestContext } from '../lib/http';

function getSessionTtlDays(): number {
  const parsed = Number(process.env.SESSION_TTL_DAYS);
  return Number.isFinite(parsed) && parsed > 0 ? parsed : APP_CONFIG.defaultSessionDays;
}

function issueUserSession(
  ctx: RequestContext,
  userId: string
): { token: string; session: SessionDTO } {
  const rawToken = generateSessionToken();
  const tokenHash = hashSessionToken(rawToken);
  const userAgent = ctx.header('user-agent') || '';
  const deviceLabel = parseDeviceLabel(userAgent);

  const now = new Date();
  const ttlDays = getSessionTtlDays();
  const expiresAt = new Date(now.getTime() + ttlDays * 24 * 60 * 60 * 1000);
  const sessionId = generateUuid();
  const nowIso = now.toISOString();
  const expIso = expiresAt.toISOString();

  dbExecute(
    `INSERT INTO sessions (id, user_id, token_hash, device_label, user_agent, created_at, last_seen_at, expires_at)
     VALUES (?, ?, ?, ?, ?, ?, ?, ?)`,
    [sessionId, userId, tokenHash, deviceLabel, userAgent.slice(0, 300), nowIso, nowIso, expIso]
  );

  const proto = (ctx.header('x-forwarded-proto') || '').toLowerCase();
  const origin = (ctx.header('origin') || '').toLowerCase();
  const isHttps = proto.indexOf('https') !== -1 || origin.indexOf('https://') === 0;

  ctx.setCookie(APP_CONFIG.sessionCookieName, rawToken, {
    httpOnly: true,
    secure: isHttps,
    sameSite: isHttps ? 'None' : 'Lax',
    partitioned: isHttps,
    path: '/',
    maxAge: ttlDays * 24 * 60 * 60,
  });

  return {
    token: rawToken,
    session: {
      id: sessionId,
      deviceLabel,
      createdAt: nowIso,
      lastSeenAt: nowIso,
      expiresAt: expIso,
      isCurrent: true,
    },
  };
}

export function registerAuthRoutes(router: ApiRouter): void {
  router.post('/api/auth/register', async (ctx) => {
    const parsed = registerSchema.safeParse(ctx.parseJson());
    if (!parsed.success) {
      const msg = parsed.error.issues[0] ? parsed.error.issues[0].message : 'Проверьте поля';
      return ctx.json({ error: msg }, 400);
    }

    const { name, email, password, defaultCurrency } = parsed.data;

    const existing = dbQueryOne<{ id: string }>(
      'SELECT id FROM users WHERE email = ?',
      [email]
    );
    if (existing) {
      return ctx.json({ error: 'Пользователь с таким email уже зарегистрирован' }, 409);
    }

    const nowIso = new Date().toISOString();
    const userId = generateUuid();
    const passwordHash = await hashPassword(password);
    const initialSettings = { ...DEFAULT_USER_SETTINGS };

    dbExecute(
      `INSERT INTO users (id, email, name, password_hash, default_currency, settings_json, created_at, updated_at)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?)`,
      [
        userId,
        email,
        name,
        passwordHash,
        defaultCurrency,
        JSON.stringify(initialSettings),
        nowIso,
        nowIso,
      ]
    );

    seedNewUserWorkspace(userId, defaultCurrency);

    const { token, session } = issueUserSession(ctx, userId);

    const userDto: UserDTO = {
      id: userId,
      email,
      name,
      defaultCurrency,
      settings: initialSettings,
      createdAt: nowIso,
    };

    const response: AuthResponseDTO = { user: userDto, token, session };
    return ctx.json(response, 201);
  });

  router.post('/api/auth/login', async (ctx) => {
    const parsed = loginSchema.safeParse(ctx.parseJson());
    if (!parsed.success) {
      const msg = parsed.error.issues[0] ? parsed.error.issues[0].message : 'Неверные данные';
      return ctx.json({ error: msg }, 400);
    }

    const { email, password } = parsed.data;

    const userRow = dbQueryOne<{
      id: string;
      email: string;
      name: string;
      password_hash: string;
      default_currency: CurrencyCode;
      settings_json: string;
      created_at: string;
    }>('SELECT * FROM users WHERE email = ?', [email]);

    if (!userRow) {
      return ctx.json({ error: 'Неверный email или пароль' }, 401);
    }

    const isValid = await verifyPassword(password, userRow.password_hash);
    if (!isValid) {
      return ctx.json({ error: 'Неверный email или пароль' }, 401);
    }

    const { token, session } = issueUserSession(ctx, userRow.id);

    const response: AuthResponseDTO = {
      user: {
        id: userRow.id,
        email: userRow.email,
        name: userRow.name,
        defaultCurrency: userRow.default_currency,
        settings: parseUserSettingsJson(userRow.settings_json),
        createdAt: userRow.created_at,
      },
      token,
      session,
    };

    return ctx.json(response);
  });

  router.get('/api/auth/me', requireAuth, (ctx) => {
    return ctx.json({
      user: ctx.user,
      session: {
        ...ctx.session,
        isCurrent: true,
      },
    });
  });

  /**
   * PATCH /api/auth/settings — сохранение персональных настроек темы, фона и интерфейса
   */
  router.patch('/api/auth/settings', requireAuth, (ctx) => {
    const parsed = userSettingsPatchSchema.safeParse(ctx.parseJson());
    if (!parsed.success) {
      return ctx.json({ error: 'Некорректные параметры настроек' }, 400);
    }

    const merged = {
      ...(ctx.user.settings || DEFAULT_USER_SETTINGS),
      ...parsed.data,
    };

    dbExecute('UPDATE users SET settings_json = ?, updated_at = ? WHERE id = ?', [
      JSON.stringify(merged),
      new Date().toISOString(),
      ctx.user.id,
    ]);

    return ctx.json({ settings: merged });
  });

  router.post('/api/auth/logout', requireAuth, (ctx) => {
    dbExecute('DELETE FROM sessions WHERE id = ?', [ctx.session.id]);
    ctx.deleteCookie(APP_CONFIG.sessionCookieName, '/');
    return ctx.json({ ok: true });
  });

  router.get('/api/auth/sessions', requireAuth, (ctx) => {
    const rows = dbQueryAll<{
      id: string;
      device_label: string;
      created_at: string;
      last_seen_at: string;
      expires_at: string;
    }>(
      'SELECT id, device_label, created_at, last_seen_at, expires_at FROM sessions WHERE user_id = ? ORDER BY last_seen_at DESC',
      [ctx.user.id]
    );

    const items: SessionDTO[] = rows.map((row) => ({
      id: row.id,
      deviceLabel: row.device_label,
      createdAt: row.created_at,
      lastSeenAt: row.last_seen_at,
      expiresAt: row.expires_at,
      isCurrent: row.id === ctx.session.id,
    }));

    return ctx.json({ sessions: items });
  });

  router.delete('/api/auth/sessions/:id', requireAuth, (ctx) => {
    const targetId = ctx.params.id;
    const res = dbExecute(
      'DELETE FROM sessions WHERE id = ? AND user_id = ?',
      [targetId, ctx.user.id]
    );

    if (res.changes === 0) {
      return ctx.json({ error: 'Сессия не найдена' }, 404);
    }

    return ctx.json({ ok: true });
  });

  router.post('/api/auth/logout-others', requireAuth, (ctx) => {
    const res = dbExecute(
      'DELETE FROM sessions WHERE user_id = ? AND id != ?',
      [ctx.user.id, ctx.session.id]
    );
    return ctx.json({ ok: true, revokedCount: res.changes });
  });

  router.post('/api/auth/change-password', requireAuth, async (ctx) => {
    const parsed = changePasswordSchema.safeParse(ctx.parseJson());
    if (!parsed.success) {
      const msg = parsed.error.issues[0] ? parsed.error.issues[0].message : 'Проверьте пароли';
      return ctx.json({ error: msg }, 400);
    }

    const { currentPassword, newPassword, revokeOtherSessions } = parsed.data;

    const userRow = dbQueryOne<{ id: string; password_hash: string }>(
      'SELECT id, password_hash FROM users WHERE id = ?',
      [ctx.user.id]
    );
    if (!userRow) {
      return ctx.json({ error: 'Пользователь не найден' }, 404);
    }

    const valid = await verifyPassword(currentPassword, userRow.password_hash);
    if (!valid) {
      return ctx.json({ error: 'Текущий пароль указан неверно' }, 400);
    }

    const newHash = await hashPassword(newPassword);
    dbExecute('UPDATE users SET password_hash = ?, updated_at = ? WHERE id = ?', [
      newHash,
      new Date().toISOString(),
      ctx.user.id,
    ]);

    if (revokeOtherSessions) {
      dbExecute('DELETE FROM sessions WHERE user_id = ? AND id != ?', [
        ctx.user.id,
        ctx.session.id,
      ]);
    }

    return ctx.json({ ok: true });
  });
}
