import type { CurrencyCode } from '@shared/constants';
import { generateUuid } from '@shared/uuid';
import { dbExecute, dbTransaction } from '../db';

/**
 * Создаёт стартовые данные для только что зарегистрированного аккаунта:
 * основной кошелёк, приветственную заметку и первую задачу.
 */
export function seedNewUserWorkspace(userId: string, currency: CurrencyCode): void {
  const now = new Date().toISOString();

  dbTransaction(() => {
    dbExecute(
      `INSERT INTO accounts (id, user_id, name, type, currency, balance, color, created_at, updated_at)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`,
      [generateUuid(), userId, 'Основная карта', 'card', currency, 0, '#6366f1', now, now]
    );

    dbExecute(
      `INSERT INTO tasks (id, user_id, title, description, status, priority, category, due_date, completed_at, created_at, updated_at)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
      [
        generateUuid(),
        userId,
        'Установить приложение на ПК и телефон',
        'Войдите под своей учётной записью на компьютере и смартфоне — все задачи, заметки и финансы синхронизируются автоматически.',
        'todo',
        'high',
        'Старт',
        now.slice(0, 10),
        null,
        now,
        now,
      ]
    );

    dbExecute(
      `INSERT INTO habits (id, user_id, title, description, color, target_days_per_week, created_at, updated_at)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?)`,
      [
        generateUuid(),
        userId,
        'Фокус и развитие 30 минут в день',
        'Отмечайте выполнение каждый день, чтобы копить серию в трекере привычек',
        'cyan',
        7,
        now,
        now,
      ]
    );

    dbExecute(
      `INSERT INTO notes (id, user_id, title, content, tags_json, color, is_pinned, created_at, updated_at)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`,
      [
        generateUuid(),
        userId,
        'Добро пожаловать в SiDaW!',
        [
          'Это ваше личное кроссплатформенное пространство SiDaW.',
          '',
          '• Задачи — планируйте день и отмечайте прогресс с любого устройства.',
          '• Заметки — записывайте идеи, списки и конспекты.',
          '• Финансы — ведите счета, доходы и расходы в удобной валюте.',
          '',
          'Данные вашего аккаунта полностью изолированы от других пользователей.',
        ].join('\n'),
        JSON.stringify(['важное', 'инструкция']),
        'sky',
        1,
        now,
        now,
      ]
    );
  });
}
