import crypto from 'crypto';
import bcrypt from 'bcryptjs';

const BCRYPT_ROUNDS = 10;

/**
 * Безопасное хеширование пароля перед сохранением в БД
 */
export async function hashPassword(password: string): Promise<string> {
  return bcrypt.hash(password, BCRYPT_ROUNDS);
}

/**
 * Проверка введённого пароля при входе и смене пароля
 */
export async function verifyPassword(
  password: string,
  passwordHash: string
): Promise<boolean> {
  return bcrypt.compare(password, passwordHash);
}

/**
 * Генерация криптостойкого сессионного токена (256 бит, совместимо с Node 13.14+ и Node 20+)
 */
export function generateSessionToken(): string {
  return crypto.randomBytes(32).toString('hex');
}

/**
 * В БД мы храним только SHA-256 хеш токена.
 */
export function hashSessionToken(token: string): string {
  return crypto.createHash('sha256').update(token).digest('hex');
}

/**
 * Определяет понятное название устройства (ПК, Windows 7/10/11, Mac или Телефон) по User-Agent
 */
export function parseDeviceLabel(userAgent: string | undefined): string {
  if (!userAgent) return 'Неизвестное устройство';

  const ua = userAgent;

  let platform = 'Устройство';
  if (/iPhone/i.test(ua)) {
    platform = 'Телефон • iPhone';
  } else if (/iPad/i.test(ua)) {
    platform = 'Планшет • iPad';
  } else if (/Android/i.test(ua)) {
    platform = /Mobile/i.test(ua) ? 'Телефон • Android' : 'Планшет • Android';
  } else if (/Windows NT 6\.1/i.test(ua)) {
    platform = 'ПК • Windows 7';
  } else if (/Windows/i.test(ua)) {
    platform = 'ПК • Windows';
  } else if (/Macintosh|Mac OS X/i.test(ua)) {
    platform = 'ПК • macOS';
  } else if (/Linux/i.test(ua)) {
    platform = 'ПК • Linux';
  }

  let browser = '';
  if (/Edg\//i.test(ua)) {
    browser = 'Edge';
  } else if (/OPR\//i.test(ua)) {
    browser = 'Opera';
  } else if (/YaBrowser\//i.test(ua)) {
    browser = 'Яндекс Браузер';
  } else if (/Firefox\//i.test(ua)) {
    browser = 'Firefox';
  } else if (/Chrome\//i.test(ua) || /CriOS\//i.test(ua)) {
    browser = 'Chrome';
  } else if (/Safari\//i.test(ua)) {
    browser = 'Safari';
  }

  return browser ? `${platform} (${browser})` : platform;
}
