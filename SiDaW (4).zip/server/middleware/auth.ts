import { APP_CONFIG, type CurrencyCode } from '@shared/constants';
import {
  DEFAULT_USER_SETTINGS,
  userSettingsSchema,
  type UserSettings,
} from '@shared/schemas';
import { dbExecute, dbQueryOne } from '../db';
import { hashSessionToken } from '../auth/crypto';
import type { MiddlewareFn, RequestContext } from '../lib/http';

export function parseUserSettingsJson(raw: string | undefined | null): UserSettings {
  if (!raw) return { ...DEFAULT_USER_SETTINGS };
  try {
    const parsed = userSettingsSchema.safeParse(JSON.parse(raw));
    return parsed.success ? parsed.data : { ...DEFAULT_USER_SETTINGS };
  } catch {
    return { ...DEFAULT_USER_SETTINGS };
  }
}

/**
 * Собирает все возможные источники токена сессии в порядке приоритета:
 * 1) Заголовок X-SiDaW-Token (не перезаписывается никакими внешними прокси / iframe-шлюзами)
 * 2) Заголовок Authorization: Bearer <token>
 * 3) HttpOnly Cookie (sidaw_session)
 * 4) Query-параметр ?_token=<token> (резервный канал)
 */
export function extractCandidateTokens(ctx: RequestContext): string[] {
  const candidates: string[] = [];

  const customHeader = ctx.header(APP_CONFIG.tokenHeaderName);
  if (customHeader && customHeader.trim().length > 0) {
    candidates.push(customHeader.trim());
  }

  const authHeader = ctx.header('authorization');
  if (authHeader && authHeader.indexOf('Bearer ') === 0) {
    const bearer = authHeader.slice(7).trim();
    if (bearer.length > 0) {
      candidates.push(bearer);
    }
  }

  const cookieToken = ctx.getCookie(APP_CONFIG.sessionCookieName);
  if (cookieToken && cookieToken.trim().length > 0) {
    candidates.push(cookieToken.trim());
  }

  if (ctx.query._token && ctx.query._token.trim().length > 0) {
    candidates.push(ctx.query._token.trim());
  }

  return Array.from(new Set(candidates));
}

interface SessionJoinRow {
  session_id: string;
  device_label: string;
  session_created_at: string;
  last_seen_at: string;
  expires_at: string;
  user_id: string;
  email: string;
  name: string;
  default_currency: CurrencyCode;
  settings_json: string;
  user_created_at: string;
}

export const requireAuth: MiddlewareFn = async (ctx: RequestContext, next) => {
  const candidateTokens = extractCandidateTokens(ctx);

  if (candidateTokens.length === 0) {
    return ctx.json({ error: 'Требуется вход в учётную запись' }, 401);
  }

  const now = new Date();
  let matchedRow: SessionJoinRow | undefined;

  for (const rawToken of candidateTokens) {
    const tokenHash = hashSessionToken(rawToken);
    const row = dbQueryOne<SessionJoinRow>(
      `SELECT
         s.id AS session_id,
         s.device_label,
         s.created_at AS session_created_at,
         s.last_seen_at,
         s.expires_at,
         u.id AS user_id,
         u.email,
         u.name,
         u.default_currency,
         u.settings_json,
         u.created_at AS user_created_at
       FROM sessions s
       INNER JOIN users u ON u.id = s.user_id
       WHERE s.token_hash = ?`,
      [tokenHash]
    );

    if (!row) {
      continue;
    }

    if (new Date(row.expires_at) <= now) {
      dbExecute('DELETE FROM sessions WHERE id = ?', [row.session_id]);
      continue;
    }

    matchedRow = row;
    break;
  }

  if (!matchedRow) {
    return ctx.json({ error: 'Сессия недействительна или завершена, войдите снова' }, 401);
  }

  const nowIso = now.toISOString();
  if (now.getTime() - new Date(matchedRow.last_seen_at).getTime() > 60_000) {
    dbExecute('UPDATE sessions SET last_seen_at = ? WHERE id = ?', [
      nowIso,
      matchedRow.session_id,
    ]);
  }

  ctx.user = {
    id: matchedRow.user_id,
    email: matchedRow.email,
    name: matchedRow.name,
    defaultCurrency: matchedRow.default_currency,
    settings: parseUserSettingsJson(matchedRow.settings_json),
    createdAt: matchedRow.user_created_at,
  };

  ctx.session = {
    id: matchedRow.session_id,
    deviceLabel: matchedRow.device_label,
    createdAt: matchedRow.session_created_at,
    lastSeenAt: nowIso,
    expiresAt: matchedRow.expires_at,
  };

  return next();
};
