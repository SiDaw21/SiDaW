import fs from 'fs';
import path from 'path';
import { APP_CONFIG } from '@shared/constants';
import { initDatabase } from './db';
import { ApiRouter } from './lib/http';
import { registerAuthRoutes } from './routes/auth';
import { registerTasksRoutes } from './routes/tasks';
import { registerHabitsRoutes } from './routes/habits';
import { registerNotesRoutes } from './routes/notes';
import { registerFinanceRoutes } from './routes/finance';
import { registerDashboardRoutes } from './routes/dashboard';
import { registerBackupRoutes } from './routes/backup';

const MIME_TYPES: Record<string, string> = {
  '.html': 'text/html; charset=utf-8',
  '.js': 'application/javascript; charset=utf-8',
  '.mjs': 'application/javascript; charset=utf-8',
  '.css': 'text/css; charset=utf-8',
  '.json': 'application/json; charset=utf-8',
  '.webmanifest': 'application/manifest+json; charset=utf-8',
  '.png': 'image/png',
  '.jpg': 'image/jpeg',
  '.jpeg': 'image/jpeg',
  '.svg': 'image/svg+xml',
  '.ico': 'image/x-icon',
  '.woff2': 'font/woff2',
};

export async function createApp(): Promise<ApiRouter> {
  await initDatabase();

  const app = new ApiRouter();

  app.get('/api/health', (ctx) => {
    return ctx.json({
      status: 'ok',
      app: APP_CONFIG.name,
      timestamp: new Date().toISOString(),
    });
  });

  registerAuthRoutes(app);
  registerDashboardRoutes(app);
  registerTasksRoutes(app);
  registerHabitsRoutes(app);
  registerNotesRoutes(app);
  registerFinanceRoutes(app);
  registerBackupRoutes(app);

  // Раздача собранного фронтенда и PWA-файлов из dist/client
  const clientBuildDir = path.resolve(process.cwd(), 'dist/client');

  app.setFallback((ctx) => {
    if (ctx.pathname.startsWith('/api/')) {
      return ctx.json({ error: 'API-маршрут не найден' }, 404);
    }

    if (fs.existsSync(clientBuildDir)) {
      const safeRel = path
        .normalize(decodeURIComponent(ctx.pathname))
        .replace(/^(\.\.(\/|\\|$))+/, '')
        .replace(/^[/\\]+/, '');

      const candidate = path.join(clientBuildDir, safeRel);
      if (
        safeRel &&
        candidate.startsWith(clientBuildDir) &&
        fs.existsSync(candidate) &&
        fs.statSync(candidate).isFile()
      ) {
        const ext = path.extname(candidate).toLowerCase();
        const mime = MIME_TYPES[ext] || 'application/octet-stream';
        return ctx.sendRaw(fs.readFileSync(candidate), mime, 200);
      }

      const indexHtmlPath = path.join(clientBuildDir, 'index.html');
      if (fs.existsSync(indexHtmlPath)) {
        return ctx.sendRaw(
          fs.readFileSync(indexHtmlPath),
          'text/html; charset=utf-8',
          200
        );
      }
    }

    return ctx.json(
      { error: 'Фронтенд не собран. Запустите npm run dev или npm run build.' },
      404
    );
  });

  return app;
}
