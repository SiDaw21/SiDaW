import http from 'http';
import { APP_CONFIG } from '@shared/constants';
import { createApp } from './app';

const args = process.argv.slice(2);
const isDevFlag = args.includes('--dev');
const isProdFlag = args.includes('--prod');

if (isProdFlag && !process.env.NODE_ENV) {
  process.env.NODE_ENV = 'production';
}

const port = Number(process.env.PORT) || 3001;
const hostname = process.env.HOST || (isDevFlag ? '127.0.0.1' : '0.0.0.0');

async function start() {
  const app = await createApp();
  const server = http.createServer(app.createNodeHandler());

  server.listen(port, hostname, () => {
    console.log(`🚀 [${APP_CONFIG.name}] Сервер запущен: http://${hostname}:${port}`);
    console.log(`📦 База данных SQLite (./data/sidaw.db) готова к работе`);
  });
}

start().catch((err) => {
  console.error('Ошибка запуска сервера SiDaW:', err);
  process.exit(1);
});
