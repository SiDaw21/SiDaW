/**
 * Типы таблиц базы данных SQLite (./data/sidaw.db) проекта SiDaW.
 * Сами SQL-таблицы автоматически создаются при старте в server/db/index.ts.
 */
import type {
  AccountType,
  CurrencyCode,
  NoteColor,
  TaskPriority,
  TaskStatus,
  TransactionType,
} from '@shared/constants';

export interface UserTableRow {
  id: string;
  email: string;
  name: string;
  password_hash: string;
  default_currency: CurrencyCode;
  settings_json: string;
  created_at: string;
  updated_at: string;
}

export interface SessionTableRow {
  id: string;
  user_id: string;
  token_hash: string;
  device_label: string;
  user_agent: string;
  created_at: string;
  last_seen_at: string;
  expires_at: string;
}

export interface TaskTableRow {
  id: string;
  user_id: string;
  title: string;
  description: string;
  status: TaskStatus;
  priority: TaskPriority;
  category: string;
  due_date: string | null;
  completed_at: string | null;
  created_at: string;
  updated_at: string;
}

export interface NoteTableRow {
  id: string;
  user_id: string;
  title: string;
  content: string;
  tags_json: string;
  color: NoteColor;
  is_pinned: number;
  created_at: string;
  updated_at: string;
}

export interface AccountTableRow {
  id: string;
  user_id: string;
  name: string;
  type: AccountType;
  currency: CurrencyCode;
  balance: number;
  color: string;
  created_at: string;
  updated_at: string;
}

export interface TransactionTableRow {
  id: string;
  user_id: string;
  account_id: string;
  type: TransactionType;
  amount: number;
  category: string;
  description: string;
  date: string;
  created_at: string;
  updated_at: string;
}
