import fs from 'fs';
import path from 'path';
import initSqlJs, { type Database as SqlJsDatabase, type SqlValue } from 'sql.js';

let sqlDb: SqlJsDatabase | null = null;
let activeDbPath = '';
let txDepth = 0;

function resolveDbPath(): string {
  return path.resolve(process.cwd(), process.env.DATABASE_PATH || './data/sidaw.db');
}

function resolveWasmPath(): string {
  const candidates = [
    path.resolve(process.cwd(), 'win7/sql-wasm.wasm'),
    path.resolve(process.cwd(), 'node_modules/sql.js/dist/sql-wasm.wasm'),
  ];
  for (const file of candidates) {
    if (fs.existsSync(file)) return file;
  }
  return candidates[1];
}

/**
 * Атомарно сохраняет состояние SQLite на диск в файл ./data/sidaw.db
 */
export function persistDatabaseToDisk(): void {
  if (!sqlDb || !activeDbPath) return;
  const dir = path.dirname(activeDbPath);
  if (!fs.existsSync(dir)) {
    fs.mkdirSync(dir, { recursive: true });
  }
  const binary = Buffer.from(sqlDb.export());
  const tmpPath = `${activeDbPath}.tmp`;
  fs.writeFileSync(tmpPath, binary);
  fs.renameSync(tmpPath, activeDbPath);
}

/**
 * Инициализирует SQLite (sql.js WebAssembly) — работает на Windows 7 (Node 13.14+),
 * Windows 10/11, macOS, Linux и в Docker без C++ компиляторов.
 */
export async function initDatabase(): Promise<void> {
  const targetPath = resolveDbPath();
  if (sqlDb && activeDbPath === targetPath) {
    return;
  }

  activeDbPath = targetPath;
  const dir = path.dirname(activeDbPath);
  if (!fs.existsSync(dir)) {
    fs.mkdirSync(dir, { recursive: true });
  }

  const wasmBinary = fs.readFileSync(resolveWasmPath());
  const SQL = await initSqlJs({ wasmBinary: wasmBinary as any });

  if (fs.existsSync(activeDbPath)) {
    const fileBuffer = fs.readFileSync(activeDbPath);
    sqlDb = new SQL.Database(new Uint8Array(fileBuffer));
  } else {
    sqlDb = new SQL.Database();
  }

  sqlDb.run('PRAGMA foreign_keys = ON;');

  sqlDb.run(`
    CREATE TABLE IF NOT EXISTS users (
      id TEXT PRIMARY KEY NOT NULL,
      email TEXT NOT NULL UNIQUE,
      name TEXT NOT NULL,
      password_hash TEXT NOT NULL,
      default_currency TEXT NOT NULL DEFAULT 'EUR',
      settings_json TEXT NOT NULL DEFAULT '{}',
      created_at TEXT NOT NULL,
      updated_at TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS sessions (
      id TEXT PRIMARY KEY NOT NULL,
      user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
      token_hash TEXT NOT NULL UNIQUE,
      device_label TEXT NOT NULL,
      user_agent TEXT NOT NULL DEFAULT '',
      created_at TEXT NOT NULL,
      last_seen_at TEXT NOT NULL,
      expires_at TEXT NOT NULL
    );
    CREATE INDEX IF NOT EXISTS idx_sessions_user_id ON sessions(user_id);

    CREATE TABLE IF NOT EXISTS tasks (
      id TEXT PRIMARY KEY NOT NULL,
      user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
      title TEXT NOT NULL,
      description TEXT NOT NULL DEFAULT '',
      status TEXT NOT NULL DEFAULT 'todo',
      priority TEXT NOT NULL DEFAULT 'medium',
      category TEXT NOT NULL DEFAULT 'Личное',
      due_date TEXT,
      completed_at TEXT,
      created_at TEXT NOT NULL,
      updated_at TEXT NOT NULL
    );
    CREATE INDEX IF NOT EXISTS idx_tasks_user_id ON tasks(user_id);
    CREATE INDEX IF NOT EXISTS idx_tasks_status ON tasks(user_id, status);

    CREATE TABLE IF NOT EXISTS habits (
      id TEXT PRIMARY KEY NOT NULL,
      user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
      title TEXT NOT NULL,
      description TEXT NOT NULL DEFAULT '',
      color TEXT NOT NULL DEFAULT 'cyan',
      target_days_per_week INTEGER NOT NULL DEFAULT 7,
      created_at TEXT NOT NULL,
      updated_at TEXT NOT NULL
    );
    CREATE INDEX IF NOT EXISTS idx_habits_user_id ON habits(user_id);

    CREATE TABLE IF NOT EXISTS habit_logs (
      id TEXT PRIMARY KEY NOT NULL,
      habit_id TEXT NOT NULL REFERENCES habits(id) ON DELETE CASCADE,
      user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
      date TEXT NOT NULL,
      created_at TEXT NOT NULL,
      UNIQUE(habit_id, date)
    );
    CREATE INDEX IF NOT EXISTS idx_habit_logs_user_id ON habit_logs(user_id);
    CREATE INDEX IF NOT EXISTS idx_habit_logs_habit_id ON habit_logs(habit_id);

    CREATE TABLE IF NOT EXISTS notes (
      id TEXT PRIMARY KEY NOT NULL,
      user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
      title TEXT NOT NULL,
      content TEXT NOT NULL DEFAULT '',
      tags_json TEXT NOT NULL DEFAULT '[]',
      color TEXT NOT NULL DEFAULT 'default',
      is_pinned INTEGER NOT NULL DEFAULT 0,
      created_at TEXT NOT NULL,
      updated_at TEXT NOT NULL
    );
    CREATE INDEX IF NOT EXISTS idx_notes_user_id ON notes(user_id);

    CREATE TABLE IF NOT EXISTS accounts (
      id TEXT PRIMARY KEY NOT NULL,
      user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
      name TEXT NOT NULL,
      type TEXT NOT NULL DEFAULT 'card',
      currency TEXT NOT NULL DEFAULT 'EUR',
      balance REAL NOT NULL DEFAULT 0,
      color TEXT NOT NULL DEFAULT '#6366f1',
      created_at TEXT NOT NULL,
      updated_at TEXT NOT NULL
    );
    CREATE INDEX IF NOT EXISTS idx_accounts_user_id ON accounts(user_id);

    CREATE TABLE IF NOT EXISTS transactions (
      id TEXT PRIMARY KEY NOT NULL,
      user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
      account_id TEXT NOT NULL REFERENCES accounts(id) ON DELETE CASCADE,
      type TEXT NOT NULL,
      amount REAL NOT NULL,
      category TEXT NOT NULL,
      description TEXT NOT NULL DEFAULT '',
      date TEXT NOT NULL,
      created_at TEXT NOT NULL,
      updated_at TEXT NOT NULL
    );
    CREATE INDEX IF NOT EXISTS idx_transactions_user_id ON transactions(user_id);
    CREATE INDEX IF NOT EXISTS idx_transactions_account_id ON transactions(account_id);
    CREATE INDEX IF NOT EXISTS idx_transactions_date ON transactions(user_id, date);
  `);

  // Безопасная автомиграция существующей БД (добавляем settings_json, если таблица создавалась ранее)
  const colsStmt = sqlDb.prepare('PRAGMA table_info(users);');
  let hasSettingsCol = false;
  while (colsStmt.step()) {
    const col = colsStmt.getAsObject() as { name?: string };
    if (col.name === 'settings_json') {
      hasSettingsCol = true;
    }
  }
  colsStmt.free();

  if (!hasSettingsCol) {
    sqlDb.run("ALTER TABLE users ADD COLUMN settings_json TEXT NOT NULL DEFAULT '{}';");
  }

  persistDatabaseToDisk();
}

function getDb(): SqlJsDatabase {
  if (!sqlDb) {
    throw new Error('База данных SQLite ещё не инициализирована. Вызовите await initDatabase()');
  }
  return sqlDb;
}

/**
 * Выполняет SELECT и возвращает массив строк
 */
export function dbQueryAll<T = Record<string, any>>(
  sql: string,
  params: SqlValue[] = []
): T[] {
  const db = getDb();
  const stmt = db.prepare(sql);
  try {
    stmt.bind(params);
    const rows: T[] = [];
    while (stmt.step()) {
      rows.push(stmt.getAsObject() as T);
    }
    return rows;
  } finally {
    stmt.free();
  }
}

/**
 * Выполняет SELECT и возвращает первую строку или undefined
 */
export function dbQueryOne<T = Record<string, any>>(
  sql: string,
  params: SqlValue[] = []
): T | undefined {
  const db = getDb();
  const stmt = db.prepare(sql);
  try {
    stmt.bind(params);
    if (stmt.step()) {
      return stmt.getAsObject() as T;
    }
    return undefined;
  } finally {
    stmt.free();
  }
}

/**
 * Выполняет INSERT / UPDATE / DELETE и сохраняет изменения в ./data/sidaw.db
 */
export function dbExecute(
  sql: string,
  params: SqlValue[] = [],
  options: { skipDiskFlush?: boolean } = {}
): { changes: number } {
  const db = getDb();
  db.run(sql, params);
  const changes = db.getRowsModified();
  if (txDepth === 0 && !options.skipDiskFlush) {
    persistDatabaseToDisk();
  }
  return { changes };
}

/**
 * Выполняет набор SQL-операций в единой атомарной транзакции SQLite
 */
export function dbTransaction<T>(fn: () => T): T {
  const db = getDb();
  const isOuter = txDepth === 0;
  txDepth++;
  if (isOuter) {
    db.run('BEGIN TRANSACTION;');
  }
  try {
    const result = fn();
    txDepth--;
    if (isOuter) {
      db.run('COMMIT;');
      persistDatabaseToDisk();
    }
    return result;
  } catch (err) {
    txDepth--;
    if (isOuter) {
      try {
        db.run('ROLLBACK;');
      } catch {
        // ignore rollback error
      }
    }
    throw err;
  }
}

export function closeDatabase(): void {
  if (sqlDb) {
    persistDatabaseToDisk();
    sqlDb.close();
    sqlDb = null;
  }
}
