import http from 'http';
import type { SessionDTO, UserDTO } from '@shared/schemas';

export interface CookieOptions {
  httpOnly?: boolean;
  secure?: boolean;
  sameSite?: 'Lax' | 'Strict' | 'None';
  partitioned?: boolean;
  path?: string;
  maxAge?: number;
}

export interface ApiResponsePayload {
  status: number;
  headers: Record<string, string | string[]>;
  body: string | Buffer;
}

export class RequestContext {
  readonly method: string;
  readonly pathname: string;
  readonly query: Record<string, string>;
  readonly headers: Record<string, string | undefined>;
  params: Record<string, string> = {};
  user!: UserDTO;
  session!: Omit<SessionDTO, 'isCurrent'>;

  private rawBody: string;
  private outCookies: string[] = [];

  constructor(opts: {
    method: string;
    url: string;
    headers: Record<string, string | undefined>;
    rawBody: string;
  }) {
    this.method = opts.method.toUpperCase();
    const qIdx = opts.url.indexOf('?');
    this.pathname = qIdx === -1 ? opts.url : opts.url.slice(0, qIdx);
    this.query = {};
    if (qIdx !== -1) {
      const search = opts.url.slice(qIdx + 1);
      for (const part of search.split('&')) {
        if (!part) continue;
        const eqIdx = part.indexOf('=');
        const k = eqIdx === -1 ? part : part.slice(0, eqIdx);
        const v = eqIdx === -1 ? '' : part.slice(eqIdx + 1);
        this.query[decodeURIComponent(k)] = decodeURIComponent(v);
      }
    }
    this.headers = {};
    for (const key of Object.keys(opts.headers)) {
      this.headers[key.toLowerCase()] = opts.headers[key];
    }
    this.rawBody = opts.rawBody;
  }

  header(name: string): string | undefined {
    return this.headers[name.toLowerCase()];
  }

  parseJson<T = any>(): T {
    if (!this.rawBody) return {} as T;
    return JSON.parse(this.rawBody) as T;
  }

  getCookie(name: string): string | undefined {
    const raw = this.header('cookie');
    if (!raw) return undefined;
    const parts = raw.split(';');
    for (const part of parts) {
      const trimmed = part.trim();
      const eq = trimmed.indexOf('=');
      if (eq === -1) continue;
      const k = trimmed.slice(0, eq).trim();
      if (k === name) {
        return decodeURIComponent(trimmed.slice(eq + 1).trim());
      }
    }
    return undefined;
  }

  setCookie(name: string, value: string, opts: CookieOptions = {}): void {
    const segs = [`${name}=${encodeURIComponent(value)}`];
    segs.push(`Path=${opts.path || '/'}`);
    if (typeof opts.maxAge === 'number') {
      segs.push(`Max-Age=${Math.floor(opts.maxAge)}`);
    }
    if (opts.httpOnly !== false) {
      segs.push('HttpOnly');
    }
    if (opts.sameSite) {
      segs.push(`SameSite=${opts.sameSite}`);
    }
    if (opts.secure) {
      segs.push('Secure');
    }
    if (opts.partitioned && opts.secure) {
      segs.push('Partitioned');
    }
    this.outCookies.push(segs.join('; '));
  }

  deleteCookie(name: string, pathStr = '/'): void {
    this.outCookies.push(`${name}=; Path=${pathStr}; Max-Age=0; HttpOnly`);
  }

  json(data: unknown, status = 200): ApiResponsePayload {
    const headers: Record<string, string | string[]> = {
      'Content-Type': 'application/json; charset=utf-8',
    };
    if (this.outCookies.length > 0) {
      headers['Set-Cookie'] = this.outCookies.slice();
    }
    return {
      status,
      headers,
      body: JSON.stringify(data),
    };
  }

  sendRaw(
    body: string | Buffer,
    contentType: string,
    status = 200,
    extraHeaders: Record<string, string> = {}
  ): ApiResponsePayload {
    const headers: Record<string, string | string[]> = {
      'Content-Type': contentType,
      ...extraHeaders,
    };
    if (this.outCookies.length > 0) {
      headers['Set-Cookie'] = this.outCookies.slice();
    }
    return { status, headers, body };
  }
}

export type RouteHandler = (
  ctx: RequestContext
) => Promise<ApiResponsePayload> | ApiResponsePayload;

export type MiddlewareFn = (
  ctx: RequestContext,
  next: () => Promise<ApiResponsePayload>
) => Promise<ApiResponsePayload>;

interface CompiledRoute {
  method: string;
  regex: RegExp;
  paramNames: string[];
  middlewares: MiddlewareFn[];
  handler: RouteHandler;
}

function compilePattern(pattern: string): { regex: RegExp; paramNames: string[] } {
  const paramNames: string[] = [];
  const escaped = pattern
    .replace(/\/+$/, '')
    .replace(/:([A-Za-z0-9_]+)/g, (_, paramName) => {
      paramNames.push(paramName);
      return '([^/]+)';
    });
  const finalRegex = new RegExp(`^${escaped || '/'}/?$`);
  return { regex: finalRegex, paramNames };
}

/**
 * Лёгкий кроссплатформенный HTTP-роутер без внешних зависимостей от Node 18+.
 * Стабильно работает на Node.js 13.14.0 (Windows 7) и на Node.js 18/20/22.
 */
export class ApiRouter {
  private routes: CompiledRoute[] = [];
  private fallbackHandler: RouteHandler | null = null;

  add(
    method: string,
    pathPattern: string,
    middlewares: MiddlewareFn[],
    handler: RouteHandler
  ): void {
    const { regex, paramNames } = compilePattern(pathPattern);
    this.routes.push({
      method: method.toUpperCase(),
      regex,
      paramNames,
      middlewares,
      handler,
    });
  }

  get(pathPattern: string, ...args: [...MiddlewareFn[], RouteHandler]): void {
    const handler = args[args.length - 1] as RouteHandler;
    const mws = args.slice(0, -1) as MiddlewareFn[];
    this.add('GET', pathPattern, mws, handler);
  }

  post(pathPattern: string, ...args: [...MiddlewareFn[], RouteHandler]): void {
    const handler = args[args.length - 1] as RouteHandler;
    const mws = args.slice(0, -1) as MiddlewareFn[];
    this.add('POST', pathPattern, mws, handler);
  }

  patch(pathPattern: string, ...args: [...MiddlewareFn[], RouteHandler]): void {
    const handler = args[args.length - 1] as RouteHandler;
    const mws = args.slice(0, -1) as MiddlewareFn[];
    this.add('PATCH', pathPattern, mws, handler);
  }

  delete(pathPattern: string, ...args: [...MiddlewareFn[], RouteHandler]): void {
    const handler = args[args.length - 1] as RouteHandler;
    const mws = args.slice(0, -1) as MiddlewareFn[];
    this.add('DELETE', pathPattern, mws, handler);
  }

  setFallback(handler: RouteHandler): void {
    this.fallbackHandler = handler;
  }

  async dispatch(ctx: RequestContext): Promise<ApiResponsePayload> {
    const origin = ctx.header('origin') || '*';
    const corsHeaders: Record<string, string> = {
      'Access-Control-Allow-Origin': origin,
      'Access-Control-Allow-Credentials': 'true',
      'Access-Control-Allow-Headers': 'Content-Type, Authorization, X-SiDaW-Token',
      'Access-Control-Allow-Methods': 'GET, POST, PUT, PATCH, DELETE, OPTIONS',
    };

    if (ctx.method === 'OPTIONS') {
      return {
        status: 204,
        headers: corsHeaders,
        body: '',
      };
    }

    try {
      for (const route of this.routes) {
        if (route.method !== ctx.method) continue;
        const match = route.regex.exec(ctx.pathname);
        if (!match) continue;

        const params: Record<string, string> = {};
        for (let i = 0; i < route.paramNames.length; i++) {
          params[route.paramNames[i]] = decodeURIComponent(match[i + 1]);
        }
        ctx.params = params;

        let idx = -1;
        const runChain = async (i: number): Promise<ApiResponsePayload> => {
          if (i <= idx) throw new Error('next() вызван повторно');
          idx = i;
          if (i < route.middlewares.length) {
            return route.middlewares[i](ctx, () => runChain(i + 1));
          }
          return route.handler(ctx);
        };

        const res = await runChain(0);
        if (ctx.pathname.startsWith('/api/')) {
          Object.assign(res.headers, corsHeaders);
        }
        return res;
      }

      if (this.fallbackHandler) {
        return await this.fallbackHandler(ctx);
      }

      return {
        status: 404,
        headers: { 'Content-Type': 'application/json; charset=utf-8', ...corsHeaders },
        body: JSON.stringify({ error: 'Маршрут не найден' }),
      };
    } catch (err: any) {
      if (err instanceof SyntaxError) {
        return {
          status: 400,
          headers: { 'Content-Type': 'application/json; charset=utf-8', ...corsHeaders },
          body: JSON.stringify({ error: 'Некорректный формат JSON' }),
        };
      }
      console.error('[SiDaW Error]:', err);
      return {
        status: 500,
        headers: { 'Content-Type': 'application/json; charset=utf-8', ...corsHeaders },
        body: JSON.stringify({ error: 'Внутренняя ошибка сервера' }),
      };
    }
  }

  /**
   * Удобный метод для автотестов (совместим с Node 13.14.0 и Node 20)
   */
  async request(
    url: string,
    init: { method?: string; headers?: Record<string, string>; body?: string } = {}
  ): Promise<{ status: number; json: () => Promise<any>; text: () => Promise<string> }> {
    const ctx = new RequestContext({
      method: init.method || 'GET',
      url,
      headers: init.headers || {},
      rawBody: init.body || '',
    });
    const res = await this.dispatch(ctx);
    const str = Buffer.isBuffer(res.body) ? res.body.toString('utf-8') : res.body;
    return {
      status: res.status,
      json: async () => JSON.parse(str),
      text: async () => str,
    };
  }

  createNodeHandler(): http.RequestListener {
    return (req, res) => {
      const chunks: Buffer[] = [];
      let totalBytes = 0;

      req.on('data', (chunk: Buffer) => {
        totalBytes += chunk.length;
        if (totalBytes > 5 * 1024 * 1024) {
          req.destroy();
          return;
        }
        chunks.push(chunk);
      });

      req.on('end', async () => {
        const rawBody = Buffer.concat(chunks).toString('utf-8');
        const flatHeaders: Record<string, string | undefined> = {};
        for (const k of Object.keys(req.headers)) {
          const val = req.headers[k];
          flatHeaders[k] = Array.isArray(val) ? val.join('; ') : val;
        }

        const ctx = new RequestContext({
          method: req.method || 'GET',
          url: req.url || '/',
          headers: flatHeaders,
          rawBody,
        });

        const startMs = Date.now();
        const payload = await this.dispatch(ctx);

        if (process.env.NODE_ENV !== 'test' && ctx.pathname.startsWith('/api/')) {
          const ms = Date.now() - startMs;
          console.log(`[API] ${ctx.method} ${ctx.pathname} -> ${payload.status} (${ms}ms)`);
        }

        res.writeHead(payload.status, payload.headers);
        res.end(payload.body);
      });
    };
  }
}
