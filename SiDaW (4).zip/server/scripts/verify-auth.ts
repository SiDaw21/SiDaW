/**
 * Автопроверка БД SQLite + Регистрация + Вход с ПК и Телефона + Изоляция аккаунтов.
 * Запуск: npm run test:auth
 */
import assert from 'assert';
import fs from 'fs';

const TEST_DB_PATH = './data/test-auth-verify.db';
process.env.DATABASE_PATH = TEST_DB_PATH;
process.env.NODE_ENV = 'test';

if (fs.existsSync(TEST_DB_PATH)) {
  fs.unlinkSync(TEST_DB_PATH);
}

async function runVerification() {
  const { createApp } = await import('../app');
  const { closeDatabase, dbQueryAll } = await import('../db');

  const app = await createApp();

  console.log('1️⃣  Проверяем /api/health...');
  const healthRes = await app.request('/api/health');
  assert.strictEqual(healthRes.status, 200);
  const healthJson = await healthRes.json();
  assert.strictEqual(healthJson.status, 'ok');

  console.log('2️⃣  Регистрируем пользователя №1 с ПК (Windows 10 Chrome)...');
  const pcUa =
    'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/131.0.0.0 Safari/537.36';
  const regRes = await app.request('/api/auth/register', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'User-Agent': pcUa,
    },
    body: JSON.stringify({
      name: 'Алексей',
      email: 'alex@example.com',
      password: 'Password123!',
      defaultCurrency: 'EUR',
    }),
  });
  assert.strictEqual(regRes.status, 201);
  const regData = await regRes.json();
  assert.strictEqual(regData.user.email, 'alex@example.com');
  assert.strictEqual(regData.session.deviceLabel, 'ПК • Windows (Chrome)');
  const pcToken = regData.token as string;
  assert.ok(pcToken.length > 20);

  const userAccounts = dbQueryAll('SELECT * FROM accounts WHERE user_id = ?', [
    regData.user.id,
  ]);
  const userTasks = dbQueryAll('SELECT * FROM tasks WHERE user_id = ?', [
    regData.user.id,
  ]);
  const userNotes = dbQueryAll('SELECT * FROM notes WHERE user_id = ?', [
    regData.user.id,
  ]);
  assert.strictEqual(userAccounts.length, 1);
  assert.strictEqual(userTasks.length, 1);
  assert.strictEqual(userNotes.length, 1);

  console.log('3️⃣  Входим в тот же аккаунт с телефона (iPhone Safari)...');
  const phoneUa =
    'Mozilla/5.0 (iPhone; CPU iPhone OS 18_1 like Mac OS X) AppleWebKit/605.1.15 Version/18.1 Mobile/15E148 Safari/604.1';
  const phoneLoginRes = await app.request('/api/auth/login', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'User-Agent': phoneUa,
    },
    body: JSON.stringify({
      email: 'alex@example.com',
      password: 'Password123!',
    }),
  });
  assert.strictEqual(phoneLoginRes.status, 200);
  const phoneLoginData = await phoneLoginRes.json();
  assert.strictEqual(phoneLoginData.session.deviceLabel, 'Телефон • iPhone (Safari)');
  const phoneToken = phoneLoginData.token as string;

  console.log('4️⃣  Проверяем список активных устройств (ПК + Телефон)...');
  const sessionsRes = await app.request('/api/auth/sessions', {
    headers: { Authorization: `Bearer ${phoneToken}` },
  });
  assert.strictEqual(sessionsRes.status, 200);
  const sessionsData = await sessionsRes.json();
  assert.strictEqual(sessionsData.sessions.length, 2);

  console.log('5️⃣  Регистрируем пользователя №2 и проверяем изоляцию аккаунтов...');
  const user2Res = await app.request('/api/auth/register', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      name: 'Мария',
      email: 'maria@example.com',
      password: 'SecretPassword99',
      defaultCurrency: 'RUB',
    }),
  });
  assert.strictEqual(user2Res.status, 201);
  const user2Data = await user2Res.json();

  const hackDeleteRes = await app.request(`/api/auth/sessions/${regData.session.id}`, {
    method: 'DELETE',
    headers: { Authorization: `Bearer ${user2Data.token}` },
  });
  assert.strictEqual(hackDeleteRes.status, 404);

  console.log('6️⃣  Проверяем смену пароля с завершением других сессий...');
  const changePassRes = await app.request('/api/auth/change-password', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      Authorization: `Bearer ${phoneToken}`,
    },
    body: JSON.stringify({
      currentPassword: 'Password123!',
      newPassword: 'NewStrongPassword456!',
      revokeOtherSessions: true,
    }),
  });
  assert.strictEqual(changePassRes.status, 200);

  const oldPcMe = await app.request('/api/auth/me', {
    headers: { Authorization: `Bearer ${pcToken}` },
  });
  assert.strictEqual(oldPcMe.status, 401);

  const phoneMe = await app.request('/api/auth/me', {
    headers: { Authorization: `Bearer ${phoneToken}` },
  });
  assert.strictEqual(phoneMe.status, 200);

  console.log('7️⃣  Проверяем синхронизацию Настроек аккаунта (Тема, Задний фон, Liquid Glass)...');
  const patchSettingsRes = await app.request('/api/auth/settings', {
    method: 'PATCH',
    headers: {
      'Content-Type': 'application/json',
      Authorization: `Bearer ${phoneToken}`,
    },
    body: JSON.stringify({
      themeMode: 'light',
      backgroundTheme: 'ocean',
      glassIntensity: 'frosted',
      hideBalances: true,
    }),
  });
  assert.strictEqual(patchSettingsRes.status, 200);
  const patchedSettingsData = await patchSettingsRes.json();
  assert.strictEqual(patchedSettingsData.settings.themeMode, 'light');
  assert.strictEqual(patchedSettingsData.settings.backgroundTheme, 'ocean');
  assert.strictEqual(patchedSettingsData.settings.glassIntensity, 'frosted');
  assert.strictEqual(patchedSettingsData.settings.hideBalances, true);

  const phoneMeAfterSettings = await app.request('/api/auth/me', {
    headers: { Authorization: `Bearer ${phoneToken}` },
  });
  const meAfterJson = await phoneMeAfterSettings.json();
  assert.strictEqual(meAfterJson.user.settings.themeMode, 'light');
  assert.strictEqual(meAfterJson.user.settings.backgroundTheme, 'ocean');

  console.log('8️⃣  Проверяем защиту сессии через X-SiDaW-Token при перезаписи Authorization внешним прокси...');
  const proxyProtectedMe = await app.request('/api/auth/me', {
    headers: {
      Authorization: 'Bearer external-arena-proxy-jwt-that-does-not-belong-to-sidaw',
      'x-sidaw-token': phoneToken,
    },
  });
  assert.strictEqual(proxyProtectedMe.status, 200);

  closeDatabase();
  if (fs.existsSync(TEST_DB_PATH)) {
    fs.unlinkSync(TEST_DB_PATH);
  }

  console.log('\n✅ Все проверки авторизации и устройств пройдены успешно!');
}

runVerification().catch((err) => {
  console.error('❌ Ошибка проверки:', err);
  process.exit(1);
});
