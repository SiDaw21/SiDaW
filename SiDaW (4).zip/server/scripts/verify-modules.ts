/**
 * Полная автопроверка Задач, Заметок, Финансов (атомарный баланс), Дашборда и изоляции аккаунтов.
 * Запуск: npm run test:modules
 */
import assert from 'assert';
import fs from 'fs';

const TEST_DB_PATH = './data/test-modules-verify.db';
process.env.DATABASE_PATH = TEST_DB_PATH;
process.env.NODE_ENV = 'test';

if (fs.existsSync(TEST_DB_PATH)) {
  fs.unlinkSync(TEST_DB_PATH);
}

async function run() {
  const { createApp } = await import('../app');
  const { closeDatabase } = await import('../db');

  const app = await createApp();

  const regA = await app.request('/api/auth/register', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      name: 'Иван',
      email: 'ivan@sidaw.local',
      password: 'Password123',
      defaultCurrency: 'EUR',
    }),
  });
  assert.strictEqual(regA.status, 201);
  const { token: tokenA } = await regA.json();

  const regB = await app.request('/api/auth/register', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      name: 'Ольга',
      email: 'olga@sidaw.local',
      password: 'Password123',
      defaultCurrency: 'RUB',
    }),
  });
  assert.strictEqual(regB.status, 201);
  const { token: tokenB } = await regB.json();

  const headersA = {
    'Content-Type': 'application/json',
    Authorization: `Bearer ${tokenA}`,
  };
  const headersB = {
    'Content-Type': 'application/json',
    Authorization: `Bearer ${tokenB}`,
  };

  console.log('1️⃣  Проверяем CRUD задач...');
  const createTaskRes = await app.request('/api/tasks', {
    method: 'POST',
    headers: headersA,
    body: JSON.stringify({
      title: 'Подготовить отчёт SiDaW',
      priority: 'high',
      category: 'Работа',
    }),
  });
  assert.strictEqual(createTaskRes.status, 201);
  const { task } = await createTaskRes.json();

  const forbiddenPatch = await app.request(`/api/tasks/${task.id}`, {
    method: 'PATCH',
    headers: headersB,
    body: JSON.stringify({ status: 'done' }),
  });
  assert.strictEqual(forbiddenPatch.status, 404);

  const patchTaskRes = await app.request(`/api/tasks/${task.id}`, {
    method: 'PATCH',
    headers: headersA,
    body: JSON.stringify({ status: 'done' }),
  });
  assert.strictEqual(patchTaskRes.status, 200);
  const patchedTask = (await patchTaskRes.json()).task;
  assert.strictEqual(patchedTask.status, 'done');
  assert.ok(patchedTask.completedAt);

  console.log('2️⃣  Проверяем CRUD заметок и тегов...');
  const createNoteRes = await app.request('/api/notes', {
    method: 'POST',
    headers: headersA,
    body: JSON.stringify({
      title: 'Идеи для проекта',
      content: 'Синхронизация ПК и смартфона',
      tags: ['проект', 'идеи'],
      color: 'emerald',
      isPinned: true,
    }),
  });
  assert.strictEqual(createNoteRes.status, 201);
  const { note } = await createNoteRes.json();
  assert.deepStrictEqual(note.tags, ['проект', 'идеи']);

  console.log('2.5️⃣ Проверяем вкладку Привычки (CRUD, отметки дней и серии)...');
  const createHabitRes = await app.request('/api/habits', {
    method: 'POST',
    headers: headersA,
    body: JSON.stringify({
      title: 'Чтение 30 минут',
      description: 'Каждый вечер перед сном',
      color: 'cyan',
      targetDaysPerWeek: 7,
    }),
  });
  assert.strictEqual(createHabitRes.status, 201);
  const { habit: createdHabit } = await createHabitRes.json();

  const todayIso = new Date().toISOString().slice(0, 10);
  const toggleTodayRes = await app.request(`/api/habits/${createdHabit.id}/toggle`, {
    method: 'POST',
    headers: headersA,
    body: JSON.stringify({ date: todayIso }),
  });
  assert.strictEqual(toggleTodayRes.status, 200);
  const toggledBody = await toggleTodayRes.json();
  assert.strictEqual(toggledBody.completed, true);
  assert.strictEqual(toggledBody.habit.currentStreak, 1);

  console.log('3️⃣  Проверяем счета и атомарный пересчёт баланса при доходах/расходах...');
  const accListRes = await app.request('/api/finance/accounts', { headers: headersA });
  const { accounts } = await accListRes.json();
  const mainAccount = accounts[0];
  assert.strictEqual(mainAccount.balance, 0);

  const incRes = await app.request('/api/finance/transactions', {
    method: 'POST',
    headers: headersA,
    body: JSON.stringify({
      accountId: mainAccount.id,
      type: 'income',
      amount: 1500,
      category: 'Зарплата',
      description: 'Аванс',
    }),
  });
  assert.strictEqual(incRes.status, 201);
  assert.strictEqual((await incRes.json()).accountBalance, 1500);

  const expRes = await app.request('/api/finance/transactions', {
    method: 'POST',
    headers: headersA,
    body: JSON.stringify({
      accountId: mainAccount.id,
      type: 'expense',
      amount: 49.9,
      category: 'Продукты',
    }),
  });
  assert.strictEqual(expRes.status, 201);
  const expBody = await expRes.json();
  assert.strictEqual(expBody.accountBalance, 1450.1);

  const delTxRes = await app.request(
    `/api/finance/transactions/${expBody.transaction.id}`,
    {
      method: 'DELETE',
      headers: headersA,
    }
  );
  assert.strictEqual(delTxRes.status, 200);

  console.log('4️⃣  Проверяем сводный /api/dashboard...');
  const dashRes = await app.request('/api/dashboard', { headers: headersA });
  assert.strictEqual(dashRes.status, 200);
  const dash = await dashRes.json();
  assert.strictEqual(dash.financeStats.balancesByCurrency.EUR, 1500);
  assert.strictEqual(dash.tasksStats.done, 1);
  assert.strictEqual(dash.habitsStats.completedToday, 1);
  assert.ok(dash.notesStats.total >= 2);

  closeDatabase();
  if (fs.existsSync(TEST_DB_PATH)) {
    fs.unlinkSync(TEST_DB_PATH);
  }

  console.log('\n✅ Все рабочие модули проверены и работают безошибочно!');
}

run().catch((err) => {
  console.error('❌ Ошибка автопроверки модулей:', err);
  process.exit(1);
});
