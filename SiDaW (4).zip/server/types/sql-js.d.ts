declare module 'sql.js' {
  export type SqlValue = number | string | Uint8Array | null;

  export interface Statement {
    bind(values?: SqlValue[] | Record<string, SqlValue>): boolean;
    step(): boolean;
    getAsObject(params?: SqlValue[] | Record<string, SqlValue>): Record<string, any>;
    free(): boolean;
  }

  export class Database {
    constructor(data?: ArrayLike<number> | Buffer | null);
    run(sql: string, params?: SqlValue[] | Record<string, SqlValue>): Database;
    prepare(sql: string, params?: SqlValue[] | Record<string, SqlValue>): Statement;
    getRowsModified(): number;
    export(): Uint8Array;
    close(): void;
  }

  export interface SqlJsStatic {
    Database: typeof Database;
  }

  export default function initSqlJs(config?: {
    wasmBinary?: ArrayBuffer | Uint8Array | Buffer;
    locateFile?: (file: string) => string;
  }): Promise<SqlJsStatic>;
}
