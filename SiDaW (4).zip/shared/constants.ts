export const APP_CONFIG = {
  name: 'SiDaW',
  shortName: 'SiDaW',
  description: 'Умное рабочее пространство для задач, привычек, заметок и личных финансов',
  version: '1.3.0',
  sessionCookieName: 'sidaw_session',
  tokenHeaderName: 'x-sidaw-token',
  defaultSessionDays: 30,
} as const;

export const CURRENCIES = ['RUB', 'EUR', 'USD', 'KZT', 'BYN'] as const;
export type CurrencyCode = (typeof CURRENCIES)[number];

export const CURRENCY_SYMBOLS: Record<CurrencyCode, string> = {
  RUB: '₽',
  EUR: '€',
  USD: '$',
  KZT: '₸',
  BYN: 'Br',
};

export const TASK_PRIORITIES = ['low', 'medium', 'high'] as const;
export type TaskPriority = (typeof TASK_PRIORITIES)[number];

export const TASK_STATUSES = ['todo', 'in_progress', 'done'] as const;
export type TaskStatus = (typeof TASK_STATUSES)[number];

export const HABIT_COLORS = [
  'cyan',
  'emerald',
  'violet',
  'amber',
  'rose',
  'indigo',
] as const;
export type HabitColor = (typeof HABIT_COLORS)[number];

export const NOTE_COLORS = [
  'default',
  'amber',
  'emerald',
  'sky',
  'violet',
  'rose',
] as const;
export type NoteColor = (typeof NOTE_COLORS)[number];

export const ACCOUNT_TYPES = ['card', 'cash', 'savings'] as const;
export type AccountType = (typeof ACCOUNT_TYPES)[number];

export const TRANSACTION_TYPES = ['income', 'expense'] as const;
export type TransactionType = (typeof TRANSACTION_TYPES)[number];

// ==========================================
// НАВИГАЦИЯ И ФИРМЕННЫЕ ЦВЕТА КАЖДОЙ ВКЛАДКИ
// ==========================================

export const NAV_TAB_IDS = [
  'dashboard',
  'tasks',
  'habits',
  'notes',
  'finance',
  'profile',
] as const;
export type NavTabId = (typeof NAV_TAB_IDS)[number];

export interface TabColorPalette {
  id: NavTabId;
  name: string;
  accentHex: string;
  accentRgb: string;
  secondaryHex: string;
  secondaryRgb: string;
  darkBgTint: string;
  lightBgTint: string;
}

export const TAB_COLOR_THEMES: Record<NavTabId, TabColorPalette> = {
  dashboard: {
    id: 'dashboard',
    name: 'Сапфир',
    accentHex: '#6366f1',
    accentRgb: '99, 102, 241',
    secondaryHex: '#0ea5e9',
    secondaryRgb: '14, 165, 233',
    darkBgTint: '#0b1026',
    lightBgTint: '#e8edff',
  },
  tasks: {
    id: 'tasks',
    name: 'Аметист',
    accentHex: '#a855f7',
    accentRgb: '168, 85, 247',
    secondaryHex: '#d946ef',
    secondaryRgb: '217, 70, 239',
    darkBgTint: '#170b29',
    lightBgTint: '#f3e8ff',
  },
  habits: {
    id: 'habits',
    name: 'Топаз',
    accentHex: '#06b6d4',
    accentRgb: '6, 182, 212',
    secondaryHex: '#3b82f6',
    secondaryRgb: '59, 130, 246',
    darkBgTint: '#051e29',
    lightBgTint: '#cffafe',
  },
  notes: {
    id: 'notes',
    name: 'Янтарь',
    accentHex: '#f59e0b',
    accentRgb: '245, 158, 11',
    secondaryHex: '#f97316',
    secondaryRgb: '249, 115, 22',
    darkBgTint: '#231507',
    lightBgTint: '#fef3c7',
  },
  finance: {
    id: 'finance',
    name: 'Изумруд',
    accentHex: '#10b981',
    accentRgb: '16, 185, 129',
    secondaryHex: '#14b8a6',
    secondaryRgb: '20, 184, 166',
    darkBgTint: '#062119',
    lightBgTint: '#d1fae5',
  },
  profile: {
    id: 'profile',
    name: 'Розовый кварц',
    accentHex: '#ec4899',
    accentRgb: '236, 72, 153',
    secondaryHex: '#f43f5e',
    secondaryRgb: '244, 63, 94',
    darkBgTint: '#250a1b',
    lightBgTint: '#fce7f3',
  },
};

// ==========================================
// ТЕМЫ ОФОРМЛЕНИЯ И ФОНОВЫЕ АТМОСФЕРЫ
// ==========================================

export const THEME_MODES = ['dark', 'light', 'system'] as const;
export type ThemeMode = (typeof THEME_MODES)[number];

export const BACKGROUND_THEMES = [
  'aurora',
  'ocean',
  'sunset',
  'forest',
  'cosmic',
  'minimal',
] as const;
export type BackgroundThemeId = (typeof BACKGROUND_THEMES)[number];

export const BACKGROUND_THEME_META: Record<
  BackgroundThemeId,
  { label: string; description: string; previewGradient: string }
> = {
  aurora: {
    label: 'Адаптивное сияние',
    description: 'Чистый перелив фона в фирменный цвет каждой вкладки',
    previewGradient: 'linear-gradient(135deg, #4f46e5 0%, #a855f7 50%, #10b981 100%)',
  },
  ocean: {
    label: 'Глубокий океан',
    description: 'Цвет вкладки с прохладным морским оттенком',
    previewGradient: 'linear-gradient(135deg, #0284c7 0%, #0369a1 50%, #1e1b4b 100%)',
  },
  sunset: {
    label: 'Закатный горизонт',
    description: 'Цвет вкладки с тёплым рубиново-закатным отливом',
    previewGradient: 'linear-gradient(135deg, #f43f5e 0%, #d946ef 50%, #f59e0b 100%)',
  },
  forest: {
    label: 'Изумрудный лес',
    description: 'Цвет вкладки с глубоким хвойно-бирюзовым подтоном',
    previewGradient: 'linear-gradient(135deg, #059669 0%, #0f766e 50%, #064e3b 100%)',
  },
  cosmic: {
    label: 'Космос и туманность',
    description: 'Контрастный глубокий фон со свечением вкладки',
    previewGradient: 'linear-gradient(135deg, #312e81 0%, #581c87 50%, #090d16 100%)',
  },
  minimal: {
    label: 'Спокойный шёлк',
    description: 'Приглушённый мягкий фон с деликатным оттенком вкладки',
    previewGradient: 'linear-gradient(135deg, #334155 0%, #1e293b 50%, #0f172a 100%)',
  },
};

export const GLASS_INTENSITIES = ['clear', 'balanced', 'frosted', 'performance'] as const;
export type GlassIntensity = (typeof GLASS_INTENSITIES)[number];

export const START_TABS = ['dashboard', 'tasks', 'habits', 'notes', 'finance'] as const;
export type StartTabId = (typeof START_TABS)[number];
