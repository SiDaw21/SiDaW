import { z } from 'zod';
import {
  ACCOUNT_TYPES,
  BACKGROUND_THEMES,
  CURRENCIES,
  GLASS_INTENSITIES,
  HABIT_COLORS,
  NOTE_COLORS,
  START_TABS,
  TASK_PRIORITIES,
  TASK_STATUSES,
  THEME_MODES,
  TRANSACTION_TYPES,
} from './constants';

// ==========================================
// 0. ПЕРСОНАЛЬНЫЕ НАСТРОЙКИ (Liquid Glass + UI)
// ==========================================

export const userSettingsSchema = z.object({
  themeMode: z.enum(THEME_MODES).optional().default('dark'),
  backgroundTheme: z.enum(BACKGROUND_THEMES).optional().default('aurora'),
  glassIntensity: z.enum(GLASS_INTENSITIES).optional().default('balanced'),
  compactMode: z.boolean().optional().default(false),
  hideBalances: z.boolean().optional().default(false),
  showCents: z.boolean().optional().default(true),
  soundEffects: z.boolean().optional().default(true),
  animationsEnabled: z.boolean().optional().default(true),
  startTab: z.enum(START_TABS).optional().default('dashboard'),
});

export const userSettingsPatchSchema = userSettingsSchema.partial();

export type UserSettings = z.infer<typeof userSettingsSchema>;
export type UserSettingsPatch = z.infer<typeof userSettingsPatchSchema>;

export const DEFAULT_USER_SETTINGS: UserSettings = {
  themeMode: 'dark',
  backgroundTheme: 'aurora',
  glassIntensity: 'balanced',
  compactMode: false,
  hideBalances: false,
  showCents: true,
  soundEffects: true,
  animationsEnabled: true,
  startTab: 'dashboard',
};

// ==========================================
// 1. АВТОРИЗАЦИЯ И АККАУНТ
// ==========================================

export const registerSchema = z.object({
  name: z
    .string()
    .trim()
    .min(2, 'Имя должно содержать минимум 2 символа')
    .max(50, 'Имя слишком длинное'),
  email: z
    .string()
    .trim()
    .toLowerCase()
    .email('Введите корректный email'),
  password: z
    .string()
    .min(6, 'Пароль должен быть не короче 6 символов')
    .max(100, 'Пароль слишком длинный'),
  defaultCurrency: z.enum(CURRENCIES).optional().default('EUR'),
});

export const loginSchema = z.object({
  email: z
    .string()
    .trim()
    .toLowerCase()
    .email('Введите корректный email'),
  password: z.string().min(1, 'Введите пароль'),
});

export const changePasswordSchema = z.object({
  currentPassword: z.string().min(1, 'Введите текущий пароль'),
  newPassword: z
    .string()
    .min(6, 'Новый пароль должен быть не короче 6 символов')
    .max(100, 'Пароль слишком длинный'),
  revokeOtherSessions: z.boolean().optional().default(false),
});

export type RegisterInput = z.infer<typeof registerSchema>;
export type LoginInput = z.infer<typeof loginSchema>;
export type ChangePasswordInput = z.infer<typeof changePasswordSchema>;

export interface UserDTO {
  id: string;
  email: string;
  name: string;
  defaultCurrency: (typeof CURRENCIES)[number];
  settings?: UserSettings;
  createdAt: string;
}

export interface SessionDTO {
  id: string;
  deviceLabel: string;
  createdAt: string;
  lastSeenAt: string;
  expiresAt: string;
  isCurrent: boolean;
}

export interface AuthResponseDTO {
  user: UserDTO;
  token: string;
  session: SessionDTO;
}

// ==========================================
// 2. ЗАДАЧИ
// ==========================================

export const taskCreateSchema = z.object({
  id: z.string().uuid().optional(),
  title: z.string().trim().min(1, 'Укажите название задачи').max(200),
  description: z.string().trim().max(2000).optional().default(''),
  status: z.enum(TASK_STATUSES).optional().default('todo'),
  priority: z.enum(TASK_PRIORITIES).optional().default('medium'),
  category: z.string().trim().max(50).optional().default('Личное'),
  dueDate: z.string().nullable().optional().default(null),
});

export const taskUpdateSchema = taskCreateSchema.partial().omit({ id: true });

export type TaskCreateInput = z.infer<typeof taskCreateSchema>;
export type TaskUpdateInput = z.infer<typeof taskUpdateSchema>;

export interface TaskDTO {
  id: string;
  title: string;
  description: string;
  status: (typeof TASK_STATUSES)[number];
  priority: (typeof TASK_PRIORITIES)[number];
  category: string;
  dueDate: string | null;
  completedAt: string | null;
  createdAt: string;
  updatedAt: string;
}

// ==========================================
// 2.5. ПРИВЫЧКИ (Трекер серий и регулярности)
// ==========================================

export const habitCreateSchema = z.object({
  id: z.string().uuid().optional(),
  title: z.string().trim().min(1, 'Укажите название привычки').max(120),
  description: z.string().trim().max(500).optional().default(''),
  color: z.enum(HABIT_COLORS).optional().default('cyan'),
  targetDaysPerWeek: z.number().int().min(1).max(7).optional().default(7),
});

export const habitUpdateSchema = habitCreateSchema.partial().omit({ id: true });

export const habitToggleSchema = z.object({
  date: z
    .string()
    .regex(/^\d{4}-\d{2}-\d{2}$/, 'Ожидается дата в формате YYYY-MM-DD')
    .optional(),
});

export type HabitCreateInput = z.infer<typeof habitCreateSchema>;
export type HabitUpdateInput = z.infer<typeof habitUpdateSchema>;
export type HabitToggleInput = z.infer<typeof habitToggleSchema>;

export interface HabitDTO {
  id: string;
  title: string;
  description: string;
  color: (typeof HABIT_COLORS)[number];
  targetDaysPerWeek: number;
  completedDates: string[];
  currentStreak: number;
  bestStreak: number;
  totalCompletions: number;
  createdAt: string;
  updatedAt: string;
}

// ==========================================
// 3. ЗАМЕТКИ
// ==========================================

export const noteCreateSchema = z.object({
  id: z.string().uuid().optional(),
  title: z.string().trim().min(1, 'Укажите заголовок заметки').max(200),
  content: z.string().max(50000).optional().default(''),
  tags: z.array(z.string().trim().max(30)).max(15).optional().default([]),
  color: z.enum(NOTE_COLORS).optional().default('default'),
  isPinned: z.boolean().optional().default(false),
});

export const noteUpdateSchema = noteCreateSchema.partial().omit({ id: true });

export type NoteCreateInput = z.infer<typeof noteCreateSchema>;
export type NoteUpdateInput = z.infer<typeof noteUpdateSchema>;

export interface NoteDTO {
  id: string;
  title: string;
  content: string;
  tags: string[];
  color: (typeof NOTE_COLORS)[number];
  isPinned: boolean;
  createdAt: string;
  updatedAt: string;
}

// ==========================================
// 4. ФИНАНСЫ (Счета и Транзакции)
// ==========================================

export const accountCreateSchema = z.object({
  id: z.string().uuid().optional(),
  name: z.string().trim().min(1, 'Укажите название счёта').max(80),
  type: z.enum(ACCOUNT_TYPES).optional().default('card'),
  currency: z.enum(CURRENCIES).optional().default('EUR'),
  initialBalance: z.number().finite().optional().default(0),
  color: z.string().trim().max(30).optional().default('#10b981'),
});

export const accountUpdateSchema = z.object({
  name: z.string().trim().min(1, 'Укажите название счёта').max(80).optional(),
  type: z.enum(ACCOUNT_TYPES).optional(),
  color: z.string().trim().max(30).optional(),
});

export const transactionCreateSchema = z.object({
  id: z.string().uuid().optional(),
  accountId: z.string().min(1, 'Выберите счёт'),
  type: z.enum(TRANSACTION_TYPES),
  amount: z.number().positive('Сумма должна быть больше нуля'),
  category: z.string().trim().min(1, 'Выберите категорию').max(60),
  description: z.string().trim().max(300).optional().default(''),
  date: z.string().optional(),
});

export type AccountCreateInput = z.infer<typeof accountCreateSchema>;
export type AccountUpdateInput = z.infer<typeof accountUpdateSchema>;
export type TransactionCreateInput = z.infer<typeof transactionCreateSchema>;

export interface AccountDTO {
  id: string;
  name: string;
  type: (typeof ACCOUNT_TYPES)[number];
  currency: (typeof CURRENCIES)[number];
  balance: number;
  color: string;
  createdAt: string;
  updatedAt: string;
}

export interface TransactionDTO {
  id: string;
  accountId: string;
  accountName?: string;
  currency?: (typeof CURRENCIES)[number];
  type: (typeof TRANSACTION_TYPES)[number];
  amount: number;
  category: string;
  description: string;
  date: string;
  createdAt: string;
  updatedAt: string;
}

// ==========================================
// 5. СВОДНЫЙ ДАШБОРД
// ==========================================

export interface DashboardSummaryDTO {
  tasksStats: {
    total: number;
    todo: number;
    inProgress: number;
    done: number;
    overdue: number;
  };
  activeTasks: TaskDTO[];
  habitsStats: {
    total: number;
    completedToday: number;
    bestActiveStreak: number;
  };
  notesStats: {
    total: number;
    pinned: number;
  };
  recentNotes: NoteDTO[];
  financeStats: {
    balancesByCurrency: Record<string, number>;
    monthIncomeByCurrency: Record<string, number>;
    monthExpenseByCurrency: Record<string, number>;
  };
  accounts: AccountDTO[];
  recentTransactions: TransactionDTO[];
}
